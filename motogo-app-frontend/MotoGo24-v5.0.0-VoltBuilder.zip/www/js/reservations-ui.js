// ===== RESERVATIONS-UI.JS – Dynamic reservation list & detail =====
// Renders reservation cards from Supabase backend data.

var _resFilter = 'all';
var _cachedBookings = null;

async function _getBookingById(bookingId){
  if(_isSupabaseReady()){
    try {
      var result = await supabase.from('bookings').select('*, motorcycles(*, branches(name, address, city))').eq('id',bookingId).single();
      if(result.data) return result.data;
    } catch(e){}
  }
  return null;
}

async function _getMotoById(motoId){
  if(_isSupabaseReady()){
    try {
      var result = await supabase.from('motorcycles').select('*, branches(name, address, city)').eq('id',motoId).single();
      if(result.data) return result.data;
    } catch(e){}
  }
  return null;
}

function filterRes(el, filter){
  try {
    _resFilter = filter;
    document.querySelectorAll('#s-res .chip').forEach(function(c){ c.classList.remove('active'); });
    if(el) el.classList.add('active');
    renderMyReservations();
  } catch(e){ console.error('filterRes error:', e); }
}

async function renderMyReservations(){
  try {
    var session = await _getSession();
    if(!session) return;

    var bookings = await apiFetchMyBookings();
    _cachedBookings = bookings;
    if(!bookings || bookings.length === 0){
      _setResContent('<div style="padding:40px 20px;text-align:center;color:var(--g400);font-size:13px;font-weight:600;">'+_t('res').noReservations+'</div>');
      return;
    }

    // Filter by status
    var filtered = bookings;
    if(_resFilter !== 'all'){
      filtered = bookings.filter(function(b){
        var st = _mapStatus(b.status, b.start_date, b.end_date, b.payment_status);
        return st === _resFilter;
      });
    }

    if(filtered.length === 0){
      _setResContent('<div style="padding:40px 20px;text-align:center;color:var(--g400);font-size:13px;font-weight:600;">'+_t('res').noInCategory+'</div>');
      return;
    }

    var html = filtered.map(function(b){ return _renderResCard(b); }).join('');
    _setResContent(html);
  } catch(e){ console.error('renderMyReservations error:', e); }
}

function _setResContent(html){
  // Render into #res-list container inside s-res
  var resList = document.getElementById('res-list');
  if(resList){ resList.innerHTML = html; return; }
  // Fallback: append to screen
  var resScreen = document.getElementById('s-res');
  if(!resScreen) return;
  var existing = resScreen.querySelector('.res-cards-dynamic');
  if(existing) existing.remove();
  var container = document.createElement('div');
  container.className = 'res-cards-dynamic';
  container.innerHTML = html;
  resScreen.appendChild(container);
}

function _mapStatus(status, startDate, endDate, paymentStatus){
  if(status === 'cancelled') return 'cancelled';
  // Unpaid bookings never become active regardless of dates
  if(paymentStatus === 'unpaid' && status === 'pending') return 'nadchazejici';
  var now = new Date(); now.setHours(0,0,0,0);
  var s = new Date(startDate); s.setHours(0,0,0,0);
  var e = new Date(endDate); e.setHours(0,0,0,0);
  if(now > e) return 'dokoncene';
  if(now >= s && now <= e && (status === 'active' || paymentStatus === 'paid')) return 'aktivni';
  if(now >= s && now <= e) return 'nadchazejici';
  return 'nadchazejici';
}

function _statusLabel(st){
  var map = {aktivni:_t('res').active, nadchazejici:_t('res').upcoming, dokoncene:_t('res').completed, cancelled:_t('res').cancelled};
  return map[st] || st;
}

function _statusClass(st){
  var map = {aktivni:'s-act', nadchazejici:'s-up', dokoncene:'s-done', cancelled:'s-done'};
  return map[st] || '';
}

function _fmtDate(iso){
  try {
    var d = new Date(iso);
    return d.getDate() + '. ' + (d.getMonth()+1) + '. ' + d.getFullYear();
  } catch(e){ return '—'; }
}

function _renderResCard(b){
  var st = _mapStatus(b.status, b.start_date, b.end_date, b.payment_status);
  var stLabel = _statusLabel(st);
  var stClass = _statusClass(st);
  var s = new Date(b.start_date); s.setHours(0,0,0,0);
  var e = new Date(b.end_date); e.setHours(0,0,0,0);
  var days = Math.max(1, Math.round((e-s)/86400000)+1);
  var img = b.moto_image || '';
  var name = b.moto_name || 'Motorka';
  var grayscale = (st === 'dokoncene' || st === 'cancelled') ? 'filter:grayscale(.5);' : '';

  var btns = '';
  if(st === 'aktivni'){
    btns = '<div class="rbtn g" onclick="event.stopPropagation();openResDetailById(\''+b.id+'\')">📋 '+_t('res').detail+'</div>' +
           '<div class="rbtn" style="background:var(--green);color:#fff;border-color:var(--green);" onclick="event.stopPropagation();openEditResByBookingId(\''+b.id+'\')">⏱ '+_t('res').extendRental+'</div>' +
           '<div class="rbtn" style="background:#fee2e2;color:#b91c1c;border-color:#fca5a5;" onclick="event.stopPropagation();goTo(\'s-sos\')">🆘 '+_t('res').fault+'</div>';
  } else if(st === 'nadchazejici'){
    btns = '<div class="rbtn g" onclick="event.stopPropagation();openResDetailById(\''+b.id+'\')">📋 '+_t('res').detail+'</div>' +
           '<div class="rbtn" style="background:var(--green);color:#fff;border-color:var(--green);" onclick="event.stopPropagation();openEditResByBookingId(\''+b.id+'\')">✏️ '+_t('res').editReservation+'</div>';
  } else if(st === 'dokoncene'){
    btns = '<div class="rbtn g" onclick="event.stopPropagation();openResDetailById(\''+b.id+'\')">📋 '+_t('res').rideDetail+'</div>' +
           '<div class="rbtn" style="background:var(--dark);color:#fff;border-color:var(--dark);" onclick="event.stopPropagation();goTo(\'s-protocol\')">📝 '+_t('res').returnProtocol+'</div>' +
           '<div class="rbtn" onclick="event.stopPropagation();showT(\'⭐\',_t(\'res\').sent,_t(\'res\').thankRating)">⭐ '+_t('res').rate+'</div>';
  } else if(st === 'cancelled'){
    btns = '<div class="rbtn g" onclick="event.stopPropagation();openResDetailById(\''+b.id+'\')">📋 '+_t('res').detail+'</div>' +
           '<div class="rbtn" style="background:var(--green);color:#fff;border-color:var(--green);" onclick="event.stopPropagation();restoreBooking(\''+b.id+'\')">🔄 '+_t('res').restoreRes+'</div>';
  }

  return '<div class="rcard" onclick="openResDetailById(\''+b.id+'\')">' +
    '<div class="rci" style="'+grayscale+'"><img src="'+img+'" onerror="this.style.display=\'none\'" loading="lazy"><div class="rcio"><div><div class="rcn">'+name+'</div><div class="rcid">#'+b.id.substr(-8).toUpperCase()+'</div></div></div><div class="rst '+stClass+'">'+stLabel+'</div></div>' +
    '<div class="rcb"><div class="rcinfo"><div class="rccol"><div class="rccol-l">'+_t('res').date+'</div><div class="rccol-v">'+_fmtDate(b.start_date)+'</div></div><div class="rccol"><div class="rccol-l">'+_t('res').duration+'</div><div class="rccol-v">'+days+' '+(days===1?_t('res').day1:_t('res').days5)+'</div></div><div class="rccol"><div class="rccol-l">'+_t('res').total+'</div><div class="rccol-v">'+(b.total_price||0).toLocaleString('cs-CZ')+' Kč</div></div></div>' +
    '<div class="ract">'+btns+'</div></div></div>';
}

// ===== RESERVATION DETAIL =====
var _currentResId = null;

async function openResDetailById(bookingId){
  try {
    _currentResId = bookingId;
    // Try cached bookings first, then Supabase
    var booking = null;
    if(_cachedBookings){
      for(var ci=0;ci<_cachedBookings.length;ci++){
        if(_cachedBookings[ci].id === bookingId){ booking = _cachedBookings[ci]; break; }
      }
    }
    if(!booking) booking = await _getBookingById(bookingId);
    if(!booking){ showT('✗',_t('common').error,_t('res').resNotFound); return; }

    var moto = booking.motorcycles || (booking.moto_id ? await _getMotoById(booking.moto_id) : null);
    var st = _mapStatus(booking.status, booking.start_date, booking.end_date, booking.payment_status);
    var s = new Date(booking.start_date);
    var e = new Date(booking.end_date);
    var days = Math.max(1, Math.round((e-s)/86400000)+1);
    var motoName = moto ? (moto.model || moto.name) : (booking.moto_name || 'Motorka');

    var titleEl = document.getElementById('rd-title');
    if(titleEl) titleEl.textContent = _t('res').resDetail + ' – ' + _statusLabel(st);
    var subEl = document.getElementById('rd-subtitle');
    if(subEl) subEl.textContent = '#' + bookingId.substr(-8).toUpperCase();

    var imgEl = document.getElementById('rd-moto-img');
    if(imgEl && moto) imgEl.src = moto.image_url || '';

    var nameEl = document.getElementById('rd-moto-name');
    if(nameEl) nameEl.textContent = motoName;

    var pickupEl = document.getElementById('rd-pickup');
    if(pickupEl) pickupEl.textContent = _fmtDate(booking.start_date) + ' ' + _t('res').at + ' ' + (booking.pickup_time || '9:00');
    var returnEl = document.getElementById('rd-return');
    if(returnEl) returnEl.textContent = _fmtDate(booking.end_date) + ' ' + _t('res').at + ' 9:00';
    var durEl = document.getElementById('rd-duration');
    if(durEl) durEl.textContent = days + ' ' + (days===1?_t('res').day1:_t('res').days5);

    var totalEl = document.getElementById('rd-total');
    if(totalEl) totalEl.textContent = (booking.total_price||0).toLocaleString('cs-CZ') + ' Kč';

    // Banner
    var banner = document.getElementById('rd-banner');
    if(banner){
      if(st === 'aktivni'){
        var now2 = new Date();
        var endD = new Date(booking.end_date);
        var hoursLeft = (endD - now2) / (1000*60*60);
        var daysLeft = Math.ceil(hoursLeft / 24);
        var refInfo = '';
        if(hoursLeft > 7*24) refInfo = '<div style="font-size:11px;margin-top:6px;color:var(--gd);">'+_t('res').cancelFull+'</div>';
        else if(hoursLeft > 48) refInfo = '<div style="font-size:11px;margin-top:6px;color:#d97706;">'+_t('res').cancelHalf+'</div>';
        else refInfo = '<div style="font-size:11px;margin-top:6px;color:var(--red);">'+_t('res').cancelNone+'</div>';
        banner.style.display = 'block';
        banner.className = 'rd-info-banner rd-banner-info';
        banner.innerHTML = '🏍️ '+_t('res').ridingNow+' ' + daysLeft + ' ' + (daysLeft===1?_t('res').day1:daysLeft<5?_t('res').days2:_t('res').days5) + '.' + refInfo;
      } else if(st === 'nadchazejici'){
        var now3 = new Date();
        var startD2 = new Date(booking.start_date);
        var hoursTo = (startD2 - now3) / (1000*60*60);
        var daysTo = Math.ceil(hoursTo / 24);
        var refInfo2 = '';
        if(hoursTo > 7*24) refInfo2 = '<div style="font-size:11px;margin-top:6px;color:var(--gd);">'+_t('res').cancelNowFull+'</div>';
        else if(hoursTo > 48) refInfo2 = '<div style="font-size:11px;margin-top:6px;color:#d97706;">'+_t('res').cancelNowHalf+'</div>';
        else refInfo2 = '<div style="font-size:11px;margin-top:6px;color:var(--red);">'+_t('res').cancelNowNone+'</div>';
        banner.style.display = 'block';
        banner.className = 'rd-info-banner rd-banner-info';
        banner.innerHTML = '📅 '+_t('res').pickupOn+' ' + _fmtDate(booking.start_date) + ' ('+_t('res').inDays+' ' + daysTo + ' ' + (daysTo===1?_t('res').day1:daysTo<5?_t('res').days2:_t('res').days5) + ')' + refInfo2;
      } else {
        banner.style.display = 'none';
      }
    }

    // Action buttons
    var actionsEl = document.getElementById('rd-actions');
    if(actionsEl){
      var btns = '';
      if(st === 'aktivni'){
        btns = '<button class="btn-g" onclick="openEditResByBookingId(\''+bookingId+'\')">✏️ '+_t('res').editExtend+'</button>' +
               '<button class="btn-g" style="background:#fee2e2;color:#b91c1c;border:none;margin-top:8px;" onclick="goTo(\'s-sos\')">🆘 '+_t('res').reportFault+'</button>';
      } else if(st === 'nadchazejici'){
        btns = '<button class="btn-g" onclick="openEditResByBookingId(\''+bookingId+'\')">✏️ '+_t('res').editReservation+'</button>' +
               '<button class="btn-g" style="background:var(--red);color:#fff;border:none;margin-top:8px;" onclick="doCancelBooking(\''+bookingId+'\')">🗑️ '+_t('res').cancelRes+'</button>';
      } else if(st === 'dokoncene'){
        btns = '<button class="btn-out" onclick="showDigitalProtocol(\''+bookingId+'\')">📝 '+_t('res').handoverProtocol+'</button>' +
               '<button class="btn-out" style="margin-top:8px;" onclick="showRentalContract(\''+bookingId+'\')">📄 '+_t('res').contract+'</button>' +
               '<button class="btn-out" style="margin-top:8px;" onclick="showInvoice(\''+bookingId+'\',\'final\')">💰 '+_t('res').finalInvoice+'</button>';
      } else if(st === 'cancelled'){
        btns = '<button class="btn-g" onclick="restoreBooking(\''+bookingId+'\')">🔄 '+_t('res').restoreBtn+'</button>';
      }
      actionsEl.innerHTML = btns;
    }

    goTo('s-res-detail');
  } catch(e){ console.error('openResDetailById error:', e); }
}

async function doCancelBooking(bookingId){
  try {
    var booking = await _getBookingById(bookingId);
    if(!booking){ showT('✗',_t('common').error,_t('res').resNotFound); return; }

    var now = new Date();
    var startDate = new Date(booking.start_date);
    var hoursUntilStart = (startDate - now) / (1000 * 60 * 60);
    var daysUntilStart = Math.ceil(hoursUntilStart / 24);
    var refundMsg = '';
    var refundPolicy = '<div style="font-size:11px;color:var(--g400);line-height:1.7;margin-top:8px;text-align:left;border-top:1px solid var(--g100);padding-top:8px;">' +
      '<div' + (hoursUntilStart > 7*24 ? ' style="color:var(--gd);font-weight:700;"' : '') + '>'+_t('res').policy7days+'</div>' +
      '<div' + (hoursUntilStart > 48 && hoursUntilStart <= 7*24 ? ' style="color:#d97706;font-weight:700;"' : '') + '>'+_t('res').policy2to7days+'</div>' +
      '<div' + (hoursUntilStart <= 48 ? ' style="color:var(--red);font-weight:700;"' : '') + '>'+_t('res').policyUnder2days+'</div></div>';

    if(hoursUntilStart > 7 * 24) refundMsg = _t('res').refund100+' (' + (booking.total_price||0).toLocaleString('cs-CZ') + ' Kč).<br><span style="font-size:11px;color:var(--g400);">'+_t('res').daysRemaining+' ' + daysUntilStart + ' '+_t('res').daysToStart+'</span>';
    else if(hoursUntilStart > 48) refundMsg = _t('res').refund50+' (' + Math.round((booking.total_price||0)*0.5).toLocaleString('cs-CZ') + ' Kč).<br><span style="font-size:11px;color:var(--g400);">'+_t('res').daysRemaining+' ' + daysUntilStart + ' '+_t('res').daysToStart+'</span>';
    else refundMsg = _t('res').refundNone+'<br><span style="font-size:11px;color:var(--g400);">'+_t('res').lessThan2days+'</span>';

    _showCancelDialog(bookingId, refundMsg + refundPolicy);
  } catch(e){ console.error('doCancelBooking error:', e); showT('✗',_t('common').error,_t('res').cancelFailed); }
}

function _showCancelDialog(bookingId, refundMsg){
  var existing = document.getElementById('cancel-confirm-overlay');
  if(existing) existing.remove();

  var overlay = document.createElement('div');
  overlay.id = 'cancel-confirm-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;padding:20px;';
  overlay.innerHTML = '<div style="background:#fff;border-radius:16px;padding:24px;max-width:320px;width:100%;text-align:center;">' +
    '<div style="font-size:32px;margin-bottom:10px;">🗑️</div>' +
    '<div style="font-size:16px;font-weight:800;color:var(--black);margin-bottom:8px;">'+_t('res').cancelConfirmTitle+'</div>' +
    '<div style="font-size:13px;color:var(--g600);line-height:1.5;margin-bottom:18px;">' + refundMsg + '</div>' +
    '<div style="display:flex;gap:10px;">' +
      '<button onclick="document.getElementById(\'cancel-confirm-overlay\').remove()" style="flex:1;padding:12px;border-radius:10px;border:2px solid var(--g200);background:#fff;font-family:var(--font);font-size:13px;font-weight:700;cursor:pointer;color:var(--black);">'+_t('res').keepBtn+'</button>' +
      '<button onclick="_execCancelBooking(\'' + bookingId + '\')" style="flex:1;padding:12px;border-radius:10px;border:none;background:var(--red);color:#fff;font-family:var(--font);font-size:13px;font-weight:700;cursor:pointer;">'+_t('res').cancelBtn+'</button>' +
    '</div></div>';
  document.body.appendChild(overlay);
  overlay.addEventListener('click', function(e){ if(e.target === overlay) overlay.remove(); });
}

async function _execCancelBooking(bookingId){
  var overlay = document.getElementById('cancel-confirm-overlay');
  if(overlay) overlay.remove();

  var result = await apiCancelBooking(bookingId);
  if(result.error){ showT('✗',_t('common').error, result.error); return; }

  var refundText = result.refund_percent > 0
    ? _t('res').refundOf+' ' + (result.refund_amount||0).toLocaleString('cs-CZ') + ' Kč (' + result.refund_percent + ' %)'
    : _t('res').noRefundText;
  showT('✓',_t('res').resCancelled, refundText);
  renderMyReservations();
  if(typeof cur !== 'undefined' && cur === 's-res-detail') histBack();
}

async function openEditResByBookingId(bookingId){
  try {
    var booking = await _getBookingById(bookingId);
    if(!booking){ showT('✗',_t('common').error,_t('res').resNotFound); return; }
    var moto = booking.motorcycles || (booking.moto_id ? await _getMotoById(booking.moto_id) : null);
    var st = _mapStatus(booking.status, booking.start_date, booking.end_date, booking.payment_status);
    var isActive = (st === 'aktivni');

    // Set V9 global variables for edit screen
    editIsActive = isActive;

    var s = new Date(booking.start_date); s.setHours(0,0,0,0);
    var e = new Date(booking.end_date); e.setHours(0,0,0,0);
    var motoName = moto ? (moto.model || moto.name) : (booking.moto_name || 'Motorka');
    var days = Math.max(1, Math.round((e-s)/86400000)+1);

    // origResStart and origResEnd for edit calendar
    origResStart = {d:s.getDate(), m:s.getMonth(), y:s.getFullYear()};
    origResEnd = {d:e.getDate(), m:e.getMonth(), y:e.getFullYear()};

    // Fill UI
    var subEl = document.getElementById('edit-subtitle');
    if(subEl) subEl.textContent = motoName + ' · #' + bookingId.substr(-8).toUpperCase();

    var durEl = document.getElementById('edit-res-duration');
    var dateRangeEl = document.getElementById('edit-res-dates');
    var now = new Date(); now.setHours(0,0,0,0);

    if(isActive){
      var remaining = Math.max(0, Math.round((e-now)/86400000))+1;
      if(durEl) durEl.textContent = _t('res').activeRemaining+' ' + remaining + (remaining===1?' '+_t('res').day1:remaining<5?' '+_t('res').days2:' '+_t('res').days5);
    } else {
      var daysTo = Math.max(0, Math.round((s-now)/86400000));
      if(durEl) durEl.textContent = _t('res').upcomingIn+' ' + daysTo + (daysTo===1?' '+_t('res').day1:daysTo<5?' '+_t('res').days2:' '+_t('res').days5) + ' · ' + days + (days===1?' '+_t('res').day1:days<5?' '+_t('res').days2:' '+_t('res').days5);
    }
    if(dateRangeEl) dateRangeEl.textContent = s.getDate()+'.'+(s.getMonth()+1)+'. – '+e.getDate()+'.'+(e.getMonth()+1)+'.'+e.getFullYear();

    // Calendar info
    var calResDates = document.getElementById('edit-cal-res-dates');
    var calResMoto = document.getElementById('edit-cal-res-moto');
    var calResInfo = document.getElementById('edit-res-info-cal');
    if(calResDates) calResDates.textContent = dateRangeEl ? dateRangeEl.textContent : '';
    if(calResMoto) calResMoto.textContent = motoName + ' · #' + bookingId.substr(-8).toUpperCase();
    if(calResInfo){
      var infoDiv = calResInfo.querySelector('div');
      if(infoDiv) infoDiv.textContent = isActive ? _t('res').yourActiveRes : _t('res').yourUpcomingRes;
    }

    // Reset edit UI
    var shortenNote = document.getElementById('edit-shorten-note');
    if(shortenNote) shortenNote.style.display = 'none';
    var priceSum = document.getElementById('edit-price-summary');
    if(priceSum) priceSum.style.display = 'none';
    var saveBtn = document.getElementById('edit-save-btn');
    if(saveBtn) saveBtn.textContent = _t('res').saveChanges;

    // Store booking ID for saveEditReservation
    window._editBookingId = bookingId;
    window._editBookingMoto = moto;

    // Zobrazit doplňky jen pro nadcházející
    var extrasCard = document.getElementById('edit-extras-card');
    if(extrasCard) extrasCard.style.display = isActive ? 'none' : 'block';

    // Naplnit text data
    var odTxt = document.getElementById('edit-od-txt');
    var doTxt = document.getElementById('edit-do-txt');
    if(odTxt) odTxt.textContent = s.getDate()+'.'+(s.getMonth()+1)+'.'+s.getFullYear();
    if(doTxt) doTxt.textContent = e.getDate()+'.'+(e.getMonth()+1)+'.'+e.getFullYear();

    // Nastavit eOd, eDo
    eOd = {d:s.getDate(), m:s.getMonth(), y:s.getFullYear()};
    eDo = {d:e.getDate(), m:e.getMonth(), y:e.getFullYear()};

    // Reset extras and moto change
    if(typeof editExtrasTotal !== 'undefined') editExtrasTotal = 0;
    if(typeof editReturnFee !== 'undefined') editReturnFee = 0;
    if(typeof editMotoDiffPrice !== 'undefined') editMotoDiffPrice = 0;
    if(typeof editNewMotoId !== 'undefined') editNewMotoId = null;

    if(typeof switchEditTab === 'function') switchEditTab('prodlouzit');
    goTo('s-edit-res');
  } catch(e){
    console.error('openEditResByBookingId error:', e);
    showT('✗',_t('common').error,_t('res').openEditFailed);
  }
}

async function restoreBooking(bookingId){
  try {
    if(!confirm(_t('res').restoreConfirm)) return;
    var result = await apiRestoreBooking(bookingId);
    if(result.error){ showT('✗',_t('common').error,result.error); return; }
    showT('✓',_t('res').restored,_t('res').restoredMsg);
    renderMyReservations();
  } catch(e){ showT('✗',_t('common').error,_t('res').restoreFailed); }
}

async function openExtendBooking(bookingId){
  try {
    var booking = await _getBookingById(bookingId);
    if(!booking){ showT('✗',_t('common').error,_t('res').resNotFound); return; }

    var currentEnd = new Date(booking.end_date);
    var newEnd = new Date(currentEnd);
    newEnd.setDate(newEnd.getDate() + 1);

    var msg = _t('res').extendConfirm + ' ' + newEnd.getDate() + '. ' + (newEnd.getMonth()+1) + '. ' + newEnd.getFullYear() + '?';
    if(!confirm(msg)) return;

    var result = await apiExtendBooking(bookingId, newEnd.toISOString());
    if(result.error){
      showT('✗',_t('common').error, result.error);
      return;
    }

    showT('✓',_t('res').extended,_t('res').extendedMsg);
    renderMyReservations();
    if(_currentResId === bookingId) openResDetailById(bookingId);
  } catch(e){ console.error('openExtendBooking error:', e); showT('✗',_t('common').error,_t('res').extendFailed); }
}
