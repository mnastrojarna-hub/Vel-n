import { useState } from "react";

const C = {
  bg:"#dff0ec",black:"#0f1a14",dark:"#1a2e22",green:"#74FB71",gd:"#3dba3a",gdk:"#1a8a18",gp:"#e8ffe8",
  g100:"#f1faf7",g200:"#d4e8e0",g400:"#8aab99",g600:"#4a6357",red:"#ef4444",gold:"#f59e0b",blue:"#3b82f6",
  purple:"#8b5cf6",white:"#ffffff",shadow:"0 4px 20px rgba(15,26,20,.1)"
};
const ST={active:{l:"Aktivní",c:C.gdk,bg:"#dcfce7"},maintenance:{l:"V servisu",c:"#92400e",bg:"#fef3c7"},out_of_service:{l:"Vyřazena",c:"#991b1b",bg:"#fee2e2"},review:{l:"K revizi",c:C.purple,bg:"#ede9fe"}};

const MOTOS=[
  {id:"bmw",name:"BMW R 1200 GS Adventure",spz:"5P2 3456",km:42350,nextSvc:"2026-04-15",status:"active",branch:"Mezná",cost:18200},
  {id:"jawa",name:"Jawa RVM 500 Adventure",spz:"3J1 2233",km:18200,nextSvc:"2026-05-01",status:"active",branch:"Mezná",cost:8400},
  {id:"benelli",name:"Benelli TRK 702 X",spz:"2B4 7788",km:31400,nextSvc:"2026-03-10",status:"maintenance",branch:"Mezná",cost:24200},
  {id:"cfmoto",name:"CF MOTO 800 MT",spz:"6C2 1199",km:15800,nextSvc:"2026-06-20",status:"active",branch:"Mezná",cost:12100},
  {id:"niken",name:"Yamaha Niken GT",spz:"1Y3 5566",km:28900,nextSvc:"2026-03-28",status:"active",branch:"Mezná",cost:15300},
  {id:"ktm",name:"KTM 1290 Super Adv.",spz:"4K7 9900",km:52100,nextSvc:"2026-04-05",status:"active",branch:"Brno",cost:22000},
  {id:"tiger",name:"Triumph Tiger 1200",spz:"7T8 4411",km:67200,nextSvc:null,status:"out_of_service",branch:"Brno",cost:35000},
  {id:"versys",name:"Kawasaki Versys 650",spz:"8K1 6677",km:22700,nextSvc:"2026-05-15",status:"active",branch:"Brno",cost:9800},
];
const INVENTORY=[
  {id:1,name:"Helma Shoei GT-Air II",sku:"HLM-001",stock:8,min:4,cat:"ochranné",price:12500,supplier:"Moto Plus s.r.o."},
  {id:2,name:"Bunda Alpinestars Andes",sku:"BUN-001",stock:2,min:4,cat:"ochranné",price:8200,supplier:"Moto Plus s.r.o."},
  {id:3,name:"Motorový olej Motul 10W-40",sku:"OIL-001",stock:24,min:10,cat:"spotřební",price:450,supplier:"AD Partner"},
  {id:4,name:"Brzdové destičky univerzál",sku:"BRK-001",stock:6,min:8,cat:"spotřební",price:890,supplier:"AD Partner"},
  {id:5,name:"Řetězová sada 520",sku:"RET-001",stock:3,min:4,cat:"spotřební",price:3200,supplier:"MotoDíly CZ"},
  {id:6,name:"Pneumatiky Michelin Road 6",sku:"PNE-001",stock:4,min:4,cat:"spotřební",price:4800,supplier:"Pneumatiky.cz"},
];
const DOCS=[
  {id:1,type:"VOP",name:"Všeobecné obchodní podmínky v2.4",updated:"2026-02-15",status:"active"},
  {id:2,type:"Smlouva",name:"Šablona nájemní smlouvy",updated:"2026-01-20",status:"active"},
  {id:3,type:"Faktura",name:"Šablona faktury",updated:"2026-02-28",status:"active"},
  {id:4,type:"Protokol",name:"Předávací protokol motorky",updated:"2026-02-10",status:"active"},
  {id:5,type:"GDPR",name:"Souhlas se zpracováním údajů",updated:"2025-12-01",status:"review"},
  {id:6,type:"Pojistka",name:"Pojistné podmínky pronájmu",updated:"2026-01-05",status:"active"},
];
const MSGS=[
  {id:1,from:"Jan Novák",ch:"web",subj:"Dotaz na prodloužení",time:"dnes 14:32",unread:true,msgs:[{s:"c",t:"Dobrý den, chtěl bych prodloužit BMW o 2 dny?",time:"14:32"},{s:"a",t:"Ano, motorka je volná. Nová cena 25 248 Kč.",time:"14:45"},{s:"c",t:"Super, beru!",time:"14:50"}]},
  {id:2,from:"Petra D.",ch:"whatsapp",subj:"Problém s helmetem",time:"dnes 11:15",unread:true,msgs:[{s:"c",t:"Helma mi nesedí, můžu vyměnit?",time:"11:15"}]},
  {id:3,from:"Martin Šimek",ch:"email",subj:"Potvrzení platby",time:"včera 19:00",unread:false,msgs:[{s:"c",t:"Posílám potvrzení platby. Č. transakce: 2026030401234",time:"19:00"},{s:"a",t:"Děkujeme, platbu evidujeme!",time:"19:30"}]},
  {id:4,from:"Autoservis Havel",ch:"email",subj:"Benelli TRK hotova",time:"dnes 09:00",unread:true,msgs:[{s:"c",t:"Benelli TRK opravená, vyzvedněte si ji. Fa 24 200 Kč.",time:"09:00"}]},
  {id:5,from:"Eva K.",ch:"instagram",subj:"Fotky z výletu",time:"včera 16:45",unread:false,msgs:[{s:"c",t:"Posílám fotky z výletu s Nikenem! 🏍️",time:"16:45"},{s:"a",t:"Smíme fotky použít na IG?",time:"17:00"}]},
];

// UI
const Badge=({l,c,bg})=><span style={{display:"inline-block",padding:"3px 10px",borderRadius:50,fontSize:10,fontWeight:800,color:c,background:bg,textTransform:"uppercase"}}>{l}</span>;
const Btn=({children,green,outline,onClick,s})=><button onClick={onClick} style={{padding:"8px 18px",borderRadius:50,fontSize:11,fontWeight:800,border:outline?`2px solid ${C.green}`:"none",background:green?C.green:outline?"transparent":C.g100,color:green?"#fff":outline?C.gd:C.g600,cursor:"pointer",textTransform:"uppercase",letterSpacing:.4,...s}}>{children}</button>;
const Cd=({children,s})=><div style={{background:C.white,borderRadius:18,padding:18,boxShadow:C.shadow,...s}}>{children}</div>;
const Stat=({icon,label,value,sub,color=C.gdk})=><Cd s={{flex:1,minWidth:130,position:"relative",overflow:"hidden"}}><div style={{position:"absolute",top:-8,right:-8,fontSize:42,opacity:.06}}>{icon}</div><div style={{fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{label}</div><div style={{fontSize:20,fontWeight:900,color}}>{value}</div>{sub&&<div style={{fontSize:10,color:C.g400,marginTop:3}}>{sub}</div>}</Cd>;
const Tabs=({tabs,a,set})=><div style={{display:"flex",gap:2,marginBottom:14,borderBottom:`2px solid ${C.g200}`}}>{tabs.map(t=><button key={t} onClick={()=>set(t)} style={{padding:"7px 16px",fontSize:11,fontWeight:a===t?800:600,color:a===t?C.gdk:C.g400,background:"transparent",border:"none",borderBottom:a===t?`3px solid ${C.green}`:"3px solid transparent",cursor:"pointer",fontFamily:"inherit",textTransform:"uppercase"}}>{t}</button>)}</div>;
const TH=({children})=><th style={{padding:"8px 12px",textAlign:"left",fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase"}}>{children}</th>;
const TD=({children,bold,color,mono})=><td style={{padding:"8px 12px",fontSize:12,fontWeight:bold?700:500,color:color||C.black,fontFamily:mono?"monospace":"inherit"}}>{children}</td>;
const ExportBar=()=><div style={{display:"flex",gap:6,marginTop:14,paddingTop:10,borderTop:`1px solid ${C.g200}`}}><span style={{fontSize:10,fontWeight:700,color:C.g400,lineHeight:"28px"}}>EXPORT:</span>{["PDF","XLSX","CSV"].map(f=><Btn key={f} s={{padding:"3px 12px",fontSize:9}}>{f}</Btn>)}</div>;

const NAV=[{id:"acct",l:"Účetnictví",i:"📒"},{id:"docs",l:"Dokumenty",i:"📄"},{id:"inv",l:"Sklady",i:"📦"},{id:"svc",l:"Servis",i:"🔧"},{id:"msg",l:"Zprávy",i:"💬"}];

// ACCOUNTING
const Acct=()=>{const[tab,sTab]=useState("Výsledovka");return <div>
  <div style={{display:"flex",gap:12,marginBottom:18,flexWrap:"wrap"}}><Stat icon="📒" label="Rozvaha" value="12.4M Kč" sub="aktiva celkem"/><Stat icon="📊" label="Výsledovka" value="+1.2M Kč" color={C.gdk}/><Stat icon="🏛️" label="DPH k odvodu" value="187 400 Kč" color={C.gold}/><Stat icon="📋" label="Daň z příjmu" value="342 000 Kč" color={C.blue}/></div>
  <Tabs tabs={["Výsledovka","Rozvaha","Daně"]} a={tab} set={sTab}/>
  {tab==="Výsledovka"&&<Cd>{[["Tržby z pronájmu","2 406 000 Kč",C.gdk],["Tržby příslušenství","184 000 Kč",C.gdk],["Náklady servis","-487 000 Kč",C.red],["Pojištění flotily","-312 000 Kč",C.red],["Odpisy","-420 000 Kč",C.red],["Mzdy","-648 000 Kč",C.red],["Provozní náklady","-284 000 Kč",C.red]].map(([l,v,c],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${C.g200}`}}><span style={{fontSize:12,fontWeight:600,color:C.g600}}>{l}</span><span style={{fontSize:12,fontWeight:800,color:c}}>{v}</span></div>)}<div style={{display:"flex",justifyContent:"space-between",padding:"12px 0 0"}}><span style={{fontSize:14,fontWeight:900}}>Hospodářský výsledek</span><span style={{fontSize:14,fontWeight:900,color:C.gdk}}>+439 000 Kč</span></div><ExportBar/></Cd>}
  {tab==="Rozvaha"&&<Cd><div style={{fontSize:10,fontWeight:800,color:C.gdk,textTransform:"uppercase",marginBottom:6}}>Aktiva</div>{[["Dlouhodobý majetek","8 200 000 Kč"],["Zásoby","420 000 Kč"],["Pohledávky","185 000 Kč"],["Finanční majetek","3 615 000 Kč"]].map(([l,v],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",fontSize:12}}><span style={{fontWeight:600,color:C.g600}}>{l}</span><span style={{fontWeight:800}}>{v}</span></div>)}<div style={{borderTop:`2px solid ${C.green}`,padding:"8px 0",margin:"8px 0",display:"flex",justifyContent:"space-between"}}><span style={{fontWeight:900}}>Celkem</span><span style={{fontWeight:900,color:C.gdk}}>12 420 000 Kč</span></div><div style={{fontSize:10,fontWeight:800,color:C.blue,textTransform:"uppercase",marginTop:10,marginBottom:6}}>Pasiva</div>{[["Vlastní kapitál","7 800 000 Kč"],["Výsledek hospodaření","439 000 Kč"],["Závazky","4 181 000 Kč"]].map(([l,v],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",fontSize:12}}><span style={{fontWeight:600,color:C.g600}}>{l}</span><span style={{fontWeight:800}}>{v}</span></div>)}<ExportBar/></Cd>}
  {tab==="Daně"&&<div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>{[["Přiznání k DPH","Kvartální","📋"],["Daň z příjmu PO","Roční 2025","📊"],["Kontrolní hlášení","Měsíční §101c","📑"]].map(([t,s,i],idx)=><Cd key={idx} s={{textAlign:"center"}}><div style={{fontSize:32,marginBottom:6}}>{i}</div><div style={{fontSize:13,fontWeight:800,marginBottom:3}}>{t}</div><div style={{fontSize:10,color:C.g400,marginBottom:12}}>{s}</div><Btn green s={{width:"100%",justifyContent:"center"}}>Generovat</Btn></Cd>)}</div>}
</div>};

// DOCUMENTS
const DocsPage=()=>{const[tab,sTab]=useState("Šablony");return <div>
  <Tabs tabs={["Šablony","Generátor"]} a={tab} set={sTab}/>
  {tab==="Šablony"&&<><div style={{display:"flex",gap:6,marginBottom:14}}><Btn green>+ Nový</Btn><Btn outline>📥 Import</Btn></div><Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Typ</TH><TH>Název</TH><TH>Úprava</TH><TH>Stav</TH><TH>Akce</TH></tr></thead><tbody>{DOCS.map(d=><tr key={d.id} style={{borderBottom:`1px solid ${C.g200}`}}><TD><Badge l={d.type} c={C.gdk} bg="#dcfce7"/></TD><TD bold>{d.name}</TD><TD>{d.updated}</TD><TD><Badge {...(ST[d.status]||{l:d.status,c:C.g400,bg:C.g100})}/></TD><TD><div style={{display:"flex",gap:4}}><Btn s={{padding:"3px 10px",fontSize:9}}>✏️</Btn><Btn s={{padding:"3px 10px",fontSize:9}}>📤</Btn></div></TD></tr>)}</tbody></table></Cd></>}
  {tab==="Generátor"&&<div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>{[["Faktura","Auto po platbě","🧾"],["Smlouva","Z rezervace","📝"],["Předávací protokol","S fotodokumentací","📋"],["Dobropis","Storno/refund","💸"]].map(([t,s,i],idx)=><Cd key={idx} s={{textAlign:"center"}}><div style={{fontSize:30,marginBottom:6}}>{i}</div><div style={{fontSize:12,fontWeight:800,marginBottom:3}}>{t}</div><div style={{fontSize:10,color:C.g400,marginBottom:12}}>{s}</div><Btn green s={{width:"100%",justifyContent:"center"}}>Generovat</Btn></Cd>)}</div>}
</div>};

// INVENTORY
const Inv=()=><div>
  <div style={{display:"flex",gap:6,marginBottom:14}}><Btn green>+ Přidat</Btn><Btn outline>🛒 Objednat chybějící</Btn></div>
  <Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>SKU</TH><TH>Název</TH><TH>Kat.</TH><TH>Sklad</TH><TH>Min</TH><TH>Stav</TH><TH>Cena/ks</TH><TH>Dodavatel</TH></tr></thead><tbody>{INVENTORY.map(i=>{const lo=i.stock<=i.min;return <tr key={i.id} style={{borderBottom:`1px solid ${C.g200}`,background:lo?"#fffbeb":"transparent"}}><TD mono color={C.g400}>{i.sku}</TD><TD bold>{i.name}</TD><TD>{i.cat}</TD><TD bold color={lo?"#92400e":C.gdk} mono>{i.stock}</TD><TD mono>{i.min}</TD><TD>{lo?<Badge l="Doplnit!" c="#92400e" bg="#fef3c7"/>:<Badge l="OK" c={C.gdk} bg="#dcfce7"/>}</TD><TD mono color={C.gd}>{i.price.toLocaleString()} Kč</TD><TD>{i.supplier}</TD></tr>})}</tbody></table></Cd>
</div>;

// SERVICE
const Svc=()=>{const items=MOTOS.filter(m=>m.nextSvc).sort((a,b)=>new Date(a.nextSvc)-new Date(b.nextSvc));return <div>
  <div style={{display:"flex",gap:12,marginBottom:18,flexWrap:"wrap"}}><Stat icon="🔧" label="V servisu" value="1" sub="Benelli TRK" color={C.gold}/><Stat icon="📅" label="Naplánované" value="6" sub="příštích 90 dní" color={C.blue}/><Stat icon="💸" label="Náklady rok" value="187k Kč" color={C.purple}/></div>
  <div style={{marginBottom:14}}><Btn green>+ Naplánovat servis</Btn></div>
  <Cd>{items.map(m=>{const d=Math.round((new Date(m.nextSvc)-new Date())/864e5),u=d<14;return <div key={m.id} style={{display:"flex",alignItems:"center",padding:"10px",background:u?"#fef3c7":C.g100,borderRadius:12,marginBottom:6,borderLeft:`4px solid ${u?C.gold:C.g200}`}}><div style={{flex:1}}><div style={{fontWeight:800,fontSize:13}}>{m.name}</div><div style={{color:C.g400,fontSize:10}}>{m.spz} · {m.km.toLocaleString()} km</div></div><div style={{textAlign:"right"}}><div style={{fontWeight:800,color:u?"#92400e":C.g600,fontSize:12}}>{m.nextSvc}</div><div style={{color:u?"#92400e":C.g400,fontSize:10}}>{d>0?`za ${d} dní`:"DNES!"}</div></div></div>})}</Cd>
</div>};

// MESSAGES
const Msg=()=>{const[sel,sSel]=useState(MSGS[0]);const[reply,sReply]=useState("");return <div style={{display:"flex",gap:14,height:"calc(100vh - 160px)"}}>
  <Cd s={{width:260,padding:0,overflow:"hidden",display:"flex",flexDirection:"column"}}><div style={{padding:"10px 12px",borderBottom:`1px solid ${C.g200}`,fontSize:11,fontWeight:800,color:C.g400}}>KONVERZACE ({MSGS.length})</div><div style={{flex:1,overflowY:"auto"}}>{MSGS.map(m=><div key={m.id} onClick={()=>sSel(m)} style={{padding:"8px 12px",background:sel.id===m.id?C.gp:"transparent",borderLeft:sel.id===m.id?`3px solid ${C.green}`:"3px solid transparent",cursor:"pointer",borderBottom:`1px solid ${C.g200}`}}><div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontSize:11,fontWeight:m.unread?800:500}}>{m.from}</span><span style={{fontSize:9,color:C.g400}}>{m.time}</span></div><div style={{fontSize:10,color:C.g600,marginTop:2}}>{m.subj}</div><div style={{display:"flex",gap:3,marginTop:3}}><span style={{fontSize:8,padding:"1px 5px",borderRadius:50,background:C.g100,color:C.g400,fontWeight:700}}>{m.ch}</span>{m.unread&&<span style={{fontSize:8,padding:"1px 5px",borderRadius:50,background:C.green,color:"#fff",fontWeight:700}}>Nové</span>}</div></div>)}</div></Cd>
  <Cd s={{flex:1,display:"flex",flexDirection:"column",padding:0}}>
    <div style={{padding:"12px 18px",borderBottom:`1px solid ${C.g200}`,display:"flex",justifyContent:"space-between"}}><div><div style={{fontSize:14,fontWeight:800}}>{sel.from}</div><div style={{fontSize:10,color:C.g400}}>{sel.subj} · {sel.ch}</div></div></div>
    <div style={{flex:1,overflowY:"auto",padding:16}}>{sel.msgs.map((m,i)=><div key={i} style={{display:"flex",justifyContent:m.s==="a"?"flex-end":"flex-start",marginBottom:10}}><div style={{maxWidth:"70%",padding:"8px 12px",borderRadius:m.s==="a"?"14px 14px 4px 14px":"14px 14px 14px 4px",background:m.s==="a"?C.gp:C.g100,fontSize:12,lineHeight:1.5}}><div style={{fontSize:9,fontWeight:700,color:m.s==="a"?C.gdk:C.g400,marginBottom:3}}>{m.s==="a"?"Vy":sel.from} · {m.time}</div>{m.t}</div></div>)}</div>
    <div style={{padding:"10px 16px",borderTop:`1px solid ${C.g200}`,display:"flex",gap:6}}><input value={reply} onChange={e=>sReply(e.target.value)} placeholder="Napište odpověď…" style={{flex:1,padding:"8px 14px",borderRadius:50,border:`2px solid ${C.g200}`,fontSize:12,outline:"none",fontFamily:"inherit"}}/><Btn green onClick={()=>{if(reply.trim()){sel.msgs.push({s:"a",t:reply,time:"teď"});sReply("");sSel({...sel})}}}>Odeslat</Btn></div>
  </Cd>
</div>};

const VIEWS={acct:Acct,docs:DocsPage,inv:Inv,svc:Svc,msg:Msg};

export default function Velin(){
  const[v,sV]=useState("acct");const[col,sCol]=useState(false);
  const View=VIEWS[v]||Acct;const label=NAV.find(n=>n.id===v)?.l||"Účetnictví";const unr=MSGS.filter(m=>m.unread).length;
  return <div style={{display:"flex",height:"100vh",background:C.bg,fontFamily:"'Montserrat',sans-serif",color:C.black,overflow:"hidden"}}>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
    <div style={{width:col?56:210,background:C.dark,display:"flex",flexDirection:"column",transition:"width .3s",flexShrink:0,overflow:"hidden"}}>
      <div style={{padding:col?"14px 6px":"16px",borderBottom:"1px solid rgba(255,255,255,.08)",display:"flex",alignItems:"center",gap:10,cursor:"pointer"}} onClick={()=>sCol(!col)}><div style={{width:36,height:36,borderRadius:18,background:"rgba(116,251,113,.15)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:900,color:C.green}}>MG</div>{!col&&<div><div style={{fontSize:14,fontWeight:900,color:C.white}}>MOTOGO24</div><div style={{fontSize:8,color:"rgba(255,255,255,.35)",letterSpacing:3,textTransform:"uppercase"}}>Velín · Část 2/3</div></div>}</div>
      <nav style={{flex:1,padding:"8px 4px"}}>{NAV.map(n=>{const a=v===n.id;return <button key={n.id} onClick={()=>sV(n.id)} style={{width:"100%",display:"flex",alignItems:"center",gap:8,padding:col?"8px 0":"8px 12px",justifyContent:col?"center":"flex-start",borderRadius:12,border:"none",cursor:"pointer",marginBottom:1,fontSize:12,fontWeight:a?800:600,background:a?"rgba(116,251,113,.12)":"transparent",color:a?C.green:"rgba(255,255,255,.5)",borderLeft:a?`3px solid ${C.green}`:"3px solid transparent",fontFamily:"inherit"}}><span style={{fontSize:15}}>{n.i}</span>{!col&&<span style={{flex:1,textAlign:"left"}}>{n.l}</span>}{!col&&n.id==="msg"&&unr>0&&<span style={{background:C.red,color:"#fff",fontSize:8,fontWeight:900,padding:"1px 6px",borderRadius:50}}>{unr}</span>}</button>})}</nav>
    </div>
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{padding:"10px 24px",borderBottom:`1px solid ${C.g200}`,display:"flex",alignItems:"center",justifyContent:"space-between",background:C.white}}><h1 style={{margin:0,fontSize:18,fontWeight:900}}>{label}</h1><div style={{fontSize:11,color:C.g400,fontWeight:600}}>{new Date().toLocaleDateString("cs-CZ",{weekday:"long",day:"numeric",month:"long"})}</div></div>
      <div style={{flex:1,overflowY:"auto",padding:20}}><View/></div>
    </div>
  </div>;
}
