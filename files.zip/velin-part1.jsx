import { useState } from "react";

const C = {
  bg:"#dff0ec",black:"#0f1a14",dark:"#1a2e22",green:"#74FB71",gd:"#3dba3a",gdk:"#1a8a18",gp:"#e8ffe8",
  g100:"#f1faf7",g200:"#d4e8e0",g400:"#8aab99",g600:"#4a6357",red:"#ef4444",gold:"#f59e0b",blue:"#3b82f6",
  purple:"#8b5cf6",white:"#ffffff",shadow:"0 4px 20px rgba(15,26,20,.1)"
};
const ST={active:{l:"Aktivní",c:C.gdk,bg:"#dcfce7"},maintenance:{l:"V servisu",c:"#92400e",bg:"#fef3c7"},out_of_service:{l:"Vyřazena",c:"#991b1b",bg:"#fee2e2"},pending:{l:"Čekající",c:"#92400e",bg:"#fef3c7"},completed:{l:"Dokončena",c:C.blue,bg:"#dbeafe"},cancelled:{l:"Zrušena",c:"#991b1b",bg:"#fee2e2"}};

const MOTOS=[
  {id:"bmw",name:"BMW R 1200 GS Adventure",cat:"cestovní",status:"active",branch:"Mezná",km:42350,spz:"5P2 3456",price:4208,nextSvc:"2026-04-15",util:78,rev:134656,cost:18200,vin:"WB10408J5GZS12345",year:2023,insurance:"Kooperativa",stkEnd:"2026-09-15"},
  {id:"jawa",name:"Jawa RVM 500 Adventure",cat:"cestovní",status:"active",branch:"Mezná",km:18200,spz:"3J1 2233",price:1986,nextSvc:"2026-05-01",util:65,rev:63552,cost:8400,vin:"TMBRF61Z5J1234567",year:2024,insurance:"Generali",stkEnd:"2027-01-10"},
  {id:"benelli",name:"Benelli TRK 702 X",cat:"cestovní",status:"maintenance",branch:"Mezná",km:31400,spz:"2B4 7788",price:2951,nextSvc:"2026-03-10",util:0,rev:47216,cost:24200,vin:"ZBMRF61Z9K9876543",year:2024,insurance:"ČSOB",stkEnd:"2026-06-22"},
  {id:"cfmoto",name:"CF MOTO 800 MT",cat:"cestovní",status:"active",branch:"Mezná",km:15800,spz:"6C2 1199",price:3941,nextSvc:"2026-06-20",util:82,rev:126112,cost:12100,vin:"LCELDM101R0001234",year:2025,insurance:"Allianz",stkEnd:"2027-05-01"},
  {id:"niken",name:"Yamaha Niken GT",cat:"special",status:"active",branch:"Mezná",km:28900,spz:"1Y3 5566",price:3931,nextSvc:"2026-03-28",util:71,rev:110068,cost:15300,vin:"JYARN70E0RA012345",year:2023,insurance:"Kooperativa",stkEnd:"2026-11-30"},
  {id:"ktm",name:"KTM 1290 Super Adv.",cat:"adventure",status:"active",branch:"Brno",km:52100,spz:"4K7 9900",price:4500,nextSvc:"2026-04-05",util:88,rev:162000,cost:22000,vin:"VBKV39400NM901234",year:2022,insurance:"Generali",stkEnd:"2026-08-05"},
  {id:"tiger",name:"Triumph Tiger 1200",cat:"adventure",status:"out_of_service",branch:"Brno",km:67200,spz:"7T8 4411",price:4100,nextSvc:null,util:0,rev:0,cost:35000,vin:"SMTD40HL7MT123456",year:2021,insurance:"Kooperativa",stkEnd:"2026-03-15"},
  {id:"versys",name:"Kawasaki Versys 650",cat:"naked",status:"active",branch:"Brno",km:22700,spz:"8K1 6677",price:2200,nextSvc:"2026-05-15",util:59,rev:52800,cost:9800,vin:"JKAER650CDA012345",year:2024,insurance:"Allianz",stkEnd:"2027-04-18"},
];
const BK=[
  {id:"RES-001",cust:"Jan Novák",cid:"c1",moto:"BMW R 1200 GS",mid:"bmw",from:"2026-03-01",to:"2026-03-04",status:"active",total:16832,paid:true,extras:["Helma","GPS"],note:"VIP, 3. pronájem"},
  {id:"RES-002",cust:"Petra Dvořáková",cid:"c2",moto:"CF MOTO 800 MT",mid:"cfmoto",from:"2026-03-02",to:"2026-03-05",status:"active",total:15764,paid:true,extras:["Kufry"],note:""},
  {id:"RES-003",cust:"Martin Šimek",cid:"c3",moto:"KTM 1290 SA",mid:"ktm",from:"2026-03-05",to:"2026-03-08",status:"pending",total:18000,paid:false,extras:["Helma","Bunda"],note:"Čeká platbu"},
  {id:"RES-004",cust:"Eva Králová",cid:"c4",moto:"Yamaha Niken GT",mid:"niken",from:"2026-03-03",to:"2026-03-06",status:"active",total:15724,paid:true,extras:[],note:"1. pronájem"},
  {id:"RES-005",cust:"Tomáš Beneš",cid:"c5",moto:"Kawasaki Versys",mid:"versys",from:"2026-03-10",to:"2026-03-12",status:"pending",total:4400,paid:false,extras:["GPS"],note:""},
  {id:"RES-006",cust:"Jan Novák",cid:"c1",moto:"KTM 1290 SA",mid:"ktm",from:"2026-02-10",to:"2026-02-14",status:"completed",total:18000,paid:true,extras:[],note:"OK"},
  {id:"RES-007",cust:"Lucie P.",cid:"c6",moto:"Jawa RVM 500",mid:"jawa",from:"2026-02-20",to:"2026-02-22",status:"completed",total:3972,paid:true,extras:[],note:""},
];
const CU=[
  {id:"c1",name:"Jan Novák",email:"jan@email.cz",phone:"+420 601 234 567",license:"A",licNum:"AB123456",licExp:"2028-06-30",city:"Praha",bk:3,spent:47456,score:95,vip:true,reg:"2025-08-12"},
  {id:"c2",name:"Petra Dvořáková",email:"petra@seznam.cz",phone:"+420 602 345 678",license:"A2",licNum:"CD789012",licExp:"2027-12-15",city:"Brno",bk:1,spent:15764,score:80,vip:false,reg:"2026-01-20"},
  {id:"c3",name:"Martin Šimek",email:"m.simek@firma.cz",phone:"+420 603 456 789",license:"A",licNum:"EF345678",licExp:"2029-03-01",city:"Jihlava",bk:1,spent:0,score:70,vip:false,reg:"2026-02-28"},
  {id:"c4",name:"Eva Králová",email:"eva.k@email.cz",phone:"+420 604 567 890",license:"A2",licNum:"GH901234",licExp:"2028-09-20",city:"Pelhřimov",bk:1,spent:15724,score:85,vip:false,reg:"2026-02-15"},
  {id:"c5",name:"Tomáš Beneš",email:"tomas@gmail.com",phone:"+420 605 678 901",license:"A",licNum:"IJ567890",licExp:"2030-01-10",city:"Olomouc",bk:1,spent:0,score:75,vip:false,reg:"2026-03-01"},
  {id:"c6",name:"Lucie Procházková",email:"lucie@email.cz",phone:"+420 606 789 012",license:"A1",licNum:"KL123789",licExp:"2027-04-25",city:"Havl. Brod",bk:1,spent:3972,score:90,vip:false,reg:"2025-12-05"},
];
const MO=["Led","Úno","Bře","Dub","Kvě","Čvn","Čvc","Srp","Zář","Říj","Lis","Pro"];
const REV=[82,71,145,198,267,312,345,356,289,178,95,68];
const COST=[48,42,72,89,112,134,148,152,124,88,52,38];

// UI
const Badge=({l,c,bg})=><span style={{display:"inline-block",padding:"3px 10px",borderRadius:50,fontSize:10,fontWeight:800,color:c,background:bg,textTransform:"uppercase"}}>{l}</span>;
const Btn=({children,green,outline,red,onClick,s})=><button onClick={onClick} style={{padding:"8px 18px",borderRadius:50,fontSize:11,fontWeight:800,border:outline?`2px solid ${C.green}`:red?`2px solid ${C.red}`:"none",background:green?C.green:red?"transparent":outline?"transparent":C.g100,color:green?"#fff":red?C.red:outline?C.gd:C.g600,cursor:"pointer",textTransform:"uppercase",letterSpacing:.4,...s}}>{children}</button>;
const Cd=({children,s,onClick})=><div onClick={onClick} style={{background:C.white,borderRadius:18,padding:18,boxShadow:C.shadow,cursor:onClick?"pointer":"default",...s}}>{children}</div>;
const Stat=({icon,label,value,sub,color=C.gdk})=><Cd s={{flex:1,minWidth:130,position:"relative",overflow:"hidden"}}><div style={{position:"absolute",top:-8,right:-8,fontSize:42,opacity:.06}}>{icon}</div><div style={{fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{label}</div><div style={{fontSize:20,fontWeight:900,color}}>{value}</div>{sub&&<div style={{fontSize:10,color:C.g400,marginTop:3}}>{sub}</div>}</Cd>;
const Chart=({data,color=C.gdk,h=50})=>{const mx=Math.max(...data),mn=Math.min(...data),r=mx-mn||1,w=100/data.length;return <svg viewBox={`0 0 100 ${h}`} style={{width:"100%",height:h}} preserveAspectRatio="none"><polyline fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" points={data.map((v,i)=>`${i*w+w/2},${h-((v-mn)/r)*(h-6)-3}`).join(" ")}/></svg>};
const Field=({l,v})=><div style={{marginBottom:10}}><div style={{fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase",marginBottom:2}}>{l}</div><div style={{fontSize:13,fontWeight:600,padding:"6px 10px",background:C.g100,borderRadius:8}}>{v||"—"}</div></div>;
const Back=({onClick})=><button onClick={onClick} style={{padding:"5px 14px",borderRadius:50,border:`2px solid ${C.g200}`,background:C.white,color:C.g600,cursor:"pointer",fontSize:11,fontWeight:700,marginBottom:14,fontFamily:"inherit"}}>← Zpět</button>;
const Tabs=({tabs,a,set})=><div style={{display:"flex",gap:2,marginBottom:14,borderBottom:`2px solid ${C.g200}`}}>{tabs.map(t=><button key={t} onClick={()=>set(t)} style={{padding:"7px 16px",fontSize:11,fontWeight:a===t?800:600,color:a===t?C.gdk:C.g400,background:"transparent",border:"none",borderBottom:a===t?`3px solid ${C.green}`:"3px solid transparent",cursor:"pointer",fontFamily:"inherit",textTransform:"uppercase"}}>{t}</button>)}</div>;
const TH=({children})=><th style={{padding:"8px 12px",textAlign:"left",fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase"}}>{children}</th>;
const TD=({children,bold,color,mono})=><td style={{padding:"8px 12px",fontSize:12,fontWeight:bold?700:500,color:color||C.black,fontFamily:mono?"monospace":"inherit"}}>{children}</td>;

const NAV=[{id:"dash",l:"Velín",i:"⚡"},{id:"fleet",l:"Flotila",i:"🏍️"},{id:"book",l:"Rezervace",i:"📅"},{id:"crm",l:"Zákazníci",i:"👥"},{id:"fin",l:"Finance",i:"💰"}];

// PAGES
const Dash=({go})=>{const am=MOTOS.filter(m=>m.status==="active").length,avgU=Math.round(MOTOS.filter(m=>m.status==="active").reduce((s,m)=>s+m.util,0)/am);return <div>
  <div style={{display:"flex",gap:12,marginBottom:18,flexWrap:"wrap"}}><Stat icon="🏍️" label="Aktivní motorky" value={`${am}/${MOTOS.length}`} sub={`Ø ${avgU}%`}/><Stat icon="💰" label="Tržby měsíc" value={`${Math.round(MOTOS.reduce((s,m)=>s+m.rev,0)/1000)}k`} color={C.gold}/><Stat icon="📅" label="Akt/Čeká" value={`${BK.filter(b=>b.status==="active").length}/${BK.filter(b=>b.status==="pending").length}`} color={C.blue}/><Stat icon="👥" label="Zákazníků" value={CU.length} color={C.purple}/></div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>📈 Tržby (tis. Kč)</div><Chart data={REV} h={60}/><div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>{MO.map((m,i)=><span key={i} style={{fontSize:7,color:C.g400,fontWeight:700}}>{m}</span>)}</div></Cd>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>🏍️ Flotila</div>{MOTOS.slice(0,5).map(m=><div key={m.id} onClick={()=>go("fleet-d",m.id)} style={{display:"flex",alignItems:"center",padding:"5px 8px",background:C.g100,borderRadius:10,marginBottom:4,fontSize:11,cursor:"pointer"}}><span style={{flex:1,fontWeight:700}}>{m.name}</span><Badge {...ST[m.status]}/></div>)}</Cd>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>📅 Rezervace</div>{BK.filter(b=>b.status==="active"||b.status==="pending").slice(0,4).map(b=><div key={b.id} onClick={()=>go("book-d",b.id)} style={{display:"flex",padding:"6px 8px",background:C.g100,borderRadius:10,marginBottom:4,fontSize:11,cursor:"pointer"}}><div style={{flex:1}}><div style={{fontWeight:700}}>{b.cust}</div><div style={{color:C.g400,fontSize:10}}>{b.moto}</div></div><div style={{textAlign:"right"}}><div style={{fontWeight:800,color:C.gd}}>{b.total.toLocaleString()} Kč</div><Badge {...ST[b.status]}/></div></div>)}</Cd>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>👥 Noví zákazníci</div>{CU.slice(0,4).map(c=><div key={c.id} onClick={()=>go("crm-d",c.id)} style={{display:"flex",alignItems:"center",padding:"5px 8px",background:C.g100,borderRadius:10,marginBottom:4,fontSize:11,cursor:"pointer"}}><div style={{width:24,height:24,borderRadius:12,background:C.dark,color:C.white,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,marginRight:8}}>{c.name.charAt(0)}</div><div style={{flex:1}}><div style={{fontWeight:700}}>{c.name}</div><div style={{color:C.g400,fontSize:10}}>{c.city}</div></div>{c.vip&&<Badge l="VIP" c={C.gdk} bg="#dcfce7"/>}</div>)}</Cd>
  </div>
</div>};

const Fleet=({go})=>{const[f,sF]=useState("all");const d=f==="all"?MOTOS:MOTOS.filter(m=>m.status===f);return <div>
  <div style={{display:"flex",gap:6,marginBottom:14,flexWrap:"wrap"}}>{[["all","Vše"],["active","Aktivní"],["maintenance","Servis"],["out_of_service","Vyřazené"]].map(([v,l])=><button key={v} onClick={()=>sF(v)} style={{padding:"6px 14px",borderRadius:50,fontSize:10,fontWeight:800,border:`2px solid ${f===v?C.green:C.g200}`,background:f===v?C.green:C.white,color:f===v?"#fff":C.g600,cursor:"pointer",textTransform:"uppercase"}}>{l}</button>)}<div style={{flex:1}}/><Btn green>+ Přidat</Btn></div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>{d.map(m=><Cd key={m.id} onClick={()=>go("fleet-d",m.id)} s={{position:"relative",cursor:"pointer"}}><div style={{position:"absolute",top:14,right:14}}><Badge {...ST[m.status]}/></div><div style={{fontSize:14,fontWeight:900,marginBottom:2}}>{m.name}</div><div style={{fontSize:10,color:C.g400,fontWeight:600,marginBottom:12}}>{m.branch} · {m.spz} · {m.cat}</div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:6}}>{[["Km",m.km.toLocaleString(),C.black],["Kč/den",m.price.toLocaleString(),C.gd],["Využití",m.util+"%",m.util>70?C.gdk:C.gold],["Zisk",(m.rev-m.cost>0?"+":"")+Math.round((m.rev-m.cost)/1000)+"k",m.rev-m.cost>0?C.gdk:C.red]].map(([l,v,c],i)=><div key={i}><div style={{fontSize:8,color:C.g400,fontWeight:700,textTransform:"uppercase"}}>{l}</div><div style={{fontSize:13,fontWeight:800,color:c}}>{v}</div></div>)}</div></Cd>)}</div>
</div>};

const FleetD=({id,go})=>{const m=MOTOS.find(x=>x.id===id);const[tab,sTab]=useState("Info");if(!m)return<div>Nenalezeno</div>;const bks=BK.filter(b=>b.mid===id);return <div><Back onClick={()=>go("fleet")}/>
  <div style={{display:"flex",gap:16}}>
    <Cd s={{flex:2}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:14}}><div><div style={{fontSize:20,fontWeight:900}}>{m.name}</div><div style={{fontSize:12,color:C.g400}}>{m.branch} · {m.cat}</div></div><Badge {...ST[m.status]}/></div>
      <Tabs tabs={["Info","Rezervace","Servis"]} a={tab} set={sTab}/>
      {tab==="Info"&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}><Field l="SPZ" v={m.spz}/><Field l="VIN" v={m.vin}/><Field l="Rok" v={m.year}/><Field l="Km" v={m.km.toLocaleString()}/><Field l="Cena/den" v={m.price.toLocaleString()+" Kč"}/><Field l="Pojišťovna" v={m.insurance}/><Field l="STK do" v={m.stkEnd}/><Field l="Servis" v={m.nextSvc||"—"}/></div>}
      {tab==="Rezervace"&&<div>{bks.length===0?<div style={{color:C.g400,padding:16,textAlign:"center"}}>Žádné</div>:bks.map(b=><div key={b.id} onClick={()=>go("book-d",b.id)} style={{display:"flex",padding:"8px",background:C.g100,borderRadius:10,marginBottom:6,cursor:"pointer"}}><div style={{flex:1}}><div style={{fontWeight:700,fontSize:12}}>{b.cust}</div><div style={{fontSize:10,color:C.g400}}>{b.from}→{b.to}</div></div><div style={{textAlign:"right"}}><div style={{fontWeight:800,color:C.gd,fontSize:12}}>{b.total.toLocaleString()} Kč</div><Badge {...ST[b.status]}/></div></div>)}</div>}
      {tab==="Servis"&&<div>{m.nextSvc?<div style={{padding:12,background:C.gp,borderRadius:12,borderLeft:`4px solid ${C.green}`}}><div style={{fontWeight:800}}>Příští: {m.nextSvc}</div><div style={{fontSize:11,color:C.g400,marginTop:3}}>Pravidelná údržba</div></div>:<div style={{color:C.g400,textAlign:"center",padding:16}}>Žádný plánovaný</div>}<div style={{marginTop:12}}><Btn green>+ Naplánovat</Btn></div></div>}
    </Cd>
    <div style={{flex:1,display:"flex",flexDirection:"column",gap:12}}><Stat icon="💰" label="Tržby" value={m.rev.toLocaleString()+" Kč"} color={C.gd}/><Stat icon="📊" label="Využití" value={m.util+"%"}/><Stat icon="🔧" label="Náklady servis" value={m.cost.toLocaleString()+" Kč"} color={C.red}/><Cd><div style={{display:"flex",flexDirection:"column",gap:6}}><Btn green>✏️ Upravit</Btn><Btn outline>📄 Dokumenty</Btn><Btn red>🗑️ Vyřadit</Btn></div></Cd></div>
  </div>
</div>};

const Book=({go})=>{const[f,sF]=useState("all");const d=f==="all"?BK:BK.filter(b=>b.status===f);return <div>
  <div style={{display:"flex",gap:6,marginBottom:14,flexWrap:"wrap"}}>{[["all","Vše"],["active","Aktivní"],["pending","Čekající"],["completed","Hotové"],["cancelled","Zrušené"]].map(([v,l])=><button key={v} onClick={()=>sF(v)} style={{padding:"6px 14px",borderRadius:50,fontSize:10,fontWeight:800,border:`2px solid ${f===v?C.green:C.g200}`,background:f===v?C.green:C.white,color:f===v?"#fff":C.g600,cursor:"pointer",textTransform:"uppercase"}}>{l} ({(v==="all"?BK:BK.filter(b=>b.status===v)).length})</button>)}<div style={{flex:1}}/><Btn green>+ Nová</Btn></div>
  <Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>ID</TH><TH>Zákazník</TH><TH>Motorka</TH><TH>Od–Do</TH><TH>Částka</TH><TH>Stav</TH><TH>Platba</TH></tr></thead><tbody>{d.map(b=><tr key={b.id} onClick={()=>go("book-d",b.id)} style={{borderBottom:`1px solid ${C.g200}`,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.background=C.gp} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><TD mono color={C.gdk}>{b.id}</TD><TD bold>{b.cust}</TD><TD>{b.moto}</TD><TD>{b.from} → {b.to}</TD><TD bold color={C.gd} mono>{b.total.toLocaleString()} Kč</TD><TD><Badge {...(ST[b.status]||{l:b.status,c:C.g400,bg:C.g100})}/></TD><TD>{b.paid?<span style={{color:C.gdk,fontWeight:700}}>✓</span>:<span style={{color:"#92400e",fontWeight:700}}>Čeká</span>}</TD></tr>)}</tbody></table></Cd>
</div>};

const BookD=({id,go})=>{const b=BK.find(x=>x.id===id);if(!b)return<div>Nenalezeno</div>;return <div><Back onClick={()=>go("book")}/>
  <div style={{display:"flex",gap:16}}>
    <Cd s={{flex:2}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:14}}><div><div style={{fontSize:20,fontWeight:900}}>{b.id}</div><div style={{fontSize:12,color:C.g400}}>{b.cust} · {b.moto}</div></div><Badge {...(ST[b.status]||{l:b.status,c:C.g400,bg:C.g100})}/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}><Field l="Zákazník" v={b.cust}/><Field l="Motorka" v={b.moto}/><Field l="Od" v={b.from}/><Field l="Do" v={b.to}/><Field l="Celkem" v={b.total.toLocaleString()+" Kč"}/><Field l="Platba" v={b.paid?"Zaplaceno":"Čeká"}/><Field l="Extras" v={b.extras.join(", ")||"—"}/><Field l="Poznámka" v={b.note}/></div>
      <div style={{marginTop:14,padding:12,background:C.g100,borderRadius:12}}><div style={{fontSize:10,fontWeight:800,color:C.g400,textTransform:"uppercase",marginBottom:8}}>Timeline</div>{[{t:"Vytvořeno",d:b.from,i:"📝"},{t:b.paid?"Zaplaceno":"Čeká platba",d:b.from,i:b.paid?"💳":"⏳"},b.status==="active"?{t:"Vydáno",d:b.from,i:"🏍️"}:null,b.status==="completed"?{t:"Vráceno",d:b.to,i:"✅"}:null].filter(Boolean).map((e,i)=><div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"6px 0",borderBottom:`1px solid ${C.g200}`}}><span style={{fontSize:16}}>{e.i}</span><div><div style={{fontWeight:700,fontSize:12}}>{e.t}</div><div style={{fontSize:10,color:C.g400}}>{e.d}</div></div></div>)}</div>
    </Cd>
    <div style={{flex:1,display:"flex",flexDirection:"column",gap:10}}><Stat icon="💰" label="Celkem" value={b.total.toLocaleString()+" Kč"} color={C.gd}/>
      <Cd><div style={{display:"flex",flexDirection:"column",gap:6}}>{b.status==="pending"&&<Btn green>✓ Potvrdit</Btn>}{b.status==="active"&&<Btn green>🏍️ Přijmout zpět</Btn>}{(b.status==="pending"||b.status==="active")&&<Btn red>✗ Zrušit</Btn>}<Btn outline>📄 Smlouva</Btn><Btn outline>🧾 Faktura</Btn><Btn s={{fontSize:10}} onClick={()=>go("crm-d",b.cid)}>👤 Zákazník</Btn><Btn s={{fontSize:10}} onClick={()=>go("fleet-d",b.mid)}>🏍️ Motorka</Btn></div></Cd>
    </div>
  </div>
</div>};

const CRM=({go})=><div>
  <div style={{display:"flex",gap:8,marginBottom:14}}><Btn green>+ Nový</Btn><div style={{flex:1}}/><div style={{padding:"7px 14px",background:C.white,borderRadius:50,border:`2px solid ${C.g200}`,fontSize:12,color:C.g400}}>🔍 Hledat…</div></div>
  <Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Jméno</TH><TH>Email</TH><TH>Telefon</TH><TH>ŘP</TH><TH>Rezervací</TH><TH>Utraceno</TH><TH>Skóre</TH></tr></thead><tbody>{CU.map(c=><tr key={c.id} onClick={()=>go("crm-d",c.id)} style={{borderBottom:`1px solid ${C.g200}`,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.background=C.gp} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><TD bold>{c.name} {c.vip?<Badge l="VIP" c={C.gdk} bg="#dcfce7"/>:""}</TD><TD>{c.email}</TD><TD mono>{c.phone}</TD><TD>{c.license}</TD><TD bold>{c.bk}</TD><TD bold color={C.gd} mono>{c.spent.toLocaleString()} Kč</TD><TD><span style={{fontSize:11,fontWeight:700}}>{c.score}</span></TD></tr>)}</tbody></table></Cd>
</div>;

const CRMD=({id,go})=>{const c=CU.find(x=>x.id===id);const[tab,sTab]=useState("Profil");if(!c)return<div>Nenalezeno</div>;const bks=BK.filter(b=>b.cid===id);return <div><Back onClick={()=>go("crm")}/>
  <div style={{display:"flex",gap:16}}>
    <Cd s={{flex:2}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:14}}><div><div style={{fontSize:20,fontWeight:900}}>{c.name}</div><div style={{fontSize:12,color:C.g400}}>{c.email} · {c.phone}</div></div>{c.vip&&<Badge l="VIP" c={C.gdk} bg="#dcfce7"/>}</div>
      <Tabs tabs={["Profil","Rezervace"]} a={tab} set={sTab}/>
      {tab==="Profil"&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}><Field l="Jméno" v={c.name}/><Field l="Email" v={c.email}/><Field l="Telefon" v={c.phone}/><Field l="Řidičák" v={c.license+" — "+c.licNum}/><Field l="Platnost ŘP" v={c.licExp}/><Field l="Město" v={c.city}/><Field l="Registrace" v={c.reg}/><Field l="Skóre" v={c.score+"/100"}/></div>}
      {tab==="Rezervace"&&<div>{bks.length===0?<div style={{color:C.g400,padding:16,textAlign:"center"}}>Žádné</div>:bks.map(b=><div key={b.id} onClick={()=>go("book-d",b.id)} style={{display:"flex",padding:"8px",background:C.g100,borderRadius:10,marginBottom:6,cursor:"pointer"}}><div style={{flex:1}}><div style={{fontWeight:700,fontSize:12}}>{b.id} — {b.moto}</div><div style={{fontSize:10,color:C.g400}}>{b.from}→{b.to}</div></div><div style={{textAlign:"right"}}><div style={{fontWeight:800,color:C.gd,fontSize:12}}>{b.total.toLocaleString()} Kč</div><Badge {...(ST[b.status]||{l:b.status,c:C.g400,bg:C.g100})}/></div></div>)}</div>}
    </Cd>
    <div style={{flex:1,display:"flex",flexDirection:"column",gap:10}}><Stat icon="📅" label="Rezervací" value={c.bk}/><Stat icon="💰" label="Utraceno" value={c.spent.toLocaleString()+" Kč"} color={C.gd}/><Stat icon="⭐" label="Skóre" value={c.score+"/100"} color={c.score>80?C.gdk:C.gold}/><Cd><div style={{display:"flex",flexDirection:"column",gap:6}}><Btn green>✏️ Upravit</Btn><Btn outline>📧 Email</Btn>{!c.vip?<Btn outline>⭐ VIP</Btn>:<Btn red>Zrušit VIP</Btn>}</div></Cd></div>
  </div>
</div>};

const Fin=()=>{const tr=REV.reduce((s,v)=>s+v,0),tc=COST.reduce((s,v)=>s+v,0),pr=tr-tc;return <div>
  <div style={{display:"flex",gap:12,marginBottom:18,flexWrap:"wrap"}}><Stat icon="💰" label="Tržby rok" value={`${tr}k Kč`} color={C.gd}/><Stat icon="📉" label="Náklady" value={`${tc}k Kč`} color={C.red}/><Stat icon="📈" label="Zisk" value={`${pr}k Kč`} sub={`marže ${Math.round(pr/tr*100)}%`}/><Stat icon="💳" label="Neuhrazené" value="22 400 Kč" color={C.red}/></div>
  <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:10}}>Měsíční přehled (tis. Kč)</div><Chart data={REV} h={70}/><div style={{display:"flex",justifyContent:"space-between",marginTop:4,marginBottom:14}}>{MO.map((m,i)=><span key={i} style={{fontSize:8,color:C.g400,fontWeight:700}}>{m}</span>)}</div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>{[["Ø tržba/moto",`${Math.round(tr/12/8)}k`],["Ø rezervace","14 329 Kč"],["Kauce","85 000 Kč"],["Pojistné","1 (12,4k)"]].map(([l,v],i)=><div key={i} style={{padding:10,background:C.g100,borderRadius:10,textAlign:"center"}}><div style={{fontSize:8,color:C.g400,fontWeight:700,textTransform:"uppercase",marginBottom:3}}>{l}</div><div style={{fontSize:14,fontWeight:800}}>{v}</div></div>)}</div>
  </Cd>
</div>};

const VIEWS={dash:Dash,fleet:Fleet,"fleet-d":FleetD,book:Book,"book-d":BookD,crm:CRM,"crm-d":CRMD,fin:Fin};

export default function Velin(){
  const[v,sV]=useState("dash");const[dId,sDId]=useState(null);const[col,sCol]=useState(false);
  const go=(page,id)=>{sV(page);sDId(id||null)};
  const View=VIEWS[v]||Dash;const label=NAV.find(n=>n.id===v)?.l||(v.includes("fleet")?"Flotila":v.includes("book")?"Rezervace":v.includes("crm")?"Zákazníci":"Velín");
  return <div style={{display:"flex",height:"100vh",background:C.bg,fontFamily:"'Montserrat',sans-serif",color:C.black,overflow:"hidden"}}>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
    <div style={{width:col?56:210,background:C.dark,display:"flex",flexDirection:"column",transition:"width .3s",flexShrink:0,overflow:"hidden"}}>
      <div style={{padding:col?"14px 6px":"16px",borderBottom:"1px solid rgba(255,255,255,.08)",display:"flex",alignItems:"center",gap:10,cursor:"pointer"}} onClick={()=>sCol(!col)}><div style={{flexShrink:0,width:36,height:36,borderRadius:18,background:"rgba(116,251,113,.15)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:900,color:C.green}}>MG</div>{!col&&<div><div style={{fontSize:14,fontWeight:900,color:C.white}}>MOTOGO24</div><div style={{fontSize:8,color:"rgba(255,255,255,.35)",letterSpacing:3,textTransform:"uppercase"}}>Velín · Část 1/3</div></div>}</div>
      <nav style={{flex:1,padding:"8px 4px",overflowY:"auto"}}>{NAV.map(n=>{const a=v===n.id||(v.startsWith(n.id));return <button key={n.id} onClick={()=>go(n.id)} style={{width:"100%",display:"flex",alignItems:"center",gap:8,padding:col?"8px 0":"8px 12px",justifyContent:col?"center":"flex-start",borderRadius:12,border:"none",cursor:"pointer",marginBottom:1,fontSize:12,fontWeight:a?800:600,background:a?"rgba(116,251,113,.12)":"transparent",color:a?C.green:"rgba(255,255,255,.5)",borderLeft:a?`3px solid ${C.green}`:"3px solid transparent",fontFamily:"inherit"}}><span style={{fontSize:15}}>{n.i}</span>{!col&&<span>{n.l}</span>}</button>})}</nav>
    </div>
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{padding:"10px 24px",borderBottom:`1px solid ${C.g200}`,display:"flex",alignItems:"center",justifyContent:"space-between",background:C.white,flexShrink:0}}><h1 style={{margin:0,fontSize:18,fontWeight:900}}>{label}</h1><div style={{fontSize:11,color:C.g400,fontWeight:600}}>{new Date().toLocaleDateString("cs-CZ",{weekday:"long",day:"numeric",month:"long"})}</div></div>
      <div style={{flex:1,overflowY:"auto",padding:20}}><View go={go} id={dId}/></div>
    </div>
  </div>;
}
