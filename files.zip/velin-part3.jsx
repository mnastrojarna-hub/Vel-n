import { useState, useRef, useEffect } from "react";

const C = {
  bg:"#dff0ec",black:"#0f1a14",dark:"#1a2e22",green:"#74FB71",gd:"#3dba3a",gdk:"#1a8a18",gp:"#e8ffe8",
  g100:"#f1faf7",g200:"#d4e8e0",g400:"#8aab99",g600:"#4a6357",red:"#ef4444",gold:"#f59e0b",blue:"#3b82f6",
  purple:"#8b5cf6",white:"#ffffff",shadow:"0 4px 20px rgba(15,26,20,.1)"
};
const ST={active:{l:"Aktivní",c:C.gdk,bg:"#dcfce7"},draft:{l:"Koncept",c:C.g600,bg:C.g200},sent:{l:"Odesláno",c:C.blue,bg:"#dbeafe"},received:{l:"Přijato",c:C.gdk,bg:"#dcfce7"}};

const MOTOS=[
  {id:"bmw",name:"BMW R 1200 GS",spz:"5P2 3456",insurance:"Kooperativa",insEnd:"2026-12-31",stkEnd:"2026-09-15",rev:134656,util:78},
  {id:"jawa",name:"Jawa RVM 500",spz:"3J1 2233",insurance:"Generali",insEnd:"2026-08-20",stkEnd:"2027-01-10",rev:63552,util:65},
  {id:"benelli",name:"Benelli TRK 702 X",spz:"2B4 7788",insurance:"ČSOB",insEnd:"2026-11-05",stkEnd:"2026-06-22",rev:47216,util:0},
  {id:"cfmoto",name:"CF MOTO 800 MT",spz:"6C2 1199",insurance:"Allianz",insEnd:"2027-03-15",stkEnd:"2027-05-01",rev:126112,util:82},
  {id:"niken",name:"Yamaha Niken GT",spz:"1Y3 5566",insurance:"Kooperativa",insEnd:"2026-07-01",stkEnd:"2026-11-30",rev:110068,util:71},
  {id:"ktm",name:"KTM 1290 SA",spz:"4K7 9900",insurance:"Generali",insEnd:"2026-10-12",stkEnd:"2026-08-05",rev:162000,util:88},
  {id:"tiger",name:"Triumph Tiger 1200",spz:"7T8 4411",insurance:"Kooperativa",insEnd:"2026-04-30",stkEnd:"2026-03-15",rev:0,util:0},
  {id:"versys",name:"Kawasaki Versys 650",spz:"8K1 6677",insurance:"Allianz",insEnd:"2027-02-28",stkEnd:"2027-04-18",rev:52800,util:59},
];
const CMS_VARS=[
  {key:"company_name",val:"MotoGo24 s.r.o.",gr:"general"},{key:"company_ico",val:"12345678",gr:"general"},
  {key:"contact_email",val:"info@motogo24.cz",gr:"contact"},{key:"contact_phone",val:"+420 774 256 271",gr:"contact"},
  {key:"weekend_surcharge",val:"15%",gr:"pricing"},{key:"season_surcharge",val:"20%",gr:"pricing"},
  {key:"deposit_percent",val:"30%",gr:"pricing"},{key:"gdpr_text",val:"Souhlasím se zpracováním...",gr:"legal"},
];
const PROMOS=[
  {code:"JARO2026",disc:"15%",from:"2026-03-01",to:"2026-04-30",used:12,limit:100,on:true},
  {code:"VIKEND20",disc:"20%",from:"2026-01-01",to:"2026-12-31",used:45,limit:null,on:true},
  {code:"PRVNI500",disc:"500 Kč",from:"2026-01-01",to:"2026-06-30",used:8,limit:50,on:true},
];
const SUPPLIERS=[
  {id:"s1",name:"Moto Plus s.r.o.",ico:"12345678",contact:"Petr Novotný",email:"objednavky@motoplus.cz",cat:"výbava"},
  {id:"s2",name:"AD Partner",ico:"23456789",contact:"Jana Veselá",email:"ad@adpartner.cz",cat:"díly"},
  {id:"s3",name:"MotoDíly CZ",ico:"34567890",contact:"Tomáš Kučera",email:"info@motodily.cz",cat:"díly"},
  {id:"s4",name:"Pneumatiky.cz",ico:"45678901",contact:"Martin Horák",email:"b2b@pneumatiky.cz",cat:"pneumatiky"},
];
const ORDERS=[
  {id:"OBJ-001",supplier:"Moto Plus s.r.o.",date:"2026-02-15",total:41000,status:"received",items:"Bunda Alpinestars 5×"},
  {id:"OBJ-002",supplier:"AD Partner",date:"2026-03-01",total:7120,status:"sent",items:"Brzdové destičky 8×"},
  {id:"OBJ-003",supplier:"MotoDíly CZ",date:"2026-03-02",total:12800,status:"draft",items:"Řetězová sada 4×"},
];
const MO=["Led","Úno","Bře","Dub","Kvě","Čvn","Čvc","Srp","Zář","Říj","Lis","Pro"];
const REV=[82,71,145,198,267,312,345,356,289,178,95,68];

// UI
const Badge=({l,c,bg})=><span style={{display:"inline-block",padding:"3px 10px",borderRadius:50,fontSize:10,fontWeight:800,color:c,background:bg,textTransform:"uppercase"}}>{l}</span>;
const Btn=({children,green,outline,onClick,s})=><button onClick={onClick} style={{padding:"8px 18px",borderRadius:50,fontSize:11,fontWeight:800,border:outline?`2px solid ${C.green}`:"none",background:green?C.green:outline?"transparent":C.g100,color:green?"#fff":outline?C.gd:C.g600,cursor:"pointer",textTransform:"uppercase",letterSpacing:.4,...s}}>{children}</button>;
const Cd=({children,s})=><div style={{background:C.white,borderRadius:18,padding:18,boxShadow:C.shadow,...s}}>{children}</div>;
const Stat=({icon,label,value,sub,color=C.gdk})=><Cd s={{flex:1,minWidth:130,position:"relative",overflow:"hidden"}}><div style={{position:"absolute",top:-8,right:-8,fontSize:42,opacity:.06}}>{icon}</div><div style={{fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{label}</div><div style={{fontSize:20,fontWeight:900,color}}>{value}</div>{sub&&<div style={{fontSize:10,color:C.g400,marginTop:3}}>{sub}</div>}</Cd>;
const Chart=({data,color=C.gdk,h=50})=>{const mx=Math.max(...data),mn=Math.min(...data),r=mx-mn||1,w=100/data.length;return <svg viewBox={`0 0 100 ${h}`} style={{width:"100%",height:h}} preserveAspectRatio="none"><polyline fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" points={data.map((v,i)=>`${i*w+w/2},${h-((v-mn)/r)*(h-6)-3}`).join(" ")}/></svg>};
const Tabs=({tabs,a,set})=><div style={{display:"flex",gap:2,marginBottom:14,borderBottom:`2px solid ${C.g200}`}}>{tabs.map(t=><button key={t} onClick={()=>set(t)} style={{padding:"7px 16px",fontSize:11,fontWeight:a===t?800:600,color:a===t?C.gdk:C.g400,background:"transparent",border:"none",borderBottom:a===t?`3px solid ${C.green}`:"3px solid transparent",cursor:"pointer",fontFamily:"inherit",textTransform:"uppercase"}}>{t}</button>)}</div>;
const TH=({children})=><th style={{padding:"8px 12px",textAlign:"left",fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase"}}>{children}</th>;
const TD=({children,bold,color,mono})=><td style={{padding:"8px 12px",fontSize:12,fontWeight:bold?700:500,color:color||C.black,fontFamily:mono?"monospace":"inherit"}}>{children}</td>;

const NAV=[{id:"cms",l:"Web CMS",i:"🌐"},{id:"stats",l:"Statistiky",i:"📊"},{id:"buy",l:"Nákupy",i:"🛒"},{id:"gov",l:"Státní správa",i:"🏛️"},{id:"ai",l:"AI Copilot",i:"🤖"}];

// CMS
const CmsPage=()=>{const[tab,sTab]=useState("Proměnné");const[editIdx,sEdit]=useState(null);return <div>
  <Tabs tabs={["Proměnné","Promo kódy","Flags"]} a={tab} set={sTab}/>
  {tab==="Proměnné"&&<Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Klíč</TH><TH>Hodnota</TH><TH>Skupina</TH><TH>Akce</TH></tr></thead><tbody>{CMS_VARS.map((v,i)=><tr key={i} style={{borderBottom:`1px solid ${C.g200}`}}><TD mono color={C.gdk}>{v.key}</TD><TD>{editIdx===i?<input defaultValue={v.val} style={{width:"100%",padding:"4px 8px",borderRadius:8,border:`1px solid ${C.g200}`,fontSize:12,fontFamily:"inherit"}} onBlur={()=>sEdit(null)} autoFocus/>:v.val}</TD><TD><Badge l={v.gr} c={C.blue} bg="#dbeafe"/></TD><TD><Btn s={{padding:"3px 10px",fontSize:9}} onClick={()=>sEdit(i)}>✏️</Btn></TD></tr>)}</tbody></table></Cd>}
  {tab==="Promo kódy"&&<><div style={{marginBottom:14}}><Btn green>+ Nový promo kód</Btn></div><Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Kód</TH><TH>Sleva</TH><TH>Platnost</TH><TH>Použití</TH><TH>Stav</TH></tr></thead><tbody>{PROMOS.map((p,i)=><tr key={i} style={{borderBottom:`1px solid ${C.g200}`}}><TD bold mono color={C.gdk}>{p.code}</TD><TD bold color={C.gd}>{p.disc}</TD><TD>{p.from} — {p.to}</TD><TD>{p.used}{p.limit?"/"+p.limit:""}</TD><TD>{p.on?<Badge l="Aktivní" c={C.gdk} bg="#dcfce7"/>:<Badge l="Off" c={C.red} bg="#fee2e2"/>}</TD></tr>)}</tbody></table></Cd></>}
  {tab==="Flags"&&<Cd>{[["Registrace uživatelů",true],["Online platby (Stripe)",true],["SOS systém",true],["AI Copilot",false],["Skenování dokladů",true],["Promo kódy",true],["Vícejazyčnost",true],["Maintenance mode",false]].map(([name,on],i)=><div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 0",borderBottom:`1px solid ${C.g200}`}}><span style={{fontSize:12,fontWeight:600}}>{name}</span><div style={{width:44,height:24,borderRadius:12,background:on?C.green:C.g200,cursor:"pointer",position:"relative"}}><div style={{width:20,height:20,borderRadius:10,background:C.white,position:"absolute",top:2,left:on?22:2,boxShadow:"0 2px 4px rgba(0,0,0,.15)"}}/></div></div>)}</Cd>}
</div>};

// STATISTICS
const Stats=()=>{const sorted=MOTOS.filter(m=>m.util>0).sort((a,b)=>b.rev-a.rev);const br=[{n:"Mezná",rev:481,motos:5,util:59},{n:"Brno",rev:215,motos:3,util:49}];return <div>
  <div style={{display:"flex",gap:12,marginBottom:18,flexWrap:"wrap"}}><Stat icon="📊" label="Tržby rok" value="696k Kč" color={C.gd}/><Stat icon="🏍️" label="Ø vytíženost" value="74%" color={C.blue}/><Stat icon="📅" label="Rezervací" value="7"/><Stat icon="⭐" label="Ø hodnocení" value="4.7" color={C.gold}/></div>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>📈 Tržby 12 měsíců (tis. Kč)</div><Chart data={REV} h={70}/><div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>{MO.map((m,i)=><span key={i} style={{fontSize:7,color:C.g400,fontWeight:700}}>{m}</span>)}</div></Cd>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>🏍️ Top motorky dle tržeb</div>{sorted.map((m,i)=><div key={m.id} style={{display:"flex",alignItems:"center",marginBottom:6}}><span style={{width:18,fontSize:11,fontWeight:800,color:i<3?C.gdk:C.g400}}>{i+1}.</span><span style={{flex:1,fontSize:11,fontWeight:700}}>{m.name}</span><div style={{width:100,height:6,borderRadius:3,background:C.g200,marginRight:8}}><div style={{height:6,borderRadius:3,background:i===0?C.green:C.gdk,width:Math.round(m.rev/sorted[0].rev*100)+"%"}}/></div><span style={{fontSize:11,fontWeight:800,color:C.gd,minWidth:55,textAlign:"right"}}>{(m.rev/1000).toFixed(0)}k</span></div>)}</Cd>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>🏢 Pobočky</div>{br.map(b=><div key={b.n} style={{padding:12,background:C.g100,borderRadius:12,marginBottom:8}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}><span style={{fontWeight:800}}>{b.n}</span><span style={{fontWeight:800,color:C.gd}}>{b.rev}k Kč</span></div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6}}>{[["Motorek",b.motos,C.black],["Využití",b.util+"%",b.util>55?C.gdk:C.gold],["Kč/moto",Math.round(b.rev/b.motos)+"k",C.gd]].map(([l,v,c],i)=><div key={i}><div style={{fontSize:8,color:C.g400,fontWeight:700,textTransform:"uppercase"}}>{l}</div><div style={{fontSize:14,fontWeight:800,color:c}}>{v}</div></div>)}</div></div>)}</Cd>
    <Cd><div style={{fontSize:12,fontWeight:800,marginBottom:8}}>📅 Rezervace dle statusu</div>{[["Aktivní",3,C.green],["Čekající",2,C.gold],["Dokončené",2,C.blue],["Zrušené",0,C.red]].map(([l,n,c])=><div key={l} style={{display:"flex",alignItems:"center",marginBottom:8}}><div style={{width:10,height:10,borderRadius:3,background:c,marginRight:8}}/><span style={{flex:1,fontSize:12,fontWeight:600}}>{l}</span><div style={{width:80,height:6,borderRadius:3,background:C.g200,marginRight:8}}><div style={{height:6,borderRadius:3,background:c,width:Math.max(n/7*100,2)+"%"}}/></div><span style={{fontSize:13,fontWeight:800}}>{n}</span></div>)}<Btn green s={{width:"100%",justifyContent:"center",marginTop:10}}>📊 Generovat report</Btn></Cd>
  </div>
</div>};

// PURCHASES
const Buy=()=>{const[tab,sTab]=useState("Objednávky");return <div>
  <Tabs tabs={["Objednávky","Dodavatelé"]} a={tab} set={sTab}/>
  {tab==="Objednávky"&&<><div style={{marginBottom:14}}><Btn green>+ Nová objednávka</Btn></div><Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Číslo</TH><TH>Dodavatel</TH><TH>Datum</TH><TH>Celkem</TH><TH>Stav</TH><TH>Položky</TH></tr></thead><tbody>{ORDERS.map(o=><tr key={o.id} style={{borderBottom:`1px solid ${C.g200}`}}><TD mono color={C.gdk}>{o.id}</TD><TD bold>{o.supplier}</TD><TD>{o.date}</TD><TD bold mono color={C.gd}>{o.total.toLocaleString()} Kč</TD><TD><Badge {...(ST[o.status]||{l:o.status,c:C.g400,bg:C.g100})}/></TD><TD>{o.items}</TD></tr>)}</tbody></table></Cd></>}
  {tab==="Dodavatelé"&&<><div style={{marginBottom:14}}><Btn green>+ Nový dodavatel</Btn></div><Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Název</TH><TH>IČO</TH><TH>Kontakt</TH><TH>Email</TH><TH>Kat.</TH></tr></thead><tbody>{SUPPLIERS.map(s=><tr key={s.id} style={{borderBottom:`1px solid ${C.g200}`}}><TD bold>{s.name}</TD><TD mono>{s.ico}</TD><TD>{s.contact}</TD><TD>{s.email}</TD><TD><Badge l={s.cat} c={C.blue} bg="#dbeafe"/></TD></tr>)}</tbody></table></Cd></>}
</div>};

// GOVERNMENT
const Gov=()=>{const[tab,sTab]=useState("STK");return <div>
  <Tabs tabs={["STK","Pojistky","Firma"]} a={tab} set={sTab}/>
  {tab==="STK"&&<Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Motorka</TH><TH>SPZ</TH><TH>STK do</TH><TH>Dní</TH><TH>Stav</TH></tr></thead><tbody>{MOTOS.map(m=>{const d=Math.round((new Date(m.stkEnd)-new Date())/864e5);return <tr key={m.id} style={{borderBottom:`1px solid ${C.g200}`,background:d<30?"#fff5f5":"transparent"}}><TD bold>{m.name}</TD><TD mono>{m.spz}</TD><TD>{m.stkEnd}</TD><TD bold color={d<30?C.red:d<90?"#92400e":C.gdk}>{d} dní</TD><TD>{d<30?<Badge l="Urgentní!" c="#991b1b" bg="#fee2e2"/>:d<90?<Badge l="Brzy" c="#92400e" bg="#fef3c7"/>:<Badge l="OK" c={C.gdk} bg="#dcfce7"/>}</TD></tr>})}</tbody></table></Cd>}
  {tab==="Pojistky"&&<Cd s={{padding:0,overflow:"hidden"}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr style={{background:C.g100}}><TH>Motorka</TH><TH>SPZ</TH><TH>Pojišťovna</TH><TH>Do</TH><TH>Dní</TH><TH>Stav</TH></tr></thead><tbody>{MOTOS.map(m=>{const d=Math.round((new Date(m.insEnd)-new Date())/864e5);return <tr key={m.id} style={{borderBottom:`1px solid ${C.g200}`}}><TD bold>{m.name}</TD><TD mono>{m.spz}</TD><TD>{m.insurance}</TD><TD>{m.insEnd}</TD><TD bold color={d<30?C.red:d<90?"#92400e":C.gdk}>{d}</TD><TD>{d<30?<Badge l="Urgentní!" c="#991b1b" bg="#fee2e2"/>:d<90?<Badge l="Brzy" c="#92400e" bg="#fef3c7"/>:<Badge l="OK" c={C.gdk} bg="#dcfce7"/>}</TD></tr>})}</tbody></table></Cd>}
  {tab==="Firma"&&<Cd><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>{[["Název firmy","MotoGo24 s.r.o."],["IČO","12345678"],["DIČ","CZ12345678"],["Sídlo","Pelhřimov, Vysočina"],["Email","info@motogo24.cz"],["Telefon","+420 774 256 271"],["Datová schránka","abc1234"],["Bankovní účet","123-456789/0100"]].map(([l,v],i)=><div key={i} style={{marginBottom:8}}><div style={{fontSize:9,fontWeight:800,color:C.g400,textTransform:"uppercase",marginBottom:2}}>{l}</div><div style={{fontSize:13,fontWeight:600,padding:"6px 10px",background:C.g100,borderRadius:8}}>{v}</div></div>)}</div><div style={{marginTop:10}}><Btn green>✏️ Upravit údaje</Btn></div></Cd>}
</div>};

// AI COPILOT
const AI=()=>{
  const[ms,sMs]=useState([{r:"ai",t:"Ahoj! Jsem AI asistent Velínu MotoGo24. Umím analyzovat flotilu, generovat reporty, optimalizovat ceny, predikovat poptávku, připravovat daňové podklady a psát odpovědi zákazníkům. Na co se chceš zeptat?"}]);
  const[inp,sInp]=useState("");const ref=useRef(null);
  const qk=["Nejziskovější motorka?","Report únor","Predikce duben","Optimalizuj ceny","Připrav DPH","Odpověď zákazníkovi","Srovnej pobočky"];
  const send=(t)=>{const m=t||inp;if(!m.trim())return;sMs(p=>[...p,{r:"user",t:m}]);sInp("");
    setTimeout(()=>{let r;
      if(m.includes("zisk")||m.includes("vydělává"))r="📊 Analýza ziskovosti:\n\n🥇 KTM 1290 SA — 140k Kč (util. 88%)\n🥈 CF MOTO 800 MT — 114k Kč (util. 82%)\n🥉 BMW R 1200 GS — 116k Kč (util. 78%)\n\n⚠️ Triumph Tiger vyřazena, generuje 0 při odpisech 35k/měs.\nROI flotily: 23.4% p.a.";
      else if(m.includes("report"))r="📋 Report únor 2026:\n\n• Tržby: 487 200 Kč (+12%)\n• Zisk: 198 400 Kč (marže 40.7%)\n• Rezervací: 34 (storno 8.8%)\n• Ø objednávka: 14 329 Kč\n• Top: KTM 1290 SA (14/28 dnů)\n\nExport do PDF?";
      else if(m.includes("predikce")||m.includes("poptáv"))r="📈 Predikce duben:\n\n• Poptávka: +45% vs březen\n• Adventure: +62% (peak)\n• Víkendy: 95% kapacity → surge +15%\n• Rozložení: 5 Mezná / 3 Brno\n\nPřesnost modelu: 87%";
      else if(m.includes("DPH")||m.includes("daň"))r="🏛️ DPH Q1 2026:\n\n• Výstupy: 1 203 000 Kč\n• DPH 21%: 252 630 Kč\n• Odpočet: 65 230 Kč\n• K odvodu: 187 400 Kč\n• Termín: 25. 4. 2026\n\nPřipravím XML pro EPO?";
      else if(m.includes("cen")||m.includes("optim"))r="💰 Cenová optimalizace:\n\n• Pátek +15% (peak)\n• Neděle -8% (generování poptávky)\n• Sezóna IV-IX +20%\n• Niken GT -5% (zvýšit util. 71→80%)\n\nDopad: +34 000 Kč/měsíc";
      else if(m.includes("pobočk")||m.includes("srovn"))r="🏢 Mezná vs Brno:\n\n• Mezná: 5 motorek, 481k/měs, util. 59%\n• Brno: 3 motorky, 215k/měs, util. 49%\n\nMezná výrazně profitabilnější. Doporučuji přesun 1 stroje z Brna nebo marketing push.";
      else if(m.includes("odpověď")||m.includes("zákazník"))r="✉️ Návrh odpovědi:\n\n\"Dobrý den!\n\nProdloužení je možné — motorka je volná. Nová cena: 25 248 Kč.\n\nPotvrďte prosím odpovědí.\n\nDěkujeme!\nTým MotoGo24\"\n\nOdeslat přes web/WhatsApp/email?";
      else r="Rozumím, připravím analýzu. K čemu přesně potřebuješ pomoc — flotila, finance, zákazníci nebo dokumenty?";
      sMs(p=>[...p,{r:"ai",t:r}]);
    },700);
  };
  useEffect(()=>{ref.current?.scrollIntoView({behavior:"smooth"});},[ms]);
  return <div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 140px)"}}>
    <div style={{flex:1,overflowY:"auto",marginBottom:10}}>{ms.map((m,i)=><div key={i} style={{display:"flex",justifyContent:m.r==="user"?"flex-end":"flex-start",marginBottom:8}}><div style={{maxWidth:"78%",padding:"10px 14px",borderRadius:m.r==="user"?"16px 16px 4px 16px":"16px 16px 16px 4px",background:m.r==="user"?C.gp:C.white,fontSize:12,lineHeight:1.6,whiteSpace:"pre-wrap",boxShadow:C.shadow,border:m.r==="user"?`2px solid ${C.green}33`:"none"}}>{m.r==="ai"&&<div style={{fontSize:9,color:C.gdk,fontWeight:800,marginBottom:4}}>🤖 AI Copilot</div>}{m.t}</div></div>)}<div ref={ref}/></div>
    <div style={{display:"flex",gap:4,flexWrap:"wrap",marginBottom:8}}>{qk.map((a,i)=><button key={i} onClick={()=>send(a)} style={{padding:"4px 10px",borderRadius:50,fontSize:10,border:`2px solid ${C.g200}`,background:C.white,color:C.g600,cursor:"pointer",fontWeight:700,fontFamily:"inherit"}}>{a}</button>)}</div>
    <div style={{display:"flex",gap:6}}><input value={inp} onChange={e=>sInp(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Zeptej se AI copilota…" style={{flex:1,padding:"10px 16px",borderRadius:50,border:`2px solid ${C.g200}`,background:C.white,fontSize:13,outline:"none",fontFamily:"inherit"}}/><Btn green onClick={()=>send()}>Odeslat</Btn></div>
  </div>;
};

const VIEWS={cms:CmsPage,stats:Stats,buy:Buy,gov:Gov,ai:AI};

export default function Velin(){
  const[v,sV]=useState("cms");const[col,sCol]=useState(false);
  const View=VIEWS[v]||CmsPage;const label=NAV.find(n=>n.id===v)?.l||"CMS";
  return <div style={{display:"flex",height:"100vh",background:C.bg,fontFamily:"'Montserrat',sans-serif",color:C.black,overflow:"hidden"}}>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
    <div style={{width:col?56:210,background:C.dark,display:"flex",flexDirection:"column",transition:"width .3s",flexShrink:0,overflow:"hidden"}}>
      <div style={{padding:col?"14px 6px":"16px",borderBottom:"1px solid rgba(255,255,255,.08)",display:"flex",alignItems:"center",gap:10,cursor:"pointer"}} onClick={()=>sCol(!col)}><div style={{width:36,height:36,borderRadius:18,background:"rgba(116,251,113,.15)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:900,color:C.green}}>MG</div>{!col&&<div><div style={{fontSize:14,fontWeight:900,color:C.white}}>MOTOGO24</div><div style={{fontSize:8,color:"rgba(255,255,255,.35)",letterSpacing:3,textTransform:"uppercase"}}>Velín · Část 3/3</div></div>}</div>
      <nav style={{flex:1,padding:"8px 4px"}}>{NAV.map(n=>{const a=v===n.id;return <button key={n.id} onClick={()=>sV(n.id)} style={{width:"100%",display:"flex",alignItems:"center",gap:8,padding:col?"8px 0":"8px 12px",justifyContent:col?"center":"flex-start",borderRadius:12,border:"none",cursor:"pointer",marginBottom:1,fontSize:12,fontWeight:a?800:600,background:a?"rgba(116,251,113,.12)":"transparent",color:a?C.green:"rgba(255,255,255,.5)",borderLeft:a?`3px solid ${C.green}`:"3px solid transparent",fontFamily:"inherit"}}><span style={{fontSize:15}}>{n.i}</span>{!col&&<span>{n.l}</span>}</button>})}</nav>
    </div>
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{padding:"10px 24px",borderBottom:`1px solid ${C.g200}`,display:"flex",alignItems:"center",justifyContent:"space-between",background:C.white}}><h1 style={{margin:0,fontSize:18,fontWeight:900}}>{label}</h1><div style={{fontSize:11,color:C.g400,fontWeight:600}}>{new Date().toLocaleDateString("cs-CZ",{weekday:"long",day:"numeric",month:"long"})}</div></div>
      <div style={{flex:1,overflowY:"auto",padding:20}}><View/></div>
    </div>
  </div>;
}
