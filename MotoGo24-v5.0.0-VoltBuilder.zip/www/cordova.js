// Cordova stub - replaced by VoltBuilder during build
