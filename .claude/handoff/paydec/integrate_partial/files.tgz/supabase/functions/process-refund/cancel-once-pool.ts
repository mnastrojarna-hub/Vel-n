// ===== process-refund/cancel-once-pool.ts =====
// Spojení HOTFIXU storna 2026-10-29 (cancel-once.ts — storno vratka nejvýš jednou za storno) s vratkou
// z více plateb rezervace (dev větev f1–f3: mainSource / staffFullBalanceHaleru / refundRemainder).
// Storno teď může vrátit z jiné platby než z uložené (bookings.stripe_payment_intent_id): hlavní vratka
// z nejstarší platby v ceně (retarget) a zbytek z ostatních plateb. Kontrola „už vráceno pro toto
// storno“ jen nad vratkami uložené platby by takovou vratku neviděla → druhé volání (send-cancellation-
// email po Velínu, retry) by vrátilo podruhé. Proto:
//  • cancellationRefundPool — vratky VŠECH plateb rezervace (uložená + search + historie úprav),
//    nejnovější první; chyba → jen uložená platba (chování hotfixu),
//  • completeCancelRemainder — dorovnání po pádu mezi hlavní vratkou a zbytkem: dovrátí nevrácený
//    zbytek TÉHOŽ storna do mg_target (požadavek zapsaný na hlavní vratce) stejnou cestou jako
//    process-refund (refundRemainder: idempotency klíč dle hlavní vratky, odečte už vrácené) a dobropis
//    k hlavní vratce dorovná nahoru (reconcileCreditNote; PDF se přegeneruje přes ensureCreditNotePdf).
//    Bez mg_target (vratka starší verze) nic — jako hotfix.
import { bookingIntents, type BookingIntentsStripe } from '../_shared/booking-intents.ts'
import { refundRemainder } from './other-intents.ts'
import { reconcileCreditNote } from './credit-note-sync.ts'
import { cancelTargetHaleru, logicalRefundHaleru, type StripeRefundLike } from './cancel-once.ts'

// deno-lint-ignore no-explicit-any
type Sb = any

const piOf = (r: { payment_intent?: unknown }): string | null =>
  typeof r.payment_intent === 'string' ? r.payment_intent : ((r.payment_intent as { id?: string } | null)?.id ?? null)

/** Vratky všech plateb rezervace, nejnovější první (Stripe `created`). */
export async function cancellationRefundPool(stripe: BookingIntentsStripe, sb: Sb, a: {
  bookingId: string; storedPiId: string | null; storedRefunds: StripeRefundLike[] | null
}): Promise<StripeRefundLike[]> {
  const pool: StripeRefundLike[] = [...(a.storedRefunds || [])]
  try {
    const { rows } = await bookingIntents(stripe, sb, a.bookingId, a.storedPiId)
    for (const p of rows) {
      const rl = await stripe.refunds.list({ payment_intent: p.id, limit: 100 })
      for (const r of (rl?.data || []) as unknown as StripeRefundLike[]) pool.push({ ...r, payment_intent: piOf(r) ?? p.id })
    }
  } catch (e) {
    console.warn('[process-refund] cancellation refund pool (other payments) failed:', (e as Error).message)
  }
  const seen = new Set<string>()
  return pool.filter((r) => !seen.has(r.id) && !!seen.add(r.id)).sort((x, y) => Number(y.created || 0) - Number(x.created || 0))
}

/** Dovrátí nevrácený zbytek storna `main` do mg_target; true = něco vrátil (stav + dobropis se dorovnají). */
export async function completeCancelRemainder(stripe: BookingIntentsStripe, sb: Sb, a: {
  bookingId: string; main: StripeRefundLike; pool: StripeRefundLike[]
  dlog: (action: string, status: string, extra?: Record<string, unknown>) => unknown
}): Promise<boolean> {
  const target = cancelTargetHaleru(a.main)
  const done = logicalRefundHaleru(a.main, a.pool)
  if (target == null || done >= target) return false
  const extra = await refundRemainder(stripe, sb, {
    bookingId: a.bookingId, mainPi: piOf(a.main), mainRefundId: a.main.id, remainingHaleru: target - Number(a.main.amount || 0), reason: 'cancellation',
  })
  const fresh = extra.refunds.reduce((s, x) => s + x.amountHaleru, 0)
  await a.dlog('cancellation_remainder_completed', extra.error ? 'error' : 'info', {
    refund_id: a.main.id, target_haleru: target, before_haleru: done, refunded_now_haleru: fresh, extra: extra.refunds,
    left_haleru: extra.leftHaleru, error: extra.error || null,
  })
  if (!(fresh > 0)) return false
  try {
    const { data } = await sb.from('invoices').select('id, number, total, items, notes')
      .eq('booking_id', a.bookingId).eq('type', 'credit_note').eq('stripe_refund_id', a.main.id).neq('status', 'cancelled').limit(1)
    const cn = data?.[0]
    if (cn) {
      const fixed = await reconcileCreditNote(sb, { cnId: cn.id, cnNumber: cn.number, bookingId: a.bookingId, currentTotal: Number(cn.total || 0),
        targetCzk: (done + fresh) / 100, description: cn.items?.[0]?.description || 'Dobropis – Storno rezervace', reasonText: 'Storno rezervace',
        notes: `${cn.notes || ''} Vráceno z více plateb: ${a.main.id} + ${extra.refunds.map((x) => x.refundId).join(', ')}.`.trim(),
        issueDate: new Date().toISOString().slice(0, 10) })
      // nový PDF s dorovnanou částkou vyrobí ensureCreditNotePdf (respondExistingCancelRefund)
      if (fixed != null) await sb.from('invoices').update({ pdf_path: null }).eq('id', cn.id)
    }
  } catch (e) {
    await a.dlog('credit_note_reconcile_failed', 'error', { refund_id: a.main.id, error: (e as Error).message })
  }
  return true
}
