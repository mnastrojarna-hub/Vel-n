// ===== MotoGo24 – Edge Function: Process Refund (Stripe LIVE) =====
// Handles partial and full refunds for bookings and shop orders.
// Endpoint: POST /functions/v1/process-refund
// Body: { booking_id?, order_id?, amount?, reason? }
// If amount is omitted, full refund is issued.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14'
import { authClassify, forbidden } from '../_shared/auth.ts'
import { refundRemainder, mainSource, refundedStatus, customerCapHaleru, staffFullBalanceHaleru, CUSTOMER_SHORT_TOLERANCE_HALERU, type ExtraRefund, type OtherIntentsStripe } from './other-intents.ts'
import { reconcileCreditNote, remainderForMainHaleru } from './credit-note-sync.ts'
import { isRecoveryOnlyReason } from '../_shared/refund-recovery.ts'
// Výpůjčka výbavy (2026-10-23): text dobropisu „výpůjčka výbavy“ + spodní mez ceny výbavy (gear.ts).
import { gearPriceFloorCzk, loadGearRefundRow, noMotoRefundSubject } from './gear.ts'
// HOTFIX storno 2026-10-29: storno vratka nejvýš jednou za storno (cancel-once.ts).
import { acquireCancelLock, cancelToken, duplicateAdminRefunds, priorCancellationRefunds, releaseCancelLock, respondExistingCancelRefund, type CancelLock, type StripeRefundLike } from './cancel-once.ts'
// Spojení hotfixu s vratkou z více plateb (dev f1–f3): kontrola nad vratkami všech plateb rezervace.
import { cancellationRefundPool, completeCancelRemainder } from './cancel-once-pool.ts'

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2024-04-10',
  httpClient: Stripe.createFetchHttpClient(),
})

const PDFSHIFT_API_KEY = Deno.env.get('PDFSHIFT_API_KEY') || ''

async function htmlToPdf(html: string): Promise<Uint8Array | null> {
  if (!PDFSHIFT_API_KEY) return null
  try {
    const res = await fetch('https://api.pdfshift.io/v3/convert/pdf', {
      method: 'POST',
      headers: { 'X-API-Key': PDFSHIFT_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ source: html, format: 'A4', margin: '12mm', sandbox: false, use_print: false }),
    })
    if (!res.ok) return null
    return new Uint8Array(await res.arrayBuffer())
  } catch { return null }
}

const fmtPrice = (n: number) => Math.abs(n || 0).toLocaleString('cs-CZ', { minimumFractionDigits: 2 })
const fmtDate = (d: string) => d ? new Date(d).toLocaleDateString('cs-CZ') : '—'

// Jednotné popisy důvodu vratky pro položky dobropisu (web/app/Velín posílají
// různé reason kódy; volný text zákazníka NIKDY neinjektujeme do HTML dokladu).
function reasonTextFor(reason: string | undefined | null): string {
  switch (reason) {
    case 'cancellation': return 'Storno rezervace'
    case 'shortening':
    case 'edit_shortening': return 'Zkrácení rezervace'
    case 'moto_swap': return 'Výměna motorky'
    case 'gear_edit': return 'Úprava výbavy'
    case 'booking_modified':
    case 'booking_modified_retry':
    case 'edit': return 'Úprava rezervace'
    case 'duplicate': return 'Duplicitní platba'
    case 'paid_change_failed': return 'Vrácení doplatku – úpravu rezervace nešlo zapsat'
    default: return 'Vrácení platby zákazníkovi'
  }
}

// Firemní údaje zákazníka (web rezervace — checkbox „Firemní údaje" v kroku 3).
// Tolerantní samostatný dotaz: sloupce company_name/company_address přidává
// migrace 20260818 — kdyby ještě nebyla aplikovaná, dobropis nesmí spadnout.
async function loadCustomerCompany(supabase: any, customer: any) {
  if (!customer || !customer.id) return
  const { data, error } = await supabase.from('profiles')
    .select('company_name, company_address').eq('id', customer.id).maybeSingle()
  if (!error && data) {
    customer.company = data.company_name || null
    customer.company_address = data.company_address || null
  }
}

function renderCreditNoteHtml(opts: {
  number: string; issueDate: string; reasonText: string; motoModel: string;
  refundAmount: number; refundPercent: number; bookingDates: string;
  customer: { full_name?: string; email?: string; phone?: string; street?: string; city?: string; zip?: string; ico?: string; dic?: string; company?: string | null; company_address?: string | null };
  originalInvoiceNumber?: string | null; stripeRefundId: string | null;
  cardBrand?: string | null; cardLast4?: string | null; manual?: boolean;
}): string {
  const c = opts.customer || {}
  const cardLine = opts.manual
    ? 'Částka bude vrácena PŘEVODEM NA ÚČET do 14 dnů.'
    : opts.cardLast4
      ? `Refund proběhl na kartu ${(opts.cardBrand || 'CARD').toUpperCase()} **** ${opts.cardLast4}.`
      : 'Refund proběhl na původní platební kartu.'
  return `<!DOCTYPE html><html lang="cs"><head><meta charset="UTF-8"><title>Dobropis ${opts.number}</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#0f1a14;margin:0;padding:24px;font-size:13px}
.hdr{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #dc2626;padding-bottom:12px;margin-bottom:18px}
.hdr h1{margin:0;font-size:22px;color:#dc2626;letter-spacing:1px}
.hdr .num{font-size:14px;color:#4a5a52;margin-top:4px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:18px}
.box{border:1px solid #d4e8e0;border-radius:6px;padding:12px;background:#f8fbfa}
.box h3{margin:0 0 8px;font-size:12px;color:#4a5a52;text-transform:uppercase;letter-spacing:1px}
.box p{margin:2px 0;font-size:13px}
table{width:100%;border-collapse:collapse;margin:12px 0}
th{text-align:left;padding:8px;background:#1a2e22;color:#fff;font-size:12px;text-transform:uppercase;letter-spacing:1px}
td{padding:10px 8px;border-bottom:1px solid #eef4f0;font-size:13px}
tr.total td{background:#fef2f2;font-weight:800;font-size:15px;color:#dc2626;border-bottom:none}
.note{margin-top:18px;padding:12px;background:#fef2f2;border-left:4px solid #dc2626;border-radius:4px;font-size:12px;line-height:1.6}
.foot{margin-top:24px;padding-top:12px;border-top:1px solid #d4e8e0;font-size:11px;color:#4a5a52;text-align:center}
</style></head><body>
<div class="hdr">
  <div>
    <h1>DOBROPIS</h1>
    <div class="num">Číslo: <strong>${opts.number}</strong></div>
    <div class="num">Datum vystavení: ${opts.issueDate}</div>
    ${opts.originalInvoiceNumber ? `<div class="num">K dokladu: ${opts.originalInvoiceNumber}</div>` : ''}
  </div>
  <div style="text-align:right">
    <div style="font-size:18px;font-weight:800">MotoGo24</div>
    <div style="color:#4a5a52">Bc. Petra Semorádová</div>
    <div style="color:#4a5a52">Mezná 9, 393 01 Pelhřimov</div>
    <div style="color:#4a5a52">IČO: 21874263</div>
  </div>
</div>
<div class="grid">
  <div class="box"><h3>Odběratel</h3>
    <p><strong>${c.full_name || '—'}</strong></p>
    ${c.company ? `<p>Firma: <strong>${c.company}</strong></p>` : ''}
    ${c.company_address ? `<p>Sídlo: ${c.company_address}</p>` : ''}
    ${c.street ? `<p>${c.street}</p>` : ''}
    ${(c.city || c.zip) ? `<p>${c.zip || ''} ${c.city || ''}</p>` : ''}
    ${c.ico ? `<p>IČO: ${c.ico}</p>` : ''}
    ${c.dic ? `<p>DIČ: ${c.dic}</p>` : ''}
    ${c.email ? `<p>${c.email}</p>` : ''}
    ${c.phone ? `<p>${c.phone}</p>` : ''}
  </div>
  <div class="box"><h3>Detaily refundu</h3>
    <p>Důvod: <strong>${opts.reasonText}</strong></p>
    <p>Rezervace: ${opts.motoModel}</p>
    <p>Termín: ${opts.bookingDates}</p>
    <p>Procento vrácení: <strong>${opts.refundPercent} %</strong></p>
    <p style="font-size:11px;color:#4a5a52;word-break:break-all">Stripe refund: ${opts.stripeRefundId}</p>
  </div>
</div>
<table>
  <thead><tr><th>Popis</th><th style="text-align:right">Částka</th></tr></thead>
  <tbody>
    <tr><td>Dobropis – ${opts.reasonText} (${opts.motoModel})</td><td style="text-align:right">−${fmtPrice(opts.refundAmount)} Kč</td></tr>
    <tr class="total"><td>K vrácení celkem</td><td style="text-align:right">−${fmtPrice(opts.refundAmount)} Kč</td></tr>
  </tbody>
</table>
<div class="note">
  <strong>${cardLine}</strong> Peníze obvykle dorazí do 5–7 pracovních dnů.<br>
  Tento dobropis slouží jako doklad o vrácení platby.
</div>
<div class="foot">www.motogo24.cz · info@motogo24.cz · +420 774 256 271</div>
</body></html>`
}

interface RefundRequest {
  booking_id?: string
  order_id?: string
  amount?: number      // partial refund in CZK (omit for full refund)
  reason?: string      // 'cancellation' | 'shortening' | 'duplicate' | 'requested_by_customer'
}

// Idempotent helper: for an already-refunded booking, locate the credit note,
// regenerate its PDF if the storage file is missing or pdf_path is empty.
// Returns { creditNoteId, pdfPath, refundId } so the caller can return success.
async function ensureCreditNotePdf(
  supabase: any,
  bookingId: string,
  bk: { stripe_refund_id?: string | null; card_brand?: string | null; card_last4?: string | null },
): Promise<{ creditNoteId: string | null; pdfPath: string | null; refundId: string | null }> {
  try {
    const { data: cnRows } = await supabase.from('invoices')
      .select('id, number, pdf_path, stripe_refund_id, total, original_invoice_id, notes, created_at')
      .eq('booking_id', bookingId)
      .eq('type', 'credit_note')
      .neq('status', 'cancelled')
      .order('created_at', { ascending: false })
      .limit(1)
    if (!cnRows?.length) return { creditNoteId: null, pdfPath: null, refundId: bk.stripe_refund_id || null }

    const cn = cnRows[0]
    const refundId = cn.stripe_refund_id || bk.stripe_refund_id || null
    if (cn.pdf_path) {
      // Verify file actually exists in storage; if missing, regenerate.
      try {
        const { data: blob } = await supabase.storage.from('documents').download(cn.pdf_path)
        if (blob && blob.size > 0) return { creditNoteId: cn.id, pdfPath: cn.pdf_path, refundId }
      } catch { /* file missing — fall through to regenerate */ }
    }

    // Regenerate PDF — load booking + customer for the template
    const { data: bk2 } = await supabase.from('bookings')
      .select('total_price, start_date, end_date, motorcycles!moto_id(model), profiles:user_id(id, full_name, email, phone, street, city, zip, ico, dic)')
      .eq('id', bookingId).single()
    const refundedAmount = Math.abs(Number(cn.total || 0))
    // Procento dopočítat z ceny rezervace — natvrdo 100 tisklo i u částečné
    // vratky „Procento vrácení: 100 %", takže přegenerovaný dobropis lhal.
    const bk2Total = Number((bk2 as any)?.total_price || 0)
    const refundPercent = bk2Total > 0
      ? Math.min(100, Math.round((refundedAmount / bk2Total) * 100))
      : 100
    const reasonText = (cn.notes || '').includes('Storno') ? 'Storno rezervace'
      : (cn.notes || '').includes('Zkrácení') ? 'Zkrácení rezervace'
      : 'Vrácení platby zákazníkovi'

    let originalNumber: string | null = null
    if (cn.original_invoice_id) {
      const { data: orig } = await supabase.from('invoices')
        .select('number').eq('id', cn.original_invoice_id).single()
      originalNumber = orig?.number || null
    }

    const cust1 = (bk2 as any)?.profiles || {}
    await loadCustomerCompany(supabase, cust1)
    const html = renderCreditNoteHtml({
      number: cn.number,
      issueDate: fmtDate(new Date().toISOString().slice(0, 10)),
      reasonText,
      // Výpůjčka výbavy (2026-10-23): bez motorky → „výpůjčka výbavy“ (gear) / „motorky“ (gear.ts).
      motoModel: (bk2 as any)?.motorcycles?.model || await noMotoRefundSubject(supabase, bookingId),
      refundAmount: refundedAmount,
      refundPercent,
      bookingDates: `${fmtDate(bk2?.start_date)} – ${fmtDate(bk2?.end_date)}`,
      customer: cust1,
      originalInvoiceNumber: originalNumber,
      stripeRefundId: refundId || '',
      cardBrand: bk.card_brand,
      cardLast4: bk.card_last4,
    })

    const pdfBytes = await htmlToPdf(html)
    let path: string
    if (pdfBytes) {
      path = `invoices/${cn.id}.pdf`
      await supabase.storage.from('documents').upload(
        path, new Blob([pdfBytes], { type: 'application/pdf' }),
        { upsert: true, contentType: 'application/pdf' },
      )
    } else {
      path = `invoices/${cn.id}.html`
      await supabase.storage.from('documents').upload(
        path, new Blob([html], { type: 'text/html' }),
        { upsert: true, contentType: 'text/html' },
      )
    }
    await supabase.from('invoices').update({ pdf_path: path }).eq('id', cn.id)
    return { creditNoteId: cn.id, pdfPath: path, refundId }
  } catch (e) {
    console.warn('[ensureCreditNotePdf] failed:', (e as Error).message)
    return { creditNoteId: null, pdfPath: null, refundId: bk.stripe_refund_id || null }
  }
}

// Safety-net: pro booking, kde Stripe refund proběhl (charge.refunded webhook fired,
// payment_status='refunded') ale credit_note v invoices NEexistuje (process-refund
// crashed po refunds.create() ale před INSERT). Vytvoří credit_note + PDF z dat,
// která dohledá ze Stripe API (refund.amount, refund.charge → card brand/last4).
// Volá se z process-refund's already_refunded branche, když ensureCreditNotePdf
// vrátí creditNoteId=null. Idempotentní (stripe_refund_id unique).
async function createCreditNoteForExistingRefund(
  supabase: any,
  bookingId: string,
  bk: { stripe_refund_id?: string | null; stripe_payment_intent_id?: string | null; total_price?: number | null },
): Promise<{ creditNoteId: string | null; pdfPath: string | null; refundId: string | null }> {
  if (!bk.stripe_refund_id) {
    return { creditNoteId: null, pdfPath: null, refundId: null }
  }
  try {
    // Idempotency: nemáme duplikát pro stejný refund.id
    const { data: dupe } = await supabase.from('invoices')
      .select('id, pdf_path').eq('stripe_refund_id', bk.stripe_refund_id).limit(1)
    if (dupe?.length) {
      return { creditNoteId: dupe[0].id, pdfPath: dupe[0].pdf_path, refundId: bk.stripe_refund_id }
    }

    // Načti Stripe refund + charge pro autoritní data (amount, card brand/last4)
    const refund = await stripe.refunds.retrieve(bk.stripe_refund_id)
    const rmd = ((refund.metadata || {}) as Record<string, string>)
    // Oprava f3: vratku rozdělenou mezi více plateb (hlavní + zbytek z ostatních plateb rezervace,
    // metadata mg_main_refund) započítat celou — dřív dobropis jen z hlavní vratky (podhodnocený).
    let restHaleru = 0
    if (rmd.mg_source === 'process-refund' && rmd.mg_part !== 'remainder') {
      const mainPi = typeof refund.payment_intent === 'string' ? refund.payment_intent : (refund.payment_intent as any)?.id || null
      restHaleru = await remainderForMainHaleru(stripe as unknown as OtherIntentsStripe, supabase, { bookingId, mainPi, mainRefundId: refund.id })
    }
    const refundedAmountCZK = ((refund.amount || 0) + restHaleru) / 100
    let cardBrand: string | null = null
    let cardLast4: string | null = null
    try {
      const chargeId = typeof refund.charge === 'string' ? refund.charge : (refund.charge as any)?.id
      if (chargeId) {
        const ch = await stripe.charges.retrieve(chargeId)
        cardBrand = ch?.payment_method_details?.card?.brand || null
        cardLast4 = ch?.payment_method_details?.card?.last4 || null
      }
    } catch { /* non-fatal */ }

    // Načti booking + customer pro template
    const { data: bkRow } = await supabase.from('bookings')
      .select('user_id, total_price, start_date, end_date, motorcycles!moto_id(model), profiles:user_id(id, full_name, email, phone, street, city, zip, ico, dic)')
      .eq('id', bookingId).single()
    if (!bkRow) return { creditNoteId: null, pdfPath: null, refundId: bk.stripe_refund_id }
    const refundPercent = (bkRow.total_price && bkRow.total_price > 0)
      ? Math.round((refundedAmountCZK / Number(bkRow.total_price)) * 100) : 100

    // Najít původní fakturu (payment_receipt / final / proforma) pro reference
    const { data: origInvs } = await supabase.from('invoices')
      .select('id, number')
      .eq('booking_id', bookingId)
      .neq('status', 'cancelled')
      .in('type', ['final', 'payment_receipt', 'advance', 'proforma'])
      .order('issue_date', { ascending: false }).limit(1)
    const originalInvoiceId = origInvs?.[0]?.id || null
    const originalInvoiceNumber = origInvs?.[0]?.number || null

    // Souběh s process-refund, které právě vystavuje dobropis k téže vratce (Stripe volání výše
    // trvají) → znovu ověřit těsně před vložením.
    const { data: dupe2 } = await supabase.from('invoices')
      .select('id, pdf_path').eq('stripe_refund_id', bk.stripe_refund_id).limit(1)
    if (dupe2?.length) {
      return { creditNoteId: dupe2[0].id, pdfPath: dupe2[0].pdf_path, refundId: bk.stripe_refund_id }
    }

    // Číslo dobropisu (DB-YYYY-NNNN) — atomicky, automatická řada < 5000.
    const cnNumber = await nextDocNumber(supabase, 'DB')
    const issueDate = new Date().toISOString().slice(0, 10)
    // Výpůjčka výbavy (2026-10-23): bez motorky → „výpůjčka výbavy“ (gear) / „motorky“ (gear.ts).
    const motoModel = (bkRow as any).motorcycles?.model || await noMotoRefundSubject(supabase, bookingId)
    // Důvod z naší vratky (zkrácení / výměna / úprava …); externí vratka (Stripe portál) = storno.
    const reasonText = rmd.mg_source === 'process-refund' && rmd.mg_reason ? reasonTextFor(rmd.mg_reason) : 'Storno rezervace'

    const { data: cnInv } = await supabase.from('invoices').insert({
      number: cnNumber,
      type: 'credit_note',
      customer_id: bkRow.user_id,
      booking_id: bookingId,
      items: [{ description: `Dobropis – ${reasonText} (${motoModel})`, qty: 1, unit_price: -refundedAmountCZK }],
      subtotal: -refundedAmountCZK,
      tax_amount: 0,
      total: -refundedAmountCZK,
      notes: `Dobropis k rezervaci. ${refundPercent < 100 ? `Částečný refund ${refundPercent}%.` : 'Plný refund.'} ${reasonText} (recovery).`
        + (restHaleru > 0 ? ` Vráceno z více plateb: ${refund.id} + ${restHaleru / 100} Kč z dalších plateb rezervace.` : ''),
      issue_date: issueDate,
      due_date: issueDate,
      status: 'issued',
      source: 'refund',
      variable_symbol: cnNumber,
      original_invoice_id: originalInvoiceId,
      stripe_refund_id: bk.stripe_refund_id,
    }).select('id').single()
    if (!cnInv?.id) return { creditNoteId: null, pdfPath: null, refundId: bk.stripe_refund_id }

    // accounting_entries nemá sloupce vat_rate/source/entry_date — insert s nimi
    // tiše padal (chyba se zahazovala) a dobropis se nikdy nezaúčtoval
    await supabase.from('accounting_entries').insert({
      type: 'expense', amount: -refundedAmountCZK,
      description: `Dobropis ${cnNumber} - ${reasonText}`,
      category: 'refund',
      date: issueDate, booking_id: bookingId, invoice_id: cnInv.id,
    }).then(() => {}, () => {})

    const cust2 = (bkRow as any).profiles || {}
    await loadCustomerCompany(supabase, cust2)
    const html = renderCreditNoteHtml({
      number: cnNumber, issueDate: fmtDate(issueDate), reasonText, motoModel,
      refundAmount: refundedAmountCZK, refundPercent,
      bookingDates: `${fmtDate(bkRow.start_date)} – ${fmtDate(bkRow.end_date)}`,
      customer: cust2, originalInvoiceNumber,
      stripeRefundId: bk.stripe_refund_id, cardBrand, cardLast4,
    })
    const pdfBytes = await htmlToPdf(html)
    const path = pdfBytes ? `invoices/${cnInv.id}.pdf` : `invoices/${cnInv.id}.html`
    await supabase.storage.from('documents').upload(
      path,
      pdfBytes ? new Blob([pdfBytes], { type: 'application/pdf' }) : new Blob([html], { type: 'text/html' }),
      { upsert: true, contentType: pdfBytes ? 'application/pdf' : 'text/html' },
    )
    await supabase.from('invoices').update({ pdf_path: path }).eq('id', cnInv.id)
    return { creditNoteId: cnInv.id, pdfPath: path, refundId: bk.stripe_refund_id }
  } catch (e) {
    console.warn('[createCreditNoteForExistingRefund] failed:', (e as Error).message)
    return { creditNoteId: null, pdfPath: null, refundId: bk.stripe_refund_id || null }
  }
}

// Manuální vratka pro booking BEZ reálně zaplacené Stripe platby (QR/převod/
// hotově/ručně označená paid) — 2026-08-04 flow:
//  1. vystaví DOBROPIS (credit_note, stripe_refund_id NULL = manuální)
//     + účetní záznam — položkově, stejně jako Stripe větev,
//  2. rezervace → 'refund_pending' („Čeká na vrácení" ve Velíně; banner
//     „Vrátit X Kč na účet zákazníka" + akce „Vratka odeslána"/„Potvrdit vrácení"),
//  3. vrátí success + manual:true, aby volající (web/app/RPC/Velín) commit
//     dokončil a zákazníkovi ukázal „vrátíme do 14 dnů".
// Volá se ze dvou míst: a) booking nemá PI ani (zaplacenou) session,
// b) PI existuje, ale Stripe na něm nikdy nepřijal peníze (stale PI
//    z opuštěného pokusu o kartu — viz fix 2026-08-21 v serve handleru).
// ===== Fio API — automatické odeslání vratky převodem (parita se Stripe) =====
// Rezervace zaplacené QR / převodem na Fio účet se vrací AUTOMATICKY: platební
// příkaz se podá přes Fio API Bankovnictví (POST /v1/rest/import/, Fio XML
// DomesticTransaction — viz https://www.fio.cz/docs/cz/API_Bankovnictvi.pdf).
// Cílový účet = protiúčet příchozí platby z `fio_transactions` (plní fio-sync).
// Idempotence: UNIQUE(credit_note_id) v `fio_payment_orders` — jeden dobropis
// = maximálně JEDEN odeslaný příkaz, souběžný dispatch dostane konflikt.
// Když příkaz nejde odeslat (chybí token / protiúčet / platba nešla na Fio /
// banka odmítla), flow spadne na dosavadní ruční fallback (refund_pending +
// banner „VRÁTIT NA ÚČET" ve Velíně) — peníze se NIKDY nepošlou dvakrát ani
// naslepo. Token: FIO_PAYMENT_TOKEN (doporučený samostatný token s právem
// zadávání příkazů — vlastní 30s limit), fallback FIO_API_TOKEN.
const FIO_REFUND_TOKEN = Deno.env.get('FIO_PAYMENT_TOKEN') || Deno.env.get('FIO_API_TOKEN') || ''
const FIO_IMPORT_URL = 'https://fioapi.fio.cz/v1/rest/import/'
const OPS_EMAIL = 'info@motogo24.cz'

/** Atomicky přidělí další číslo dokladové řady (PREFIX-YYYY-NNNN).
 *
 *  Primárně přes RPC `next_document_number` — ta drží row-lock nad
 *  `document_number_counters`, takže dvě souběžné invokace nikdy nedostanou
 *  totéž číslo. Dřív se tu skládalo `MAX+1` read-then-write bez zámku; nad
 *  `invoices.number` je UNIQUE index, takže souběh nekončil duplicitou, ale
 *  SPADLÝM zápisem — a zákazníkovi doklad prostě nevznikl (viz DB-2026-0001 2×).
 *
 *  Fallback na původní MAX+1 zůstává jen pro případ, že RPC selže — ať
 *  výpadek číselníku nezablokuje fakturaci úplně.
 */
async function nextDocNumber(supabase: any, prefix: string): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('next_document_number', { p_prefix: prefix })
    if (!error && typeof data === 'string' && /^[A-Z]{2}-\d{4}-\d{4}$/.test(data)) return data
    if (error) console.warn(`[doc-number] RPC next_document_number selhala (${error.message}) — fallback MAX+1`)
  } catch (e) {
    console.warn('[doc-number] RPC next_document_number nedostupná — fallback MAX+1:', (e as Error).message)
  }
  const year = new Date().getFullYear()
  const { data: last } = await supabase.from('invoices').select('number')
    .like('number', `${prefix}-${year}-%`).lt('number', `${prefix}-${year}-5000`)
    .order('number', { ascending: false }).limit(1)
  let seq = 1
  if (last?.length) { const m = last[0].number.match(/-(\d+)$/); if (m) seq = parseInt(m[1], 10) + 1 }
  return `${prefix}-${year}-${String(seq).padStart(4, '0')}`
}

const xmlEscape = (s: string) =>
  s.replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c] || c))

async function sendOpsMail(subject: string, html: string) {
  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? ''
    const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    await fetch(`${SUPABASE_URL}/functions/v1/send-email`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + SERVICE_KEY, apikey: SERVICE_KEY },
      body: JSON.stringify({ to: OPS_EMAIL, subject, raw_html: html }),
    })
  } catch (e) { console.warn('[process-refund] ops mail failed:', (e as Error).message) }
}

async function tryFioRefund(
  supabase: any,
  booking_id: string,
  cnId: string | null,
  cnNumber: string | null,
  amount: number,
  reasonText: string,
  dlog: (action: string, status: string, extra?: Record<string, unknown>) => unknown,
): Promise<{ sent: boolean; instructionId?: string | null }> {
  if (!FIO_REFUND_TOKEN || !cnId || !(amount > 0)) return { sent: false }
  const bookingNumber = String(booking_id).slice(-8).toUpperCase()
  try {
    // 1) Zdrojový účet = účet tokenu. Bereme z company_info.bank_account a
    //    vyžadujeme kód banky 2010 (Fio) — dokud company_info míří na starý
    //    účet (mBank), automatická vratka se nepokouší (peníze tam nepřišly).
    const { data: ci } = await supabase.from('app_settings').select('value').eq('key', 'company_info').maybeSingle()
    const bankAccount = String((ci?.value as any)?.bank_account || '').replace(/\s+/g, '')
    const accMatch = bankAccount.match(/^(?:(\d{1,6})-)?(\d{2,10})\/(\d{4})$/)
    if (!accMatch || accMatch[3] !== '2010') {
      await dlog('fio_refund_skipped_not_fio_account', 'info', { bank_account: bankAccount })
      return { sent: false }
    }
    const accountFrom = accMatch[1] ? `${accMatch[1]}-${accMatch[2]}` : accMatch[2]

    // 2) Cílový účet = protiúčet PŘÍCHOZÍ platby této rezervace (fio_transactions
    //    plní fio-sync). Primárně dle booking_id (spárované auto-potvrzení),
    //    fallback dle VS (platba zaevidovaná, ale potvrzená ručně).
    const { data: bk } = await supabase.from('bookings')
      .select('payment_vs, mod_surcharge_vs').eq('id', booking_id).maybeSingle()
    let src: { counter_account: string | null; counter_bank: string | null } | null = null
    const { data: byBooking } = await supabase.from('fio_transactions')
      .select('counter_account, counter_bank').eq('booking_id', booking_id)
      .gt('amount', 0).not('counter_account', 'is', null)
      .order('fio_id', { ascending: false }).limit(1)
    src = byBooking?.[0] || null
    if (!src) {
      const vses = [bk?.payment_vs, bk?.mod_surcharge_vs].filter(Boolean).map(String)
      if (vses.length > 0) {
        const { data: byVs } = await supabase.from('fio_transactions')
          .select('counter_account, counter_bank').in('vs', vses)
          .gt('amount', 0).not('counter_account', 'is', null)
          .order('fio_id', { ascending: false }).limit(1)
        src = byVs?.[0] || null
      }
    }
    if (!src?.counter_account || !src?.counter_bank) {
      await dlog('fio_refund_no_source_account', 'info', { note: 'platba rezervace nedohledána ve fio_transactions — ruční vratka' })
      return { sent: false }
    }

    // 3) Idempotentní claim: UNIQUE(credit_note_id). Konflikt = příkaz už
    //    vznikl dřív — submitted vrátíme jako hotovo, cokoli jiného necháme
    //    na ručním fallbacku (žádné opakované odeslání peněz).
    const vsOut = String(bk?.payment_vs || cnNumber || '').replace(/\D/g, '').slice(0, 10) || null
    const msg = `MotoGo24 vratka ${bookingNumber} - ${reasonText}`.slice(0, 140)
    const { data: claim } = await supabase.from('fio_payment_orders')
      .upsert({
        credit_note_id: cnId, booking_id, amount,
        account_to: src.counter_account, bank_code: src.counter_bank,
        vs: vsOut, message: msg, status: 'pending',
      }, { onConflict: 'credit_note_id', ignoreDuplicates: true })
      .select('id').maybeSingle()
    if (!claim?.id) {
      const { data: prev } = await supabase.from('fio_payment_orders')
        .select('status, fio_instruction_id').eq('credit_note_id', cnId).maybeSingle()
      await dlog('fio_refund_claim_conflict', 'info', { prev_status: prev?.status || null })
      return prev?.status === 'submitted'
        ? { sent: true, instructionId: prev?.fio_instruction_id || null }
        : { sent: false }
    }

    // 4) Fio XML tuzemský příkaz (pořadí elementů dle importIB.xsd).
    const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'Europe/Prague' })
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Import xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.fio.cz/schema/importIB.xsd">
<Orders>
<DomesticTransaction>
<accountFrom>${xmlEscape(accountFrom)}</accountFrom>
<currency>CZK</currency>
<amount>${amount.toFixed(2)}</amount>
<accountTo>${xmlEscape(String(src.counter_account))}</accountTo>
<bankCode>${xmlEscape(String(src.counter_bank))}</bankCode>
${vsOut ? `<vs>${vsOut}</vs>\n` : ''}<date>${today}</date>
<messageForRecipient>${xmlEscape(msg)}</messageForRecipient>
<comment>${xmlEscape('Dobropis ' + (cnNumber || ''))}</comment>
<paymentType>431001</paymentType>
</DomesticTransaction>
</Orders>
</Import>`

    // 5) Upload (multipart/form-data). 409 = 30s interval tokenu (sdílený se
    //    sync cronem) → jednou počkej a zopakuj.
    const submit = async () => {
      const fd = new FormData()
      fd.append('type', 'xml')
      fd.append('token', FIO_REFUND_TOKEN)
      fd.append('file', new Blob([xml], { type: 'application/xml' }), 'vratka.xml')
      return await fetch(FIO_IMPORT_URL, { method: 'POST', body: fd })
    }
    let resp = await submit()
    if (resp.status === 409) {
      await new Promise((r) => setTimeout(r, 31_000))
      resp = await submit()
    }
    const text = await resp.text()
    const errorCode = Number((text.match(/<errorCode>(\d+)<\/errorCode>/) || [])[1] ?? NaN)
    const instructionId = (text.match(/<idInstruction>(\d+)<\/idInstruction>/) || [])[1] || null
    // errorCode 0 = přijato, 2 = varování kontrol (příkazy s warning banka přijala)
    const ok = resp.ok && (errorCode === 0 || errorCode === 2)

    await supabase.from('fio_payment_orders').update({
      status: ok ? 'submitted' : 'failed',
      fio_instruction_id: instructionId,
      error: ok ? null : `HTTP ${resp.status}, errorCode ${Number.isNaN(errorCode) ? '?' : errorCode}: ${text.slice(0, 400)}`,
      submitted_at: ok ? new Date().toISOString() : null,
    }).eq('id', claim.id)
    await dlog(ok ? 'fio_refund_submitted' : 'fio_refund_failed', ok ? 'ok' : 'error', {
      amount, account_to: src.counter_account + '/' + src.counter_bank,
      fio_instruction_id: instructionId, http_status: resp.status,
      error_code: Number.isNaN(errorCode) ? null : errorCode,
      ...(ok ? {} : { response: text.slice(0, 400) }),
    })

    if (ok) {
      await sendOpsMail(
        `✅ Fio: vratka ${amount.toLocaleString('cs-CZ')} Kč odeslána (rez. #${bookingNumber}, dávka ${instructionId || '—'})`,
        `<h2 style="margin:0 0 8px;font-size:18px;color:#0f1a14">✅ Vratka odeslána automaticky přes Fio API</h2>
         <p style="margin:0 0 12px;color:#374151;font-size:14px">Vratka <strong>${amount.toLocaleString('cs-CZ')} Kč</strong> (${reasonText.toLowerCase()}, dobropis ${cnNumber || '—'}) k rezervaci <strong>#${bookingNumber}</strong> byla podána jako platební příkaz na účet <strong>${src.counter_account}/${src.counter_bank}</strong>, VS ${vsOut || '—'}, dávka č. ${instructionId || '—'}${errorCode === 2 ? ' (přijato s varováním kontrol)' : ''}.</p>
         <p style="margin:0;color:#b45309;font-size:13px">Pokud má účet nastavenou dodatečnou autorizaci API dávek, potvrďte dávku v internetbankingu — bez toho banka příkaz nezpracuje.</p>`
      )
    } else {
      await sendOpsMail(
        `⚠️ Fio: vratku ${amount.toLocaleString('cs-CZ')} Kč se NEPODAŘILO odeslat (rez. #${bookingNumber})`,
        `<h2 style="margin:0 0 8px;font-size:18px;color:#0f1a14">⚠️ Automatická vratka přes Fio selhala — pošlete ručně</h2>
         <p style="margin:0 0 12px;color:#374151;font-size:14px">Platební příkaz na <strong>${amount.toLocaleString('cs-CZ')} Kč</strong> (dobropis ${cnNumber || '—'}, rezervace <strong>#${bookingNumber}</strong>, účet ${src.counter_account}/${src.counter_bank}) banka nepřijala. Rezervace zůstává ve stavu „Čeká na vrácení" — pošlete vratku ručně převodem a potvrďte ve Velíně tlačítkem „Vratka odeslána".</p>
         <p style="margin:0;color:#6b7280;font-size:12px">Detail chyby: HTTP ${resp.status}, errorCode ${Number.isNaN(errorCode) ? '?' : errorCode}. Viz debug log (fio_refund_failed).</p>`
      )
    }
    return ok ? { sent: true, instructionId } : { sent: false }
  } catch (e) {
    await dlog('fio_refund_exception', 'error', { error: (e as Error).message })
    return { sent: false }
  }
}

// ── Strop ZÁKAZNICKÉ vratky (2026-10-11) ─────────────────────────────────────
// Zákazník (appka) smí dostat zpět jen PŘEPLATEK: co rezervace reálně zaplatila,
// minus co se už vrátilo, minus její AKTUÁLNÍ total_price (appka nižší cenu zapíše
// dřív, než refund zavolá — reservation_edit_screen). Stripe: customerCapHaleru
// (other-intents.ts — od opravy f2 2026-10-22 jen platby V CENĚ rezervace, tentýž
// výběr, ze kterého hlavní vratka i zbytek vrací). Převod / QR: níže.

/** Převod / QR: příchozí platby rezervace (fio_transactions dle booking_id nebo VS)
 *  − ruční dobropisy − total_price; Kč. Chyba = 0 (fail closed → vyřídí obsluha). */
async function customerManualCapCzk(supabase: any, bookingId: string, totalPrice: number): Promise<number> {
  try {
    const { data: bk } = await supabase.from('bookings')
      .select('payment_vs, mod_surcharge_vs').eq('id', bookingId).maybeSingle()
    const rows = new Map<string, number>()
    const { data: byId, error: e1 } = await supabase.from('fio_transactions')
      .select('fio_id, amount').eq('booking_id', bookingId).gt('amount', 0)
    if (e1) return 0
    for (const r of byId || []) rows.set(String(r.fio_id), Number(r.amount) || 0)
    const vses = [bk?.payment_vs, bk?.mod_surcharge_vs].filter(Boolean).map(String)
    if (vses.length) {
      const { data: byVs } = await supabase.from('fio_transactions')
        .select('fio_id, amount').in('vs', vses).gt('amount', 0)
      for (const r of byVs || []) rows.set(String(r.fio_id), Number(r.amount) || 0)
    }
    const paid = [...rows.values()].reduce((s, v) => s + v, 0)
    const { data: cns, error: e2 } = await supabase.from('invoices').select('total')
      .eq('booking_id', bookingId).eq('type', 'credit_note').neq('status', 'cancelled')
      .is('stripe_refund_id', null)
    if (e2) return 0
    const refunded = (cns || []).reduce((s: number, c: any) => s + Math.abs(Number(c.total) || 0), 0)
    return Math.max(0, Math.round((paid - refunded - (Number(totalPrice) || 0)) * 100) / 100)
  } catch { return 0 }
}

/** Spodní věrohodná mez ceny rezervace (Kč) ze serverového ceníku; null = nelze ověřit. */
async function customerPriceFloorCzk(supabase: any, bookingId: string): Promise<number | null> {
  try {
    const { data: bk } = await supabase.from('bookings')
      .select('moto_id, start_date, end_date').eq('id', bookingId).maybeSingle()
    // Výpůjčka výbavy (2026-10-23): mez z ceny výbavy × dny (gear.ts) — bez motorky dřív null = vždy obsluha.
    const gearBk = bk && !bk.moto_id ? await loadGearRefundRow(supabase, bookingId) : null
    if (gearBk) return await gearPriceFloorCzk(supabase, gearBk, bookingId)
    if (!bk?.moto_id || !bk?.start_date || !bk?.end_date) return null
    const s = String(bk.start_date).slice(0, 10), e = String(bk.end_date).slice(0, 10)
    const { data: sum, error } = await supabase.rpc('_moto_dayprice_sum', { p_moto_id: bk.moto_id, p_start: s, p_end: e })
    if (error) return null
    const { data: m } = await supabase.from('motorcycles')
      .select('price_mon, price_tue, price_wed, price_thu, price_fri, price_sat, price_sun').eq('id', bk.moto_id).maybeSingle()
    const maxDay = Math.max(0, ...Object.values(m || {}).map((v) => Number(v) || 0))
    const { data: disc } = await supabase.from('booking_discounts').select('amount').eq('booking_id', bookingId)
    const discounts = (disc || []).reduce((t: number, d: any) => t + Math.max(0, Number(d.amount) || 0), 0)
    return Math.max(0, Math.floor(0.8 * (Number(sum) || 0) - 0.5 * maxDay - discounts))
  } catch { return null }
}

/** Zákaznická vratka bez ověřeného přeplatku → nic se nevrací, stav se nemění,
 *  obsluha dostane mail (max 1× za 10 min na rezervaci). HTTP 200 + success:false,
 *  aby appka (functions.invoke hází na ne-2xx) ukázala srozumitelný text. */
async function customerRefundNeedsStaff(
  supabase: any, bookingId: string, amount: unknown, reason: string | undefined,
  dlog: (action: string, status: string, extra?: Record<string, unknown>) => unknown,
): Promise<Response> {
  let recent = false
  try {
    const { data: prev } = await supabase.from('debug_log').select('id')
      .eq('source', 'process-refund').eq('action', 'customer_refund_needs_staff')
      .eq('request_data->>booking_id', bookingId)
      .gte('created_at', new Date(Date.now() - 10 * 60_000).toISOString()).limit(1)
    recent = !!prev?.length
  } catch { /* bez dedupu */ }
  await dlog('customer_refund_needs_staff', 'info', { requested: amount ?? null })
  if (!recent) {
    const num = String(bookingId).slice(-8).toUpperCase()
    const amt = (Number(amount) || 0).toLocaleString('cs-CZ')
    await sendOpsMail(
      `⚠️ Vratku za úpravu rezervace #${num} vyřiďte ručně`,
      `<p>Zákazník v aplikaci upravil rezervaci <strong>#${num}</strong> (${reasonTextFor(reason)}) a požádal o vrácení <strong>${amt} Kč</strong>.</p>`
      + '<p>Automatická vratka NEPROBĚHLA — k rezervaci se nenašel ověřený přeplatek (platby Stripe / Fio − vrácené − aktuální cena). '
      + 'Zkontrolujte platby a případně vraťte ručně z detailu rezervace ve Velíně.</p>',
    )
  }
  return new Response(
    JSON.stringify({ success: false, code: 'refund_needs_staff', error: 'Změna je uložená. Vrácení peněz za ni vyřídí obsluha ručně — ozveme se vám.' }),
    { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
  )
}

async function manualBookingRefund(
  supabase: any,
  booking_id: string,
  amount: number | undefined,
  reason: string | undefined,
  dlog: (action: string, status: string, extra?: Record<string, unknown>) => unknown,
  customerCap = false,
): Promise<Response> {
  const { data: bkFull } = await supabase.from('bookings')
    .select('user_id, total_price, start_date, end_date, motorcycles!moto_id(model), profiles:user_id(id, full_name, email, phone, street, city, zip, ico, dic)')
    .eq('id', booking_id).single()
  const totalPrice = Number(bkFull?.total_price || 0)
  let manAmount = Number(amount) > 0 ? Number(amount) : totalPrice
  if (totalPrice > 0 && manAmount > totalPrice) manAmount = totalPrice
  // Zákazník (appka): jen ověřený přeplatek z příchozích plateb (strop výše).
  // Souběžný duplicitní dispatch TÉŽE částky (čerstvý ruční dobropis ≤15 min)
  // strop přeskočí — vyřeší ho dedup níže (žádná druhá vratka).
  const requestedCzk = Number(amount) > 0 ? Number(amount) : 0
  if (customerCap && manAmount > 0) {
    const { data: dupCn } = await supabase.from('invoices').select('id')
      .eq('booking_id', booking_id).eq('type', 'credit_note').neq('status', 'cancelled')
      .is('stripe_refund_id', null).eq('total', -manAmount)
      .gte('created_at', new Date(Date.now() - 15 * 60_000).toISOString()).limit(1)
    if (!dupCn?.length) {
      const capCzk = await customerManualCapCzk(supabase, booking_id, totalPrice)
      if (manAmount > capCzk) manAmount = capCzk
      if (!(manAmount > 0)) return await customerRefundNeedsStaff(supabase, booking_id, amount, reason, dlog)
    }
  }
  // f2: zákazníkovi se vrací méně, než požadoval (strop ověřeného přeplatku; zbytek nad 1 Kč —
  // menší = zaokrouhlení) → odpověď `partial` (appka neslibuje celou částku) + obsluha dostane
  // mail níže (po vystavení dobropisu).
  const partial = requestedCzk > 0 && manAmount > 0
    && Math.round((requestedCzk - manAmount) * 100) > (customerCap ? CUSTOMER_SHORT_TOLERANCE_HALERU : 0)

  if (manAmount <= 0) {
    await dlog('manual_refund_noop_zero', 'info', { manual: true })
    return new Response(
      JSON.stringify({ success: true, manual: true, code: 'manual_refund_pending', amount: 0, credit_note_id: null }),
      { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
    )
  }

  const reasonText = reasonTextFor(reason)
  // Výpůjčka výbavy (2026-10-23): bez motorky → „výpůjčka výbavy“ (gear) / „motorky“ (gear.ts).
  const motoModel = (bkFull as any)?.motorcycles?.model || await noMotoRefundSubject(supabase, booking_id)
  const refundPercent = totalPrice > 0 ? Math.min(100, Math.round((manAmount / totalPrice) * 100)) : 100

  // Dedup: souběžný dispatch téže manuální vratky (pg_net z RPC + retry
  // v send-booking-email) → čerstvý manuální dobropis na stejnou částku
  // (≤15 min, bez Stripe refund id) = už vystaveno, vrať existující.
  const { data: freshManCn } = await supabase.from('invoices')
    .select('id, number, pdf_path')
    .eq('booking_id', booking_id).eq('type', 'credit_note').neq('status', 'cancelled')
    .is('stripe_refund_id', null)
    .eq('total', -manAmount)
    .gte('created_at', new Date(Date.now() - 15 * 60_000).toISOString())
    .order('created_at', { ascending: false }).limit(1)
  let cnId: string | null = freshManCn?.[0]?.id || null
  let cnNumber: string | null = freshManCn?.[0]?.number || null
  let cnPdfPath: string | null = freshManCn?.[0]?.pdf_path || null
  const reusedCn = !!cnId

  if (!cnId) {
    const { data: origInvs } = await supabase.from('invoices')
      .select('id, number')
      .eq('booking_id', booking_id).neq('status', 'cancelled')
      .in('type', ['final', 'payment_receipt', 'advance', 'proforma'])
      .order('issue_date', { ascending: false }).limit(1)
    cnNumber = await nextDocNumber(supabase, 'DB')
    const issueDate = new Date().toISOString().slice(0, 10)

    const { data: cnInv, error: manCnErr } = await supabase.from('invoices').insert({
      number: cnNumber,
      type: 'credit_note',
      customer_id: bkFull?.user_id || null,
      booking_id,
      items: [{
        description: `Dobropis – ${reasonText} (${motoModel})`,
        qty: 1,
        unit_price: -manAmount,
      }],
      subtotal: -manAmount,
      tax_amount: 0,
      total: -manAmount,
      notes: `Dobropis k rezervaci. ${refundPercent < 100 ? `Částečný refund ${refundPercent}%.` : 'Plný refund.'} ${reasonText}. MANUÁLNÍ VRATKA — bez Stripe platby, k vrácení převodem na účet do 14 dnů.`,
      issue_date: issueDate,
      due_date: issueDate,
      status: 'issued',
      source: 'refund',
      variable_symbol: cnNumber,
      original_invoice_id: origInvs?.[0]?.id || null,
      stripe_refund_id: null,
    }).select('id').single()
    cnId = cnInv?.id || null
    await dlog('manual_credit_note_inserted', cnId ? 'info' : 'error',
      { credit_note_id: cnId, number: cnNumber, amount: manAmount, error: manCnErr?.message || null })
    if (!cnId) {
      // Vratka je domluvená, ale doklad k ní nevznikl — bez upozornění by to
      // nikdo nezjistil, dokud si zákazník neřekne o dobropis.
      await sendOpsMail(
        '⚠️ Dobropis k ruční vratce se nevystavil',
        `<p>Rezervace <strong>${booking_id}</strong>: ruční vratka <strong>${manAmount} Kč</strong>, `
        + `ale zápis dobropisu <strong>${cnNumber}</strong> selhal: ${manCnErr?.message || 'prázdná odpověď'}.</p>`
        + '<p>Vystavte dobropis ručně ve Velíně.</p>',
      )
    }

    if (cnId) {
      await supabase.from('accounting_entries').insert({
        type: 'expense',
        amount: -manAmount,
        description: `Dobropis ${cnNumber} – ${reasonText} (manuální vratka na účet)`,
        category: 'refund',
        date: issueDate,
        booking_id,
      })
      try {
        const cust3 = (bkFull as any)?.profiles || {}
        await loadCustomerCompany(supabase, cust3)
        const html = renderCreditNoteHtml({
          number: cnNumber, issueDate: fmtDate(issueDate), reasonText, motoModel,
          refundAmount: manAmount, refundPercent,
          bookingDates: `${fmtDate(String((bkFull as any)?.start_date || ''))} – ${fmtDate(String((bkFull as any)?.end_date || ''))}`,
          customer: cust3,
          originalInvoiceNumber: origInvs?.[0]?.number || null,
          stripeRefundId: null, manual: true,
        })
        const pdfBytes = await htmlToPdf(html)
        cnPdfPath = pdfBytes ? `invoices/${cnId}.pdf` : `invoices/${cnId}.html`
        await supabase.storage.from('documents').upload(
          cnPdfPath,
          pdfBytes ? new Blob([pdfBytes], { type: 'application/pdf' }) : new Blob([html], { type: 'text/html' }),
          { upsert: true, contentType: pdfBytes ? 'application/pdf' : 'text/html' },
        )
        await supabase.from('invoices').update({ pdf_path: cnPdfPath }).eq('id', cnId)
      } catch (e) {
        console.warn('[process-refund] manual CN pdf failed:', (e as Error).message)
      }
    }
  }

  if (customerCap && partial && !reusedCn) {
    const num = String(booking_id).slice(-8).toUpperCase()
    await dlog('refund_short', 'error', { manual: true, requested: requestedCzk, refunded: manAmount, customer: true })
    await sendOpsMail(
      `⚠️ Vratku za úpravu rezervace #${num} dořešte ručně (vráceno jen částečně)`,
      `<p>Zákazník v aplikaci upravil rezervaci <strong>#${num}</strong> (${reasonText}) a požádal o vrácení <strong>${requestedCzk.toLocaleString('cs-CZ')} Kč</strong>. `
      + `Dobropis ${cnNumber || '—'} je jen na <strong>${manAmount.toLocaleString('cs-CZ')} Kč</strong> — ověřený přeplatek z příchozích plateb převodem (platby − ruční dobropisy − aktuální cena).</p>`
      + '<p>Zbytek zkontrolujte a případně vraťte ručně ve Velíně.</p>',
    )
  }
  // AUTOMATICKÁ VRATKA PŘES FIO API (parita se Stripe): platba přijatá na Fio
  // účet se vrací platebním příkazem na protiúčet, ze kterého přišla. Když
  // příkaz odejde, rezervace jde rovnou do finálního stavu (refunded /
  // partial_refund — stejně jako Stripe refund) a ruční banner se nezobrazí.
  const fio = await tryFioRefund(supabase, booking_id, cnId, cnNumber, manAmount, reasonText, dlog)
  if (fio.sent) {
    // Zákaznická vratka = jen přeplatek → rezervace s nenulovou cenou zůstává zaplacená.
    const newStatus = refundPercent >= 100 && !(customerCap && totalPrice > 0) ? 'refunded' : 'partial_refund'
    await supabase.from('bookings').update({ payment_status: newStatus }).eq('id', booking_id)
    try {
      if (cnId) {
        await supabase.from('invoices').update({
          notes: `Dobropis k rezervaci. ${refundPercent < 100 ? `Částečný refund ${refundPercent}%.` : 'Plný refund.'} ${reasonText}. Vratka odeslána automaticky převodem přes Fio API (dávka ${fio.instructionId || '—'}).`,
        }).eq('id', cnId)
      }
    } catch { /* poznámka na dokladu — neblokuje */ }
    await dlog('fio_refund_done', 'ok', {
      manual: true, fio_sent: true, amount: manAmount, credit_note_id: cnId,
      new_payment_status: newStatus, fio_instruction_id: fio.instructionId || null,
    })
    return new Response(
      JSON.stringify({
        success: true, manual: true, fio_sent: true, code: 'fio_refund_sent',
        amount: manAmount, credit_note_id: cnId, credit_note_pdf_path: cnPdfPath,
        fio_instruction_id: fio.instructionId || null, partial,
      }),
      { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
    )
  }

  await supabase.from('bookings')
    .update({ payment_status: 'refund_pending' })
    .eq('id', booking_id)
  await dlog('manual_refund_pending', 'info', {
    manual: true, amount: manAmount, credit_note_id: cnId,
    note: 'no Stripe payment — vratka k ručnímu vyřízení převodem na účet (do 14 dnů)',
  })
  return new Response(
    JSON.stringify({
      success: true, manual: true, code: 'manual_refund_pending',
      amount: manAmount, credit_note_id: cnId, credit_note_pdf_path: cnPdfPath, partial,
    }),
    { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
  )
}

// Ručně potvrzená platba (QR / převod / hotově / krypto / voucher) — žádné peníze na Stripe.
const MANUAL_PAY_METHODS = ['bank_transfer', 'qr', 'cash', 'crypto', 'voucher', 'wire']
function isManualPayment(d: any): boolean {
  const m = String(d?.payment_method || '').toLowerCase().trim()
  return MANUAL_PAY_METHODS.includes(m) || (!m && d?.pay_channel === 'qr')
}

// Idempotentní odpověď „už vráceno“: dohraje PDF / chybějící dobropis k uložené vratce, Stripe nevolá.
async function respondAlreadyRefunded(
  supabase: any, booking_id: string, data: any,
  dlog: (action: string, status: string, extra?: Record<string, unknown>) => unknown,
): Promise<Response> {
  let result = await ensureCreditNotePdf(supabase, booking_id, data)
  // Recovery: pokud credit_note row vůbec neexistuje (process-refund spadl
  // dřív než stihl INSERT), vytvoř ho ze Stripe refund dat. Tohle je hlavní
  // safety-net cesta, kterou volá webhook-receiver charge.refunded.
  if (!result.creditNoteId && data.stripe_refund_id) {
    await dlog('credit_note_recovery_create', 'info', { stripe_refund_id: data.stripe_refund_id })
    result = await createCreditNoteForExistingRefund(supabase, booking_id, data)
    await dlog('credit_note_recovery_create_done', result.creditNoteId ? 'ok' : 'error', { credit_note_id: result.creditNoteId, pdf_path: result.pdfPath })
  }
  return new Response(
    JSON.stringify({
      success: true,
      already_refunded: true,
      refund_id: data.stripe_refund_id || result.refundId,
      credit_note_id: result.creditNoteId,
      credit_note_pdf_path: result.pdfPath,
      card_brand: data.card_brand,
      card_last4: data.card_last4,
    }),
    { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
  )
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS })
  }

  // Bezpečnostní gate: refund smí spustit service_role (DB triggery / webhook),
  // admin (Velín), NEBO přihlášený zákazník POUZE pro VLASTNÍ rezervaci/objednávku
  // (appka — zkrácení rezervace). Anon (jen apikey) je odmítnut. Ověření
  // vlastnictví u 'user' proběhne po načtení booking/order níže.
  const caller = await authClassify(req)
  if (caller.kind === 'none') return forbidden(CORS, 'auth_required')

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  )
  let cancelLockBooking: string | null = null // HOTFIX storno 2026-10-29: uvolní se ve finally

  try {
    const body: RefundRequest = await req.json()
    const { booking_id, order_id, amount, reason } = body

    // Diagnostika — admin v Velin → Dokumenty → Debug log uvidí každý krok
    // refund flow a okamžitě pozná, kde to padá. Helper, aby fail v debug_log
    // insertu nezablokoval hlavní flow.
    const dlog = (action: string, status: string, extra?: Record<string, unknown>) =>
      supabase.from('debug_log').insert({
        source: 'process-refund', action, status,
        request_data: { booking_id, order_id, amount, reason, ...(extra || {}) },
      }).then(() => {}, () => {})
    await dlog('request_received', 'info')

    // ── ZÁKAZNÍK (2026-10-11) ────────────────────────────────────────────────
    // Dřív smí přihlášený zákazník vrátit si LIBOVOLNOU částku z vlastní zaplacené
    // rezervace/objednávky bez jakékoli změny (zaplatit, vrátit peníze, jet dál).
    // Jediný zákaznický volající = appka po zkrácení / levnější motorce
    // (reservation_edit_screen: nejdřív zapíše nižší total_price, pak refund s
    // reason edit_shortening | moto_swap). Proto jen rezervace, jen tyto důvody,
    // jen živá rezervace a částka max. ověřený PŘEPLATEK (customer*Cap* výše).
    // Oprava f2 2026-10-22: zdroj vratky jako u obsluhy (mainSource — ne vyčerpaný /
    // nezaplacený doplatek ani platba mimo cenu) a zbytek do ověřeného přeplatku
    // z ostatních plateb rezervace; co nejde automaticky → obsluha (mail) + `partial`.
    // service_role (DB triggery / jiné edge fn) a admin (Velín) beze změny.
    const isCustomer = caller.kind === 'user'
    if (isCustomer && !booking_id) {
      await dlog('customer_order_refund_denied', 'error')
      return forbidden(CORS, 'customer_booking_only')
    }
    if (isCustomer && reason !== 'edit_shortening' && reason !== 'moto_swap') {
      await dlog('customer_reason_denied', 'error')
      return forbidden(CORS, 'reason_not_allowed')
    }
    let bookingTotalPrice = 0

    if (!booking_id && !order_id) {
      await dlog('missing_identifier', 'error')
      return new Response(
        JSON.stringify({ success: false, error: 'Missing booking_id or order_id', code: 'missing_identifier' }),
        { status: 400, headers: { ...CORS, 'Content-Type': 'application/json' } }
      )
    }

    // Look up the Stripe payment_intent_id
    let stripePaymentIntentId: string | null = null
    let entityType = 'booking'
    let entityId = booking_id || order_id || ''
    let alreadyRefunded = false
    // HOTFIX storno 2026-10-29: identita storna (bookings.cancelled_at) + řádek pro dorovnání stavu
    const cancelOnce = !!booking_id && reason === 'cancellation' && !isCustomer
    let cancelTok = ''
    let cancelBk: Record<string, any> | null = null
    let wantsRest = false

    if (booking_id) {
      const { data } = await supabase.from('bookings')
        .select('user_id, status, stripe_payment_intent_id, stripe_session_id, total_price, payment_status, payment_method, pay_channel, stripe_refund_id, card_brand, card_last4, cancelled_at')
        .eq('id', booking_id)
        .single()

      if (!data) {
        return new Response(
          JSON.stringify({ success: false, error: 'Booking not found', code: 'not_found' }),
          { status: 404, headers: { ...CORS, 'Content-Type': 'application/json' } }
        )
      }

      // Vlastnictví: přihlášený zákazník smí refundovat jen SVOU rezervaci.
      if (caller.kind === 'user' && data.user_id !== caller.userId) {
        await dlog('ownership_denied', 'error')
        return forbidden(CORS, 'not_owner')
      }
      // Zákazník: jen živá rezervace (úprava v appce), ne storno/ukončená.
      if (isCustomer && data.status !== 'reserved' && data.status !== 'active') {
        await dlog('customer_wrong_status', 'error', { status: data.status })
        return new Response(
          JSON.stringify({ success: false, error: 'Rezervaci v tomto stavu nelze upravit s vrácením peněz.', code: 'wrong_status' }),
          { status: 409, headers: { ...CORS, 'Content-Type': 'application/json' } }
        )
      }
      bookingTotalPrice = Number(data.total_price) || 0
      cancelTok = cancelToken((data as any).cancelled_at)
      cancelBk = data
      // Zákazník si total_price zapisuje sám (appka při úpravě) — nesmí být
      // nesmyslně nízká vůči ceníku (jinak by strop „zaplaceno − cena“ vrátil
      // skoro vše). Spodní mez: 80 % denních cen termínu (věrnostní sleva ≤ 20 %)
      // − ½ nejdražšího dne (sleva za vyzvednutí od 12:00) − uplatněné slevy.
      if (isCustomer) {
        const floor = await customerPriceFloorCzk(supabase, booking_id)
        if (floor == null || bookingTotalPrice + 1 < floor) {
          await dlog('customer_price_below_floor', 'error', { total_price: bookingTotalPrice, floor })
          return await customerRefundNeedsStaff(supabase, booking_id, amount, reason, dlog)
        }
      }

      // RECOVERY-ONLY dispatche (reason '…_retry' z attach smyček
      // send-booking-email / send-cancellation-email) NIKDY nevytvářejí nový
      // Stripe refund — jen dohrají chybějící dobropis/PDF k vratce, která už
      // proběhla. Incident #DDC5A69D (2026-08-12): retry se s primární vratkou
      // minul o ~1 s (credit_note ještě nebyla v DB a Stripe idempotency klíč
      // se lišil kvůli mezitím změněnému refundable) → vznikla DRUHÁ reálná
      // 556Kč vratka a duplicitní dobropis DB-2026-0002.
      // Webhook charge.refunded volá s důvodem `webhook_refund_retry` (oprava f3 — dřív bez důvodu
      // a u 'refund_pending' tak vznikla druhá plná vratka), viz _shared/refund-recovery.ts.
      if (isRecoveryOnlyReason(reason)) {
        let result = await ensureCreditNotePdf(supabase, booking_id, data)
        if (!result.creditNoteId && data.stripe_refund_id) {
          result = await createCreditNoteForExistingRefund(supabase, booking_id, data)
        }
        await dlog('recovery_only_dispatch', result.creditNoteId ? 'ok' : 'info', {
          credit_note_id: result.creditNoteId, pdf_path: result.pdfPath,
          webhook_refund_id: typeof (body as Record<string, unknown>).refund_id === 'string' ? (body as Record<string, unknown>).refund_id : null,
        })
        return new Response(
          JSON.stringify({
            success: !!result.creditNoteId,
            recovery_only: true,
            refund_id: result.refundId,
            credit_note_id: result.creditNoteId,
            credit_note_pdf_path: result.pdfPath,
            card_brand: data.card_brand,
            card_last4: data.card_last4,
          }),
          { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
        )
      }

      // Idempotency: if booking is already refunded, ensure the credit note has pdf_path
      // (regenerate if missing) and return success — DON'T call Stripe again.
      // This handles the scenario where a previous refund attempt partially succeeded
      // (Stripe refund went through, status updated, but PDF/email step failed).
      //
      // POZOR: 'partial_refund' NENÍ terminální stav — je to běžný stav rezervace po
      // PRVNÍ rozdílové úpravě (levnější motorka / odebraná výbava / zkrácení).
      // Další úprava se slevou musí umět vystavit DALŠÍ částečný Stripe refund +
      // dobropis. Proto se 'partial_refund' chová idempotentně jen BEZ explicitní
      // částky; s `amount > 0` pokračuje na nový refund (po fresh-CN dedup checku níže).
      const wantsNewPartial = data.payment_status === 'partial_refund' && Number.isFinite(Number(amount)) && Number(amount) > 0
      // HOTFIX storno 2026-10-29: Velín „Potvrdit (částečné) vrácení“ 100 % (bez amount) u stornované,
      // částečně vrácené KARTOVÉ rezervace = vrátit ZBYTEK (modal: „omezí se na dosud nevrácenou část“).
      // Dřív větev „už vráceno“ nevrátila nic a mail zákazníkovi tvrdil 100 %. Ruční platby beze změny.
      wantsRest = caller.kind === 'admin' && reason === 'cancellation' && data.status === 'cancelled'
        && data.payment_status === 'partial_refund' && !(Number(amount) > 0)
        && !!data.stripe_payment_intent_id && !isManualPayment(data)
      if (data.payment_status === 'refunded' || (data.payment_status === 'partial_refund' && !wantsNewPartial && !wantsRest)) {
        alreadyRefunded = true
        return await respondAlreadyRefunded(supabase, booking_id, data, dlog)
      }

      // Duplicitní dispatch téže rozdílové úpravy (RPC pg_net + retry v
      // send-booking-email běží souběžně): čerstvý dobropis na STEJNOU částku
      // (≤15 min) znamená, že refund téhle úpravy už proběhl → vrať existující.
      if (wantsNewPartial) {
        const { data: freshCn } = await supabase.from('invoices')
          .select('id, number, pdf_path')
          .eq('booking_id', booking_id).eq('type', 'credit_note').neq('status', 'cancelled')
          .eq('total', -Math.abs(Number(amount)))
          .gte('created_at', new Date(Date.now() - 15 * 60_000).toISOString())
          .order('created_at', { ascending: false }).limit(1)
        if (freshCn?.length) {
          await dlog('partial_refund_dedup_fresh_cn', 'info', { credit_note_id: freshCn[0].id, amount })
          // Dobropis existuje, ale PDF mohlo selhat (PDFShift/Storage) → dorenderuj,
          // ať má retry loop v send-booking-email co přiložit.
          let pdfPath = freshCn[0].pdf_path
          if (!pdfPath) {
            const ensured = await ensureCreditNotePdf(supabase, booking_id, data)
            if (ensured.creditNoteId === freshCn[0].id && ensured.pdfPath) pdfPath = ensured.pdfPath
          }
          return new Response(
            JSON.stringify({
              success: true,
              already_refunded: true,
              refund_id: data.stripe_refund_id,
              credit_note_id: freshCn[0].id,
              credit_note_pdf_path: pdfPath,
              card_brand: data.card_brand,
              card_last4: data.card_last4,
            }),
            { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
          )
        }
      }

      // Refund povolíme pro 'paid' i 'refund_pending' (= „Čeká na vrácení" — storno už
      // proběhlo, peníze jsou stále u nás a čeká se na vrácení), plus 'partial_refund'
      // s explicitní částkou (další rozdílová úprava). 'refunded' (a 'partial_refund'
      // bez částky) řeší idempotentní větev výše. Cokoli jiného (unpaid) refundovat nelze.
      if (data.payment_status !== 'paid' && data.payment_status !== 'refund_pending' && !wantsNewPartial && !wantsRest) {
        return new Response(
          JSON.stringify({
            success: false,
            error: `Booking is not paid (current: ${data.payment_status}) — cannot refund`,
            code: 'not_paid',
            current_status: data.payment_status,
          }),
          { status: 400, headers: { ...CORS, 'Content-Type': 'application/json' } }
        )
      }
      // DŮVĚŘUJ ZPŮSOBU PLATBY (2026-08-21c, zadání provozovatele): rezervace
      // zaplacená RUČNĚ potvrzenou platbou (QR / bankovní převod / hotově /
      // krypto / voucher) nemá na Stripe žádné peníze — případný PaymentIntent
      // nebo session na řádku je jen pozůstatek opuštěného pokusu o kartu.
      // Stripe API se u ní VŮBEC nevolá: rovnou manuální vratka (dobropis +
      // refund_pending, peníze pošle admin převodem). Řeší i chybu
      // „This PaymentIntent ... does not have a successful charge to refund".
      // pay_channel='qr' je pojistka pro řádky bez payment_method; kartové
      // metody (card/stripe/google_pay/apple_pay/klarna/paypal) jdou dál na Stripe.
      const payMethod = String((data as any).payment_method || '').toLowerCase().trim()
      if (isManualPayment(data)) {
        await dlog('manual_method_direct', 'info', { payment_method: payMethod, pay_channel: (data as any).pay_channel })
        return await manualBookingRefund(supabase, booking_id, amount, reason, dlog, isCustomer)
      }

      stripePaymentIntentId = data.stripe_payment_intent_id

      // Robustnost: `stripe_payment_intent_id` může být prázdný — typicky u web
      // rezervací, kde se PI uloží až po dokončení Checkoutu (race s webhookem),
      // nebo když booking nikdy neprošel přes náš confirm flow. Bez PI by refund
      // spadl na `no_stripe_payment` a Stripe by se o vrácení vůbec nedozvěděl.
      // Dohledáme ho proto ze `stripe_session_id` přes Stripe API a doplníme do DB.
      if (!stripePaymentIntentId && data.stripe_session_id) {
        try {
          const sess = await stripe.checkout.sessions.retrieve(data.stripe_session_id)
          const piFromSess = typeof sess.payment_intent === 'string'
            ? sess.payment_intent
            : (sess.payment_intent as any)?.id || null
          // PI ze session převezmi JEN když session byla skutečně ZAPLACENÁ.
          // Rezervace placená QR/převodem může nést stripe_session_id z dřívějšího
          // opuštěného pokusu o kartu — jeho nezaplacený PI by níže vedl na
          // „refundable 0 → no_op → payment_status='refunded'" (peníze by se nikdy
          // nevrátily a nevznikl by ani manuální dobropis). Nezaplacená session →
          // PI ignoruj a spadni do manuální větve (dobropis + refund_pending).
          if (piFromSess && sess.payment_status === 'paid') {
            stripePaymentIntentId = piFromSess
            await supabase.from('bookings').update({ stripe_payment_intent_id: piFromSess }).eq('id', booking_id)
            await dlog('pi_resolved_from_session', 'info', { session_id: data.stripe_session_id, payment_intent_id: piFromSess })
          } else if (piFromSess) {
            await dlog('pi_from_session_ignored_unpaid', 'info', { session_id: data.stripe_session_id, payment_intent_id: piFromSess, session_payment_status: sess.payment_status })
          }
        } catch (e) { console.warn('[process-refund] session PI resolve failed:', (e as Error).message) }
      }
    } else if (order_id) {
      entityType = 'shop'
      const { data } = await supabase.from('shop_orders')
        .select('customer_id, stripe_payment_intent_id, stripe_session_id, total_amount, payment_status')
        .eq('id', order_id)
        .single()

      if (!data) {
        return new Response(
          JSON.stringify({ success: false, error: 'Order not found', code: 'not_found' }),
          { status: 404, headers: { ...CORS, 'Content-Type': 'application/json' } }
        )
      }

      // Vlastnictví: přihlášený zákazník smí refundovat jen SVOU objednávku.
      if (caller.kind === 'user' && data.customer_id !== caller.userId) {
        await dlog('ownership_denied', 'error')
        return forbidden(CORS, 'not_owner')
      }
      if (data.payment_status !== 'paid') {
        return new Response(
          JSON.stringify({
            success: false,
            error: `Order is not paid (current: ${data.payment_status}) — cannot refund`,
            code: 'not_paid',
            current_status: data.payment_status,
          }),
          { status: 400, headers: { ...CORS, 'Content-Type': 'application/json' } }
        )
      }
      stripePaymentIntentId = data.stripe_payment_intent_id
      if (!stripePaymentIntentId && data.stripe_session_id) {
        try {
          const sess = await stripe.checkout.sessions.retrieve(data.stripe_session_id)
          const piFromSess = typeof sess.payment_intent === 'string'
            ? sess.payment_intent
            : (sess.payment_intent as any)?.id || null
          // Stejný guard jako u bookingu: PI jen ze ZAPLACENÉ session.
          if (piFromSess && sess.payment_status === 'paid') {
            stripePaymentIntentId = piFromSess
            await supabase.from('shop_orders').update({ stripe_payment_intent_id: piFromSess }).eq('id', order_id)
          }
        } catch (e) { console.warn('[process-refund] session PI resolve failed (order):', (e as Error).message) }
      }
    }

    if (!stripePaymentIntentId) {
      // Rezervace BEZ Stripe platby (QR/převod/hotově/ručně označená paid):
      // automatický Stripe refund nejde, ale vratku kvůli tomu NEBLOKUJEME —
      // manuální dobropis + refund_pending, viz manualBookingRefund.
      // Shop objednávky se chovají jako dřív (400 — řeší se ručně).
      if (booking_id) {
        return await manualBookingRefund(supabase, booking_id, amount, reason, dlog, isCustomer)
      }
      return new Response(
        JSON.stringify({
          success: false,
          error: `No Stripe payment found for this ${entityType}. Refund must be processed manually.`,
          code: 'no_stripe_payment',
        }),
        { status: 400, headers: { ...CORS, 'Content-Type': 'application/json' } }
      )
    }

    // Cap refund at the amount actually charged on Stripe.
    // Without this, edge cases (100% promo code → tiny payment, but DB-side
    // refund_amount computed from gross per-day pricing) make us request a
    // refund larger than the captured charge — Stripe then errors with
    // "Refund amount ... is greater than charge amount ..." and the user
    // sees "Něco se pokazilo. Zkus to prosím znovu."
    // HOTFIX storno 2026-10-29: souběžná storno volání téže rezervace po sobě (zámek PŘED čtením
    // vratek ze Stripe, ať druhé volání vidí vratku prvního). Bez zámku dál — rozhoduje kontrola níže.
    let cancelLock: CancelLock | null = null
    if (cancelOnce) {
      cancelLock = await acquireCancelLock(supabase, booking_id!)
      if (cancelLock.held) cancelLockBooking = booking_id!
      else await dlog('cancellation_lock_busy', 'info', { waited: cancelLock.waited })
    }

    let refundableHaleru: number | null = null
    let refundableCZK: number | null = null
    let chargedHaleru: number | null = null
    // uložená platba + její vratky (mainSource: patří vůbec do ceny rezervace?)
    let storedPi: any = null
    let storedRefunds: any[] | null = null
    try {
      const pi = await stripe.paymentIntents.retrieve(stripePaymentIntentId)
      storedPi = pi
      // POZOR (fix 2026-08-21): dřívější fallback `|| pi.amount` počítal i
      // NEZAPLACENÝ PI jako nabitý (pi.amount = pouze POŽADOVANÁ částka) —
      // refunds.create pak na PI bez charge spadl („no successful charge")
      // → 500 a vratka se nikdy nevyřídila. amount_received = skutečně přijato.
      const charged = pi.amount_received || 0
      chargedHaleru = charged
      // Subtract refunds already issued on this PI
      let alreadyRefunded = 0
      try {
        const refundsList = await stripe.refunds.list({ payment_intent: stripePaymentIntentId, limit: 100 })
        storedRefunds = refundsList.data
        for (const r of refundsList.data) {
          if (r.status === 'succeeded' || r.status === 'pending') alreadyRefunded += r.amount
        }
      } catch { /* non-fatal */ }
      refundableHaleru = Math.max(0, charged - alreadyRefunded)
      refundableCZK = refundableHaleru / 100
    } catch (e) {
      console.warn('[process-refund] PI lookup failed:', (e as Error).message)
    }

    // Vratka obsluhy / služby BEZ částky (Velín plné storno — bookingMessageHelpers isFull,
    // BookingDetail „Potvrdit vrácení" na celou cenu) = celý zůstatek plateb V CENĚ rezervace
    // (uložená platba, patří-li do ceny, + ostatní platby) a dál stejná cesta jako vratka s částkou
    // (mainSource → hlavní vratka → zbytek). Oprava f3 2026-10-22: dřív jen zbytek uložené platby —
    // po zaplacené úpravě / výměně je to doplatek, takže plné storno 3000 + 115 Kč vrátilo 115 Kč,
    // zapsalo 'refunded' a navazující volání na celou cenu (send-cancellation-email) skončilo
    // v idempotentní větvi: původní platba (i dorovnání na 15 Kč) se nevrátila nikdy; po nezapsané
    // výměně (uložený vrácený doplatek) no_op → 'refunded' a 0 Kč. Recovery (`_retry`) a idempotentní
    // větev výše se nemění; zákazník částku posílá vždy. Nelze zjistit → dosavadní chování.
    let reqAmount: number | undefined = amount
    let fullBalance = false
    if (booking_id && !isCustomer && !(Number(amount) > 0) && refundableHaleru != null) {
      const balH = await staffFullBalanceHaleru(stripe as unknown as OtherIntentsStripe, supabase, { bookingId: booking_id, storedPi, storedRefunds })
      await dlog('full_refund_balance', 'info', { balance_haleru: balH, stored_refundable_haleru: refundableHaleru, payment_intent_id: stripePaymentIntentId })
      if (balH != null && balH > 0) { reqAmount = balH / 100; fullBalance = true }
    }

    // Uložená platba nemá z čeho vracet (nikdy nezaplacený PI opuštěného doplatku, nebo
    // doplatek nezapsané změny, který se už celý vrátil přímo ze Stripe — oprava 2026-10-16),
    // nebo stojí MIMO cenu rezervace (doplatek změny, kterou webhook ještě nezapsal, platba
    // vrácená jen jako peníze mimo cenu — oprava f1 2026-10-22), ale rezervace má jiné úspěšné
    // platby kartou → hlavní vratka z nejstarší z nich (typicky původní platba rezervace),
    // zbytek níže z ostatních. Platba mimo cenu a žádná jiná platba kartou (rezervace placená
    // QR / převodem / hotově) → ruční vratka (dobropis + refund_pending). Dřív: no_op →
    // 'refunded' bez vrácení peněz, resp. storno část ceny z ještě nezapsaného doplatku. Jen
    // vratka s částkou — storno, obsluha i zákaznická vratka z appky (oprava f2 2026-10-22:
    // dřív jen z uložené platby, tj. z posledního doplatku oříznutá na jeho zbytek).
    if (booking_id && (chargedHaleru === 0 || refundableHaleru === 0 || storedPi)) {
      try {
        const src = await mainSource(stripe as unknown as OtherIntentsStripe, supabase, {
          bookingId: booking_id, storedPiId: stripePaymentIntentId, storedPi, storedRefunds, chargedHaleru, refundableHaleru, isCustomer, amount: reqAmount,
        })
        if (src.kind === 'retarget') {
          await dlog('main_pi_retargeted', 'info', { stored_payment_intent_id: stripePaymentIntentId, payment_intent_id: src.piId,
            stored_charged_haleru: chargedHaleru, refundable_haleru: src.refundableHaleru, stored_outside_price: src.outside })
          stripePaymentIntentId = src.piId
          chargedHaleru = src.refundableHaleru
          refundableHaleru = src.refundableHaleru
          refundableCZK = refundableHaleru / 100
        } else if (src.kind === 'manual') {
          await dlog('stored_pi_outside_price_manual', 'info', { payment_intent_id: stripePaymentIntentId, outside: src.outside })
          return await manualBookingRefund(supabase, booking_id, amount, reason, dlog, isCustomer)
        }
      } catch (e) {
        await dlog('main_pi_retarget_failed', 'error', { error: (e as Error).message })
      }
    }

    // PI existuje, ale Stripe na něm NIKDY nepřijal peníze → rezervace byla
    // reálně zaplacená jinak (QR/převod/hotově; stale PI z opuštěného pokusu
    // o kartu, který si starší verze uložila do bookings.stripe_payment_intent_id).
    // Bez tohoto fallbacku by no_op větev níže chybně označila 'refunded'
    // (peníze by se nikdy nevrátily a nevznikl by ani dobropis).
    if (booking_id && chargedHaleru === 0) {
      // „Vrátit zbytek“ jde jen ze Stripe platby — bez ní jako dřív „už vráceno“ (žádný ruční dobropis na celou cenu).
      if (wantsRest && cancelBk) return await respondAlreadyRefunded(supabase, booking_id, cancelBk, dlog)
      await dlog('pi_never_charged_manual_fallback', 'info', { payment_intent_id: stripePaymentIntentId })
      return await manualBookingRefund(supabase, booking_id, amount, reason, dlog, isCustomer)
    }

    // HOTFIX storno 2026-10-29: volání ze serveru (send-cancellation-email) na storno, ke kterému
    // už naše storno vratka existuje (i pending / bez zapsaného stavu) → žádná druhá vratka.
    // Obsluha (Velín): jen duplicita TÉHOŽ požadavku (dvojité odeslání / souběh při čekání na zámek);
    // vědomá další vratka („Potvrdit vrácení“ jiné částky) projde jako dřív.
    // Dev (více plateb): vratky VŠECH plateb rezervace (hlavní vratka mohla jít z jiné platby než
    // z uložené — mainSource), stav dle zůstatku všech plateb v ceně a dokončení nevráceného zbytku
    // téhož storna po pádu (cancel-once-pool.ts).
    if (cancelOnce && cancelBk && storedRefunds) {
      const ois = stripe as unknown as OtherIntentsStripe
      const pool = await cancellationRefundPool(ois, supabase, { bookingId: booking_id!, storedPiId: storedPi?.id || stripePaymentIntentId,
        storedRefunds: storedRefunds as unknown as StripeRefundLike[] })
      const prior = caller.kind === 'service'
        ? priorCancellationRefunds(pool, booking_id!, cancelTok)
        : duplicateAdminRefunds(pool, booking_id!, {
          amountHaleru: Number(amount) > 0 ? Math.round(Number(amount) * 100) : null,
          nowS: Math.floor(Date.now() / 1000), lock: cancelLock,
        })
      if (prior.length) {
        return await respondExistingCancelRefund({
          supabase, bookingId: booking_id!, token: cancelTok, prior: prior[0], refunds: pool, refundableHaleru,
          lockHeld: !!cancelLock?.held, createCn: createCreditNoteForExistingRefund, ensureCn: ensureCreditNotePdf, dlog,
          complete: (main) => completeCancelRemainder(ois, supabase, { bookingId: booking_id!, main, pool, dlog }),
          remaining: () => staffFullBalanceHaleru(ois, supabase, { bookingId: booking_id!, storedPi, storedRefunds: null }),
          cardOf: async (r) => {
            const chargeId = typeof r.charge === 'string' ? r.charge : (r.charge as any)?.id
            if (!chargeId) return null
            const ch = await stripe.charges.retrieve(chargeId)
            return { brand: ch?.payment_method_details?.card?.brand || null, last4: ch?.payment_method_details?.card?.last4 || null }
          },
          headers: { ...CORS, 'Content-Type': 'application/json' },
        })
      }
    }

    // Decide effective amount (in haléře). Null = full refund.
    let effectiveAmountHaleru: number | null = null
    if (reqAmount && reqAmount > 0) {
      effectiveAmountHaleru = Math.round(reqAmount * 100)
      if (refundableHaleru != null && effectiveAmountHaleru > refundableHaleru) {
        console.warn(`[process-refund] requested ${effectiveAmountHaleru/100} CZK > refundable ${refundableHaleru/100} CZK — clamping`)
        effectiveAmountHaleru = refundableHaleru
      }
    } else if (refundableHaleru != null) {
      effectiveAmountHaleru = refundableHaleru
    }

    // Zákazník: max. ověřený přeplatek přes platby V CENĚ rezervace (customerCapHaleru).
    // Neověřitelné / nulové → nic se nevrací ani nemění (žádné no_op → 'refunded'),
    // vyřídí obsluha. Strop platí pro hlavní vratku i zbytek z ostatních plateb níže.
    let customerCapH: number | null = null
    if (isCustomer && booking_id) {
      customerCapH = refundableHaleru == null ? null
        : await customerCapHaleru(stripe as unknown as OtherIntentsStripe, supabase, { bookingId: booking_id, storedPi, storedRefunds,
          totalPrice: bookingTotalPrice })
      await dlog('customer_refund_cap', 'info', { cap_haleru: customerCapH, requested_haleru: effectiveAmountHaleru, refundable_haleru: refundableHaleru,
        payment_intent_id: stripePaymentIntentId })
      if (customerCapH == null || effectiveAmountHaleru == null || Math.min(effectiveAmountHaleru, customerCapH) <= 0) {
        return await customerRefundNeedsStaff(supabase, booking_id, amount, reason, dlog)
      }
      effectiveAmountHaleru = Math.min(effectiveAmountHaleru, customerCapH)
    }

    // Nothing left to refund (e.g. fully discounted booking that paid 0 Kč,
    // or already-refunded PI) — short-circuit with success so the caller
    // (web "Zkrátit a vrátit peníze" / change-bike flow) doesn't error out.
    if (effectiveAmountHaleru === 0) {
      if (booking_id) {
        await supabase.from('bookings').update({ payment_status: 'refunded' }).eq('id', booking_id)
      } else if (order_id) {
        await supabase.from('shop_orders').update({ payment_status: 'refunded' }).eq('id', order_id)
      }
      return new Response(
        JSON.stringify({
          success: true,
          refund_id: null,
          status: 'no_op',
          amount_refunded: 0,
          currency: 'czk',
          credit_note_id: null,
          card_brand: null,
          card_last4: null,
          note: 'Nothing left to refund (already refunded or amount paid was 0)',
        }),
        { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
      )
    }

    // Create Stripe refund. Metadata mg_* označují refund jako NÁŠ (interní) —
    // webhook-receiver charge.refunded podle nich pozná, že dobropis/mail/stavy
    // řeší tohle flow, a rezervaci NEzruší jako „Stripe portál storno"
    // (incident #DDC5A69D 2026-08-12: částečná vratka výměny motorky → auto-storno).
    const refundParams: Stripe.RefundCreateParams = {
      payment_intent: stripePaymentIntentId,
      reason: reason === 'duplicate' ? 'duplicate' : 'requested_by_customer',
      metadata: {
        mg_source: 'process-refund',
        mg_reason: reason || '',
        mg_booking_id: booking_id || '',
        mg_order_id: order_id || '',
        // HOTFIX storno 2026-10-29: identita storna (cancel-once.ts); dev: požadavek celého storna
        // (hlavní + zbytek z ostatních plateb) pro dorovnání po pádu (cancel-once-pool.ts)
        ...(booking_id && reason === 'cancellation' ? { mg_cancel_at: cancelTok,
          ...(reqAmount && reqAmount > 0 ? { mg_target: String(Math.round(reqAmount * 100)) } : {}) } : {}),
      },
    }
    if (effectiveAmountHaleru != null && (refundableHaleru == null || effectiveAmountHaleru < refundableHaleru)) {
      refundParams.amount = effectiveAmountHaleru
    }

    // Stripe idempotency key — dva souběžné dispatche TÉŽE refundace (pg_net z RPC
    // + recovery retry v send-booking-email startují dřív, než první stihne zapsat
    // credit_note) se na Stripe srazí do JEDNOHO refundu. Sekvenční složka =
    // `refundableHaleru` (charged − už refundováno na PI): souběžné duplicity ho
    // vidí stejné → stejný klíč → jeden refund; legitimní DALŠÍ refund (klidně
    // stejné částky) přijde až po provedení předchozího → refundable kleslo →
    // jiný klíč. Fallback na počet dobropisů, když PI lookup selhal.
    let seqPart: number | string | null = refundableHaleru
    if (seqPart == null) {
      try {
        let cq = supabase.from('invoices')
          .select('id', { count: 'exact', head: true })
          .eq('type', 'credit_note').neq('status', 'cancelled')
        cq = booking_id ? cq.eq('booking_id', booking_id) : cq.eq('order_id', order_id)
        const { count } = await cq
        seqPart = `cn${count || 0}`
      } catch { seqPart = 'na' }
    }
    const idempotencyKey = `refund:${booking_id || order_id}:${effectiveAmountHaleru ?? 'full'}:${seqPart}`

    await dlog('stripe_refund_create_pre', 'info', { effectiveAmountHaleru, refundableHaleru, idempotency_key: idempotencyKey })
    const refund = await stripe.refunds.create(refundParams, { idempotencyKey })
    await dlog('stripe_refund_create_ok', 'info', { refund_id: refund.id, refund_status: refund.status, refund_amount: refund.amount })

    // Vratka větší, než zbývá na hlavní platbě (doplatky úprav a výměn vč. dorovnání na 15 Kč
    // se platily jinými PaymentIntenty) → zbytek z ostatních plateb TÉŽE rezervace (odpověď
    // majitele 2026-10-16: dorovnání se při stornu vrací poměrně jako zbytek ceny). Zákaznická
    // vratka (appka; oprava f2 2026-10-22) stejně, ale celkem jen do ověřeného přeplatku
    // (customerCapH) — dřív šla jen z hlavní platby a zbytek se tiše ztratil.
    let extra: { refunds: ExtraRefund[]; refundedHaleru: number; leftHaleru: number; error?: string } =
      { refunds: [], refundedHaleru: 0, leftHaleru: 0 }
    const requestedHaleru = reqAmount && reqAmount > 0 ? Math.round(reqAmount * 100) : null
    const targetHaleru = requestedHaleru == null ? null
      : (isCustomer ? Math.min(requestedHaleru, customerCapH ?? 0) : requestedHaleru)
    if (booking_id && targetHaleru != null && effectiveAmountHaleru != null && targetHaleru > effectiveAmountHaleru) {
      extra = await refundRemainder(stripe as unknown as OtherIntentsStripe, supabase, {
        bookingId: booking_id, mainPi: stripePaymentIntentId, mainRefundId: refund.id, remainingHaleru: targetHaleru - effectiveAmountHaleru, reason,
      })
      await dlog(extra.error ? 'stripe_refund_remainder_partial' : 'stripe_refund_remainder', extra.error ? 'error' : 'info', {
        requested_haleru: requestedHaleru, target_haleru: targetHaleru, main_haleru: effectiveAmountHaleru, extra: extra.refunds,
        left_haleru: extra.leftHaleru, error: extra.error || null,
      })
    }
    // Co se z požadované částky automaticky NEvrátilo (zákazník: nad ověřený přeplatek, nebo
    // ostatní platby nestačily / selhaly) → obsluha (mail), rezervace partial_refund, odpověď
    // `partial: true` (appka pak neslibuje celou částku — pdRefundManual). Zákazník: zbytek
    // do 1 Kč = zaokrouhlení ceny na haléře → jen záznam (CUSTOMER_SHORT_TOLERANCE_HALERU).
    const shortRaw = booking_id && requestedHaleru != null && effectiveAmountHaleru != null
      ? Math.max(0, requestedHaleru - effectiveAmountHaleru - extra.refundedHaleru) : 0
    const shortHaleru = isCustomer && shortRaw <= CUSTOMER_SHORT_TOLERANCE_HALERU ? 0 : shortRaw
    if (shortRaw > 0 && !shortHaleru) await dlog('refund_short_rounding', 'info', { short_haleru: shortRaw })
    if (shortHaleru > 0) {
      const reqH = requestedHaleru ?? 0
      const doneH = Number(refund.amount || 0) + extra.refundedHaleru
      await dlog('refund_short', 'error', { requested_haleru: requestedHaleru, refunded_haleru: doneH, short_haleru: shortHaleru,
        customer_cap_haleru: customerCapH, customer: isCustomer })
      const num = String(booking_id).slice(-8).toUpperCase()
      await sendOpsMail(
        isCustomer ? `⚠️ Vratku za úpravu rezervace #${num} dořešte ručně (vráceno jen částečně)` : '⚠️ Vratka rezervace se nevrátila celá automaticky',
        `<p>Rezervace <strong>${isCustomer ? '#' + num : booking_id}</strong> (${reasonTextFor(reason)}): požadováno <strong>${reqH / 100} Kč</strong>, `
        + `automaticky vráceno <strong>${doneH / 100} Kč</strong> `
        + `(hlavní platba ${stripePaymentIntentId}${extra.refunds.length ? ', další platby ' + extra.refunds.map((x) => x.piId).join(', ') : ''}), `
        + `zbývá <strong>${shortHaleru / 100} Kč</strong>.</p>`
        + (isCustomer
          ? `<p>Úprava v aplikaci je uložená. Automaticky se vrací jen ověřený přeplatek (platby kartou v ceně rezervace − vrácené − aktuální cena = ${(customerCapH ?? 0) / 100} Kč)${extra.error ? ' a vratka z dalších plateb selhala (debug log stripe_refund_remainder_partial)' : ''}. Zákazník v aplikaci vidí, že zbytek vratky dokončí obsluha.</p>`
          : (extra.error ? '<p>Vratka z dalších plateb selhala (debug log stripe_refund_remainder_partial).</p>' : ''))
        + '<p>Zbytek zkontrolujte a případně vraťte ručně ve Velíně.</p>',
      )
    }

    // Look up card brand/last4 from the underlying Charge (used both on credit note and bookings).
    let cardBrand: string | null = null
    let cardLast4: string | null = null
    try {
      const chargeId = typeof refund.charge === 'string' ? refund.charge : (refund.charge as any)?.id
      if (chargeId) {
        const ch = await stripe.charges.retrieve(chargeId)
        cardBrand = ch?.payment_method_details?.card?.brand || null
        cardLast4 = ch?.payment_method_details?.card?.last4 || null
      }
    } catch (e) { console.warn('[process-refund] charge retrieve failed:', (e as Error).message) }

    // Update payment_status in DB
    const refundedAmountCZK = (Number(refund.amount || 0) + extra.refundedHaleru) / 100
    if (booking_id) {
      // Mapování na payment_status dle reality vrácení peněz:
      //  - Stripe refund ještě nepotvrzen (status='pending') → 'refund_pending' (Čeká na vrácení).
      //    Finální stav dorazí webhookem charge.refunded / refund.updated.
      //  - částečné vrácení (zadaná `amount` menší než zbývající k vrácení) → 'partial_refund'.
      //  - jinak (plné vrácení / succeeded) → 'refunded'.
      // Zákaznická vratka = jen přeplatek → rezervace s nenulovou cenou zůstává zaplacená
      // (i když se tím vyčerpá aktuální PI, např. doplatkový).
      const newStatus = refundedStatus({ refundStatus: refund.status, isCustomer, bookingTotalPrice, amount: reqAmount,
        refundableHaleru, effectiveAmountHaleru, leftHaleru: extra.leftHaleru, shortHaleru, fullBalance })
      const bkPatch: Record<string, any> = { payment_status: newStatus, stripe_refund_id: refund.id }
      if (cardBrand) bkPatch.card_brand = cardBrand
      if (cardLast4) bkPatch.card_last4 = cardLast4
      await supabase.from('bookings').update(bkPatch).eq('id', booking_id)
    } else if (order_id) {
      await supabase.from('shop_orders')
        .update({ payment_status: 'refunded' })
        .eq('id', order_id)
    }

    // Auto-generate credit note (dobropis) for booking refunds
    let creditNoteId: string | null = null
    if (booking_id) {
      try {
        // Fetch booking data for the credit note
        const { data: bk } = await supabase.from('bookings')
          .select('user_id, total_price, start_date, end_date, motorcycles!moto_id(model), profiles:user_id(id, full_name, email, phone, street, city, zip, ico, dic)')
          .eq('id', booking_id).single()
        if (bk) {
          const refundPercent = amount ? Math.round((amount / Number(bk.total_price || 1)) * 100) : 100
          const reasonText = reasonTextFor(reason)

          // Find original invoice to reference
          const { data: origInvs } = await supabase.from('invoices')
            .select('id, type, number')
            .eq('booking_id', booking_id)
            .neq('status', 'cancelled')
            .in('type', ['final', 'payment_receipt', 'advance', 'proforma'])
            .order('issue_date', { ascending: false })
            .limit(1)
          const originalInvoiceId = origInvs?.[0]?.id || null
          const originalInvoiceNumber = origInvs?.[0]?.number || null

          const cnNotes = `Dobropis k rezervaci. ${refundPercent < 100 ? `Částečný refund ${refundPercent}%.` : 'Plný refund.'} ${reasonText}`
            + (extra.refunds.length ? ` Vráceno z více plateb: ${refund.id} + ${extra.refunds.map((x) => x.refundId).join(', ')}.` : '')
          // Výpůjčka výbavy (2026-10-23): bez motorky → „výpůjčka výbavy“ (gear) / „motorky“ (gear.ts).
          const cnMotoModel = (bk as any).motorcycles?.model || await noMotoRefundSubject(supabase, booking_id)

          // Idempotency: if a credit_note already exists for this booking + refund, reuse it
          const { data: existingCn } = await supabase.from('invoices')
            .select('id, number, pdf_path, total, status')
            .eq('booking_id', booking_id)
            .eq('type', 'credit_note')
            .eq('stripe_refund_id', refund.id)
            .limit(1)
          let cnNumber: string
          let cnId: string | null = null

          if (existingCn?.length) {
            cnId = existingCn[0].id
            cnNumber = existingCn[0].number
            // Oprava f3: dobropis mohla k této vratce vystavit recovery z webhooku charge.refunded
            // dřív, než tohle volání vrátilo zbytek z ostatních plateb — jen z částky hlavní vratky.
            // Dorovnat na skutečně vrácenou částku (položka, základ, celkem, poznámka, účetní záznam).
            if (existingCn[0].status !== 'cancelled') {
              try {
                const fixed = await reconcileCreditNote(supabase, { cnId: cnId!, cnNumber, bookingId: booking_id,
                  currentTotal: Number(existingCn[0].total || 0), targetCzk: refundedAmountCZK,
                  description: `Dobropis – ${reasonText} (${cnMotoModel})`, reasonText, notes: cnNotes,
                  issueDate: new Date().toISOString().slice(0, 10) })
                if (fixed != null) await dlog('credit_note_reconciled', 'info', { credit_note_id: cnId, from: existingCn[0].total, to: -fixed })
              } catch (e) {
                await dlog('credit_note_reconcile_failed', 'error', { credit_note_id: cnId, error: (e as Error).message })
              }
            }
          } else {
            // Číslo dobropisu (DB-YYYY-NNNN) — atomicky, automatická řada < 5000.
            cnNumber = await nextDocNumber(supabase, 'DB')

            const issueDate = new Date().toISOString().slice(0, 10)
            const motoModel = cnMotoModel
            const { data: cnInv, error: cnErr } = await supabase.from('invoices').insert({
              number: cnNumber,
              type: 'credit_note',
              customer_id: bk.user_id,
              booking_id,
              items: [{
                description: `Dobropis – ${reasonText} (${motoModel})`,
                qty: 1,
                unit_price: -refundedAmountCZK,
              }],
              subtotal: -refundedAmountCZK,
              tax_amount: 0,
              total: -refundedAmountCZK,
              notes: cnNotes,
              issue_date: issueDate,
              due_date: issueDate,
              status: 'issued',
              source: 'refund',
              variable_symbol: cnNumber,
              original_invoice_id: originalInvoiceId,
              stripe_refund_id: refund.id,
            }).select('id').single()

            cnId = cnInv?.id || null
            if (cnErr || !cnId) {
              // Stripe refund UŽ PROBĚHL — bez dobropisu by k vrácené částce
              // nebyl daňový doklad a dřív se to tiše zalogovalo jako úspěch.
              await dlog('credit_note_insert_failed', 'error', {
                booking_id, number: cnNumber, error: cnErr?.message || 'insert vrátil prázdno',
              })
              await sendOpsMail(
                '⚠️ Dobropis se nevystavil — vratka ale odešla',
                `<p>Rezervace <strong>${booking_id}</strong>: Stripe refund <code>${refund.id}</code> `
                + `proběhl na <strong>${refundedAmountCZK} Kč</strong>, ale zápis dobropisu `
                + `<strong>${cnNumber}</strong> selhal: ${cnErr?.message || 'prázdná odpověď'}.</p>`
                + '<p>Peníze zákazníkovi odešly, daňový doklad k nim ale chybí — '
                + 'vystavte dobropis ručně ve Velíně.</p>',
              )
            } else {
              await dlog('credit_note_inserted', 'info', { credit_note_id: cnId, number: cnNumber })
            }

            // Create negative accounting entry only on first creation
            await supabase.from('accounting_entries').insert({
              type: 'expense',
              amount: -refundedAmountCZK,
              description: `Dobropis ${cnNumber} – ${reasonText}`,
              category: 'refund',
              date: issueDate,
              booking_id,
            })
          }

          creditNoteId = cnId

          // Render and upload dobropis PDF/HTML so it can be attached to the cancellation email.
          if (cnId) {
            try {
              // Výpůjčka výbavy (2026-10-23): bez motorky → „výpůjčka výbavy“ (gear) / „motorky“ (gear.ts).
              const motoModel2 = (bk as any).motorcycles?.model || await noMotoRefundSubject(supabase, booking_id)
              const cust4 = (bk as any).profiles || {}
              await loadCustomerCompany(supabase, cust4)
              const html = renderCreditNoteHtml({
                number: cnNumber,
                issueDate: fmtDate(new Date().toISOString().slice(0, 10)),
                reasonText,
                motoModel: motoModel2,
                refundAmount: refundedAmountCZK,
                refundPercent,
                bookingDates: `${fmtDate(bk.start_date)} – ${fmtDate(bk.end_date)}`,
                customer: cust4,
                originalInvoiceNumber,
                stripeRefundId: refund.id,
                cardBrand,
                cardLast4,
              })
              const pdfBytes = await htmlToPdf(html)
              await dlog('pdfshift_render_done', 'info', { credit_note_id: cnId, has_pdf: !!pdfBytes, pdf_bytes: pdfBytes?.length || 0 })
              let path: string
              if (pdfBytes) {
                path = `invoices/${cnId}.pdf`
                const { error: upErr } = await supabase.storage.from('documents').upload(
                  path, new Blob([pdfBytes], { type: 'application/pdf' }),
                  { upsert: true, contentType: 'application/pdf' },
                )
                if (upErr) await dlog('pdf_upload_failed', 'error', { path, error: upErr.message })
              } else {
                path = `invoices/${cnId}.html`
                const { error: upErr } = await supabase.storage.from('documents').upload(
                  path, new Blob([html], { type: 'text/html' }),
                  { upsert: true, contentType: 'text/html' },
                )
                if (upErr) await dlog('pdf_upload_failed', 'error', { path, error: upErr.message })
              }
              const { error: updErr } = await supabase.from('invoices').update({ pdf_path: path }).eq('id', cnId)
              await dlog('credit_note_finalized', updErr ? 'error' : 'ok', { credit_note_id: cnId, pdf_path: path, update_error: updErr?.message })
            } catch (pdfErr) {
              console.warn('[process-refund] credit note PDF render failed:', (pdfErr as Error).message)
              await dlog('pdfshift_render_failed', 'error', { credit_note_id: cnId, error: (pdfErr as Error).message })
            }
          }
        }
      } catch (cnErr) {
        console.error('Credit note generation failed:', (cnErr as Error).message)
        // Non-blocking — refund was already processed
      }
    }

    // Log to debug_log
    try {
      await supabase.from('debug_log').insert({
        source: 'process-refund',
        action: 'stripe_refund_created',
        component: entityType,
        status: 'ok',
        request_data: { booking_id, order_id, amount, reason },
        response_data: { refund_id: refund.id, status: refund.status, amount_refunded: refundedAmountCZK, credit_note_id: creditNoteId, extra_refunds: extra.refunds,
          short_haleru: shortHaleru },
      })
    } catch (e) { /* ignore */ }

    return new Response(
      JSON.stringify({
        success: true,
        refund_id: refund.id,
        status: refund.status,
        amount_refunded: refundedAmountCZK,
        currency: refund.currency,
        credit_note_id: creditNoteId,
        card_brand: cardBrand,
        card_last4: cardLast4,
        // f2: automaticky se nevrátila celá požadovaná částka (zbytek vyřídí obsluha)
        partial: shortHaleru > 0,
        requested_amount: requestedHaleru != null ? requestedHaleru / 100 : null,
      }),
      { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
    )
  } catch (err) {
    console.error('Refund error:', err)

    try {
      await supabase.from('debug_log').insert({
        source: 'process-refund',
        action: 'stripe_refund_error',
        component: 'stripe',
        status: 'error',
        error_message: (err as Error).message,
      })
      // Pozn.: konkrétní booking_id už zachytí dlog('request_received', ...) na začátku
      // request flow + dlog na každém kroku. Pokud catch fire-nul po request_received,
      // korelace přes timestamp + sekvence akcí pro daný booking je v debug_log evidentní.
    } catch (e) { /* ignore */ }

    return new Response(
      JSON.stringify({ success: false, error: 'Refund failed: ' + (err as Error).message }),
      { status: 500, headers: { ...CORS, 'Content-Type': 'application/json' } }
    )
  } finally {
    if (cancelLockBooking) await releaseCancelLock(supabase, cancelLockBooking)
  }
})
