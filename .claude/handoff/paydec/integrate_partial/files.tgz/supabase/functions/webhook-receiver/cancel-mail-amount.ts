// ===== webhook-receiver/cancel-mail-amount.ts =====
// Spojení HOTFIXU storna 2026-10-29 (pojistný storno mail z charge.refunded se skip_refund — jen text)
// s vratkou z více plateb (dev f1–f3): storno vrací hlavní vratkou + zbytkem z ostatních plateb
// rezervace, takže `charge.amount_refunded` uložené platby ≠ vratka storna (např. doplatek 115 Kč
// z 1 558 Kč) a mail, který doběhne dřív než mail z Velínu (claim 30 min), by tvrdil špatnou částku.
// Naše storno vratka nese mg_target = požadovaná částka celého storna (process-refund) → mail ji
// použije; zbytek (mg_part 'remainder') ji vezme z hlavní vratky (mg_main_refund). Jinak null →
// částka z charge jako dřív (externí vratka ze Stripe portálu, starší vratka bez mg_target).
type Md = Record<string, string | undefined>
type RefundLike = { id?: string; metadata?: Md | null } | null | undefined
type RefundsApi = { refunds: { retrieve: (id: string) => Promise<{ metadata?: unknown } | null> } }

const targetCzk = (md: Md | null | undefined): number | null => {
  const t = Number(md?.mg_target)
  return Number.isFinite(t) && t > 0 ? Math.round(t) / 100 : null
}

/** Částka storno vratky pro mail (Kč) z metadat naší vratky; null = použij charge.amount_refunded. */
export async function cancellationMailRefundCzk(stripe: RefundsApi, latest: RefundLike): Promise<number | null> {
  const md = (latest?.metadata || {}) as Md
  if (md.mg_source !== 'process-refund' || md.mg_reason !== 'cancellation') return null
  if (md.mg_part !== 'remainder') return targetCzk(md)
  if (!md.mg_main_refund) return null
  try {
    const main = await stripe.refunds.retrieve(md.mg_main_refund)
    return targetCzk((main?.metadata || null) as Md | null)
  } catch { return null }
}
